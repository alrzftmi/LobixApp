using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

using LobixApp.Models;

namespace LobixApp.Services
{
    public class LobixApiService : IDisposable
    {
        // =====================================================
        // API CONFIGURATION
        // =====================================================

        private const string ApiBaseUrl =
            "https://lobixapp.ir/wp-json/lobix/operator/v2/";

        private readonly HttpClient _httpClient;

        private readonly JsonSerializerOptions _jsonOptions = new()
        {
            PropertyNameCaseInsensitive = true
        };

        // =====================================================
        // CONSTRUCTOR
        // =====================================================

        public LobixApiService()
        {
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri(ApiBaseUrl),
                Timeout = TimeSpan.FromSeconds(30)
            };

            _httpClient.DefaultRequestHeaders.Accept.Clear();

            _httpClient.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue(
                    "application/json"
                )
            );
        }

        // =====================================================
        // AUTHENTICATION STATE
        // =====================================================

        public string? Token { get; private set; }

        public bool IsAuthenticated =>
            !string.IsNullOrWhiteSpace(Token);

        // =====================================================
        // SYNC DEBUG INFORMATION
        // =====================================================

        public string? LastSyncRawResponse { get; private set; }

        public string? LastSyncRequestUrl { get; private set; }

        // =====================================================
        // LOGIN
        // =====================================================

        public async Task<OperatorSession> LoginAsync(
            string username,
            string password,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(username))
            {
                throw new ArgumentException(
                    "نام کاربری وارد نشده است.",
                    nameof(username)
                );
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                throw new ArgumentException(
                    "رمز عبور وارد نشده است.",
                    nameof(password)
                );
            }

            var requestData = new
            {
                username = username.Trim(),
                password = password
            };

            string json =
                JsonSerializer.Serialize(
                    requestData,
                    _jsonOptions
                );

            using var content =
                new StringContent(
                    json,
                    Encoding.UTF8,
                    "application/json"
                );

            using HttpResponseMessage response =
                await _httpClient.PostAsync(
                    "login",
                    content,
                    cancellationToken
                );

            string responseBody =
                await response.Content.ReadAsStringAsync(
                    cancellationToken
                );

            if (!response.IsSuccessStatusCode)
            {
                throw CreateApiException(
                    response.StatusCode,
                    responseBody
                );
            }

            using JsonDocument document =
                ParseJsonOrThrow(
                    "Login",
                    responseBody
                );

            JsonElement root =
                document.RootElement;

            if (root.TryGetProperty(
                    "success",
                    out JsonElement successElement))
            {
                if (successElement.ValueKind ==
                    JsonValueKind.False)
                {
                    throw new Exception(
                        GetApiMessage(
                            root,
                            "ورود ناموفق بود."
                        )
                    );
                }
            }

            string token =
                GetString(
                    root,
                    "token"
                );

            if (string.IsNullOrWhiteSpace(token))
            {
                throw new Exception(
                    "ورود انجام شد اما API توکن معتبری برنگرداند."
                );
            }

            string expiresAt =
                GetString(
                    root,
                    "expires_at"
                );

            string usernameFromServer =
                username.Trim();

            string displayName =
                string.Empty;

            int userId = 0;

            if (root.TryGetProperty(
                    "user",
                    out JsonElement userElement))
            {
                userId =
                    GetInt(
                        userElement,
                        "id"
                    );

                string serverUsername =
                    GetString(
                        userElement,
                        "username"
                    );

                if (!string.IsNullOrWhiteSpace(
                        serverUsername))
                {
                    usernameFromServer =
                        serverUsername;
                }

                displayName =
                    GetString(
                        userElement,
                        "name"
                    );
            }

            SetAuthentication(token);

            return new OperatorSession
            {
                Token = token,
                TokenExpiresAt = expiresAt,
                UserId = userId,
                Username = usernameFromServer,
                DisplayName = displayName
            };
        }

        // =====================================================
        // SET AUTHENTICATION
        // =====================================================

        public void SetAuthentication(
            string token)
        {
            if (string.IsNullOrWhiteSpace(token))
            {
                throw new ArgumentException(
                    "توکن احراز هویت معتبر نیست.",
                    nameof(token)
                );
            }

            Token =
                token.Trim();

            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue(
                    "Bearer",
                    Token
                );
        }

        // =====================================================
        // ME
        // =====================================================

        public async Task<JsonDocument> GetMeAsync(
            CancellationToken cancellationToken = default)
        {
            EnsureAuthenticated();

            using HttpResponseMessage response =
                await _httpClient.GetAsync(
                    "me",
                    cancellationToken
                );

            string responseBody =
                await response.Content.ReadAsStringAsync(
                    cancellationToken
                );

            if (!response.IsSuccessStatusCode)
            {
                throw CreateApiException(
                    response.StatusCode,
                    responseBody
                );
            }

            return ParseJsonOrThrow(
                "Me",
                responseBody
            );
        }

        // =====================================================
        // GET GAMENETS
        // =====================================================

        public async Task<List<GamenetInfo>> GetGamenetsAsync(
            CancellationToken cancellationToken = default)
        {
            EnsureAuthenticated();

            using HttpResponseMessage response =
                await _httpClient.GetAsync(
                    "gamenets",
                    cancellationToken
                );

            string responseBody =
                await response.Content.ReadAsStringAsync(
                    cancellationToken
                );

            if (!response.IsSuccessStatusCode)
            {
                throw CreateApiException(
                    response.StatusCode,
                    responseBody
                );
            }

            using JsonDocument document =
                ParseJsonOrThrow(
                    "Gamenets",
                    responseBody
                );

            JsonElement root =
                document.RootElement;

            if (root.TryGetProperty(
                    "success",
                    out JsonElement successElement))
            {
                if (successElement.ValueKind ==
                    JsonValueKind.False)
                {
                    throw new Exception(
                        GetApiMessage(
                            root,
                            "دریافت لیست گیمنت‌ها ناموفق بود."
                        )
                    );
                }
            }

            var gamenets =
                new List<GamenetInfo>();

            if (!root.TryGetProperty(
                    "gamenets",
                    out JsonElement gamenetsElement))
            {
                return gamenets;
            }

            if (gamenetsElement.ValueKind !=
                JsonValueKind.Array)
            {
                return gamenets;
            }

            foreach (JsonElement item in
                     gamenetsElement.EnumerateArray())
            {
                gamenets.Add(
                    new GamenetInfo
                    {
                        Id =
                            GetInt(
                                item,
                                "id"
                            ),

                        Name =
                            GetString(
                                item,
                                "name"
                            ),

                        Status =
                            GetString(
                                item,
                                "status"
                            ),

                        OwnerUserId =
                            GetInt(
                                item,
                                "owner_user_id"
                            )
                    }
                );
            }

            return gamenets;
        }

        // =====================================================
        // GET GAMENET DETAILS
        // =====================================================

        public async Task<JsonDocument> GetGamenetDetailsAsync(
            int productId,
            CancellationToken cancellationToken = default)
        {
            EnsureAuthenticated();

            if (productId <= 0)
            {
                throw new ArgumentException(
                    "شناسه گیمنت معتبر نیست.",
                    nameof(productId)
                );
            }

            string cacheBuster =
                DateTimeOffset.UtcNow
                    .ToUnixTimeMilliseconds()
                    .ToString();

            string requestUrl =
                "gamenet" +
                $"?product_id={Uri.EscapeDataString(productId.ToString())}" +
                $"&_nocache={Uri.EscapeDataString(cacheBuster)}";

            using HttpResponseMessage response =
                await _httpClient.GetAsync(
                    requestUrl,
                    cancellationToken
                );

            string responseBody =
                await response.Content.ReadAsStringAsync(
                    cancellationToken
                );

            if (!response.IsSuccessStatusCode)
            {
                throw CreateApiException(
                    response.StatusCode,
                    responseBody
                );
            }

            return ParseJsonOrThrow(
                "Gamenet",
                responseBody
            );
        }

        // =====================================================
        // SYNC GAMENET
        // =====================================================

        public async Task<GamenetSyncResponse> SyncAsync(
            int productId,
            string from,
            string to,
            CancellationToken cancellationToken = default)
        {
            EnsureAuthenticated();

            LastSyncRawResponse = null;
            LastSyncRequestUrl = null;

            if (productId <= 0)
            {
                throw new ArgumentException(
                    "شناسه گیمنت معتبر نیست.",
                    nameof(productId)
                );
            }

            if (string.IsNullOrWhiteSpace(from))
            {
                throw new ArgumentException(
                    "تاریخ شروع همگام‌سازی مشخص نشده است.",
                    nameof(from)
                );
            }

            if (string.IsNullOrWhiteSpace(to))
            {
                throw new ArgumentException(
                    "تاریخ پایان همگام‌سازی مشخص نشده است.",
                    nameof(to)
                );
            }

            string cacheBuster =
                DateTimeOffset.UtcNow
                    .ToUnixTimeMilliseconds()
                    .ToString();

            string requestUrl =
                "sync" +
                $"?product_id={Uri.EscapeDataString(productId.ToString())}" +
                $"&from={Uri.EscapeDataString(from)}" +
                $"&to={Uri.EscapeDataString(to)}" +
                $"&_nocache={Uri.EscapeDataString(cacheBuster)}";

            LastSyncRequestUrl =
                requestUrl;

            HttpResponseMessage response;
            try
            {
                response = await _httpClient.GetAsync(requestUrl, cancellationToken);
            }
            catch (HttpRequestException) when (!cancellationToken.IsCancellationRequested)
            {
                var cached = await LocalDatabase.Instance.GetSyncSnapshotAsync<GamenetSyncResponse>(productId, from, to, cancellationToken)
                    ?? await LocalDatabase.Instance.GetContainingSyncSnapshotAsync<GamenetSyncResponse>(productId, from, to, cancellationToken);
                if (cached is not null) return cached;
                throw new InvalidOperationException("اینترنت در دسترس نیست و اطلاعات ذخیره‌شده‌ای برای این بازه زمانی وجود ندارد.");
            }
            catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                var cached = await LocalDatabase.Instance.GetSyncSnapshotAsync<GamenetSyncResponse>(productId, from, to, cancellationToken)
                    ?? await LocalDatabase.Instance.GetContainingSyncSnapshotAsync<GamenetSyncResponse>(productId, from, to, cancellationToken);
                if (cached is not null) return cached;
                throw new InvalidOperationException("اتصال به سرور برقرار نشد و اطلاعات ذخیره‌شده‌ای برای این بازه زمانی وجود ندارد.");
            }

            using (response)
            {
                string responseBody = await response.Content.ReadAsStringAsync(cancellationToken);

                LastSyncRawResponse =
                    responseBody;

                if (!response.IsSuccessStatusCode)
                {
                    throw CreateApiException(
                        response.StatusCode,
                        responseBody
                    );
                }

                GamenetSyncResponse? result;

                try
                {
                    result =
                        JsonSerializer.Deserialize<GamenetSyncResponse>(
                            responseBody,
                            _jsonOptions
                        );
                }
                catch (JsonException ex)
                {
                    throw CreateJsonParseException(
                        "Sync",
                        responseBody,
                        ex
                    );
                }
                catch (Exception ex)
                {
                    throw new Exception(
                        "خطای غیرمنتظره هنگام پردازش پاسخ Sync.\n\n" +
                        $"نوع خطا: {ex.GetType().Name}\n\n" +
                        $"جزئیات:\n{ex.Message}\n\n" +
                        $"آدرس درخواست:\n{requestUrl}\n\n" +
                        "پاسخ خام سرور:\n" +
                        responseBody,
                        ex
                    );
                }

                if (result == null)
                {
                    throw new Exception(
                        "سرور پاسخ معتبری برای Sync ارسال نکرد.\n\n" +
                        $"آدرس درخواست:\n{requestUrl}\n\n" +
                        "پاسخ خام سرور:\n" +
                        responseBody
                    );
                }

                if (!result.Success)
                {
                    throw new Exception(
                        GetApiMessageFromJson(
                            responseBody,
                            "همگام‌سازی ناموفق بود."
                        ) +
                        "\n\n" +
                        $"آدرس درخواست:\n{requestUrl}\n\n" +
                        "پاسخ خام سرور:\n" +
                        responseBody
                    );
                }

                if (result.Data == null)
                {
                    throw new Exception(
                        "Sync موفق بود اما بخش Data در پاسخ سرور وجود ندارد.\n\n" +
                        $"آدرس درخواست:\n{requestUrl}\n\n" +
                        "پاسخ خام سرور:\n" +
                        responseBody
                    );
                }

                await LocalDatabase.Instance.SaveSyncSnapshotAsync(productId, from, to, result, result.SyncAt, cancellationToken);
                return result;
            }
        }
        // =====================================================
        // GET RESERVATIONS
        // =====================================================

        public async Task<List<ReservationItem>> GetReservationsAsync(
            int productId,
            string from,
            string to,
            CancellationToken cancellationToken = default)
        {
            EnsureAuthenticated();

            if (productId <= 0)
            {
                throw new ArgumentException(
                    "شناسه گیمنت معتبر نیست.",
                    nameof(productId)
                );
            }

            if (string.IsNullOrWhiteSpace(from))
            {
                throw new ArgumentException(
                    "تاریخ شروع مشخص نشده است.",
                    nameof(from)
                );
            }

            if (string.IsNullOrWhiteSpace(to))
            {
                throw new ArgumentException(
                    "تاریخ پایان مشخص نشده است.",
                    nameof(to)
                );
            }

            GamenetSyncResponse sync =
                await SyncAsync(
                    productId,
                    from,
                    to,
                    cancellationToken
                );

            return GetReservationsFromSync(sync);
        }

        // =====================================================
        // MAP RESERVATIONS FROM AN EXISTING SYNC RESPONSE
        // =====================================================

        public List<ReservationItem> GetReservationsFromSync(
            GamenetSyncResponse sync)
        {
            if (sync?.Data == null)
            {
                throw new ArgumentException(
                    "پاسخ Sync معتبر نیست یا بخش Data ندارد.",
                    nameof(sync)
                );
            }

            var reservations =
                new List<ReservationItem>();


            // =================================================
            // ONLINE BOOKINGS
            // =================================================

            if (sync.Data?.OnlineBookings != null)
            {
                int onlineBookingIndex = 0;

                foreach (OnlineBooking booking
                         in sync.Data.OnlineBookings)
                {
                    onlineBookingIndex++;

                    // OrderId is shared by every line item in one WooCommerce order.
                    // ItemId is the unique identity of each separately reserved device.
                    string onlineReservationId = booking.ItemId > 0
                        ? $"online:{booking.OrderId}:{booking.ItemId}"
                        : $"online:{booking.OrderId}:fallback:{onlineBookingIndex}";

                    reservations.Add(
                        new ReservationItem
                        {
                            Id = onlineReservationId,

                            Source = "online",

                            OrderId =
                                booking.OrderId,

                            ItemId =
                                booking.ItemId,

                            VariationId =
                                booking.VariationId > 0 ? booking.VariationId : booking.VarId,

                            Date =
                                booking.DateIso,

                            StartTime = booking.StartTime,
                            EndTime = booking.EndTime,
                            DurationMinutes = booking.DurationMinutes > 0 ? booking.DurationMinutes : Math.Max(1, booking.Hours) * 60,
                            Hours = booking.Hours,

                            Quantity = 1,

                            Customer =
                                booking.Customer,

                            Phone =
                                booking.Phone,

                            Amount =
                                booking.Amount,

                            Status = booking.Status,
                            OperatorStatus = booking.OperatorStatus,

                            CreatedAt =
                                string.Empty,

                            Note =
                                string.Empty,

                            Systems = !string.IsNullOrWhiteSpace(booking.SystemNumber)
                                ? new List<ReservationSystem>
                                {
                                    new ReservationSystem
                                    {
                                        VariationId = booking.VariationId > 0 ? booking.VariationId : booking.VarId,
                                        Quantity = 1,
                                        SystemNumber = booking.SystemNumber,
                                        GameId = booking.GameId,
                                        GameName = booking.GameName
                                    }
                                }
                                : new List<ReservationSystem>()
                        }
                    );
                }
            }


            // =================================================
            // MANUAL BOOKINGS
            // =================================================

            if (sync.Data?.ManualBookings != null)
            {
                foreach (ManualBooking booking
                         in sync.Data.ManualBookings)
                {
                    int firstVariationId = 0;
                    int totalQuantity = 0;
                    var allHours =
                        new List<string>();

                    if (booking.Systems != null)
                    {
                        foreach (ManualBookingSystem system
                                 in booking.Systems)
                        {
                            if (firstVariationId == 0)
                            {
                                firstVariationId =
                                    system.VariationId;
                            }

                            totalQuantity +=
                                system.Quantity;

                            if (system.Hours != null)
                            {
                                foreach (string hour
         in system.Hours)
                                {
                                    string hourText =
                                        hour.PadLeft(
                                            2,
                                            '0'
                                        );

                                    if (!allHours.Contains(
                                            hourText))
                                    {
                                        allHours.Add(
                                            hourText
                                        );
                                    }
                                }
                            }
                        }
                    }

                    allHours.Sort();


                    string startTime =
                        allHours.Count > 0
                            ? allHours[0] + ":00"
                            : string.Empty;


                    int bookingHours =
                        allHours.Count;


                    reservations.Add(
                        new ReservationItem
                        {
                            Id =
                                booking.Id,

                            Source =
                                "manual",

                            OrderId =
                                0,

                            ItemId =
                                0,

                            VariationId =
                                firstVariationId,

                            Date =
                                booking.Date,

                            StartTime = !string.IsNullOrWhiteSpace(booking.StartTime) ? booking.StartTime : startTime,
                            EndTime = booking.EndTime,
                            DurationMinutes = booking.DurationMinutes > 0 ? booking.DurationMinutes : bookingHours * 60,
                            Hours = booking.HoursCount > 0 ? booking.HoursCount : bookingHours,

                            Quantity =
                                totalQuantity,

                            Customer =
                                booking.Customer,

                            Phone =
                                booking.Phone,

                            Amount =
                                booking.Amount,

                            Status =
                                "manual",

                            CreatedAt =
                                booking.CreatedAt,

                            Note =
                                booking.Note,

                            Systems =
                                ConvertManualSystems(
                                    booking.Systems
                                )
                        }
                    );
                }
            }


            // =================================================
            // SORT
            // =================================================

            reservations.Sort(
                (a, b) =>
                {
                    int dateCompare =
                        string.Compare(
                            a.Date,
                            b.Date,
                            StringComparison.Ordinal
                        );

                    if (dateCompare != 0)
                    {
                        return dateCompare;
                    }

                    return string.Compare(
                        a.StartTime,
                        b.StartTime,
                        StringComparison.Ordinal
                    );
                }
            );

            return reservations;
        }





        // =====================================================
        // CONVERT MANUAL SYSTEMS
        // =====================================================

        private static List<ReservationSystem>
            ConvertManualSystems(
                List<ManualBookingSystem>? systems)
        {
            var result =
                new List<ReservationSystem>();

            if (systems == null)
            {
                return result;
            }

            foreach (ManualBookingSystem system
                     in systems)
            {
                result.Add(
                    new ReservationSystem
                    {
                        VariationId =
                            system.VariationId,

                        Quantity =
                            system.Quantity,

                        SystemNumber = system.SystemNumber,
                        GameId = system.GameId,
                        GameName = system.GameName,

                        Hours =
    system.Hours
        ?.ConvertAll(
            hour =>
                hour.PadLeft(
                    2,
                    '0'
                )
        )
    ?? new List<string>()
                    }
                );
            }

            return result;
        }
        // =====================================================
        // AVAILABILITY
        // =====================================================


        public async Task<AvailabilityResponse> GetAvailabilityAsync(
            int productId,
            int variationId,
            string date,
            CancellationToken cancellationToken = default)
        {
            EnsureAuthenticated();

            if (productId <= 0)
            {
                throw new ArgumentException(
                    "شناسه گیمنت معتبر نیست.",
                    nameof(productId)
                );
            }

            if (variationId <= 0)
            {
                throw new ArgumentException(
                    "شناسه سیستم معتبر نیست.",
                    nameof(variationId)
                );
            }

            if (string.IsNullOrWhiteSpace(date))
            {
                throw new ArgumentException(
                    "تاریخ معتبر نیست.",
                    nameof(date)
                );
            }

            string cacheBuster = DateTimeOffset.UtcNow
                .ToUnixTimeMilliseconds()
                .ToString();

            string requestUrl =
                "availability" +
                $"?product_id={Uri.EscapeDataString(productId.ToString())}" +
                $"&variation_id={Uri.EscapeDataString(variationId.ToString())}" +
                $"&date={Uri.EscapeDataString(date)}" +
                $"&_nocache={Uri.EscapeDataString(cacheBuster)}";

            HttpResponseMessage networkResponse;
            try
            {
                networkResponse = await _httpClient.GetAsync(requestUrl, cancellationToken);
            }
            catch (HttpRequestException) when (!cancellationToken.IsCancellationRequested)
            {
                var cached = await LocalDatabase.Instance.GetEntityAsync<AvailabilityResponse>(
                    "Availability", variationId.ToString() + ":" + date, productId, cancellationToken);
                if (cached != null) return cached;
                throw new InvalidOperationException("اینترنت در دسترس نیست و ظرفیت ذخیره‌شده‌ای برای این تاریخ وجود ندارد.");
            }
            catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                var cached = await LocalDatabase.Instance.GetEntityAsync<AvailabilityResponse>(
                    "Availability", variationId.ToString() + ":" + date, productId, cancellationToken);
                if (cached != null) return cached;
                throw new InvalidOperationException("اتصال به سرور برقرار نشد و ظرفیت ذخیره‌شده‌ای برای این تاریخ وجود ندارد.");
            }
            using HttpResponseMessage response = networkResponse;

            string responseBody =
                await response.Content.ReadAsStringAsync(
                    cancellationToken
                );

            if (!response.IsSuccessStatusCode)
            {
                throw CreateApiException(
                    response.StatusCode,
                    responseBody
                );
            }

            AvailabilityResponse? result;

            try
            {
                result =
                    JsonSerializer.Deserialize<AvailabilityResponse>(
                        responseBody,
                        _jsonOptions
                    );
            }
            catch (JsonException ex)
            {
                throw CreateJsonParseException(
                    "Availability",
                    responseBody,
                    ex
                );
            }
            catch (Exception ex)
            {
                throw new Exception(
                    "خطای غیرمنتظره هنگام پردازش پاسخ Availability.\n\n" +
                    $"نوع خطا: {ex.GetType().Name}\n\n" +
                    $"جزئیات:\n{ex.Message}\n\n" +
                    "پاسخ خام سرور:\n" +
                    responseBody,
                    ex
                );
            }

            if (result == null)
            {
                throw new Exception(
                    "سرور پاسخ معتبری برای Availability ارسال نکرد.\n\n" +
                    "پاسخ خام سرور:\n" +
                    responseBody
                );
            }

            if (!result.Success)
            {
                throw new Exception(
                    GetApiMessageFromJson(
                        responseBody,
                        "دریافت Availability ناموفق بود."
                    )
                );
            }

            if (result.Availability == null)
            {
                throw new Exception(
                    "پاسخ Availability موفق بود اما اطلاعات ظرفیت وجود نداشت.\n\n" +
                    "پاسخ خام سرور:\n" +
                    responseBody
                );
            }




            await LocalDatabase.Instance.PutEntityAsync(
                "Availability", variationId.ToString() + ":" + date, productId, result, 0, "Synced", cancellationToken);
            return result;
        }


        // =====================================================
        // CREATE BOOKING
        // =====================================================

        public async Task<BookingCreateResponse> CreateBookingAsync(
            BookingCreateRequest request,
            CancellationToken cancellationToken = default)
        {
            return await CreateBookingAsync(
                request,
                null,
                cancellationToken
            );
        }

        // =====================================================
        // CREATE BOOKING WITH IDEMPOTENCY KEY
        // =====================================================

        public async Task<BookingCreateResponse> CreateBookingAsync(
            BookingCreateRequest request,
            string? idempotencyKey,
            CancellationToken cancellationToken = default)
        {
            EnsureAuthenticated();

            ValidateBookingRequest(
                request
            );

            string finalIdempotencyKey =
                string.IsNullOrWhiteSpace(idempotencyKey)
                    ? Guid.NewGuid().ToString("N")
                    : idempotencyKey.Trim();

            ValidateIdempotencyKey(
                finalIdempotencyKey
            );

            string requestBody =
                JsonSerializer.Serialize(
                    request,
                    _jsonOptions
                );

            using HttpRequestMessage httpRequest =
                new HttpRequestMessage(
                    HttpMethod.Post,
                    "booking/create"
                );

            httpRequest.Content =
                new StringContent(
                    requestBody,
                    Encoding.UTF8,
                    "application/json"
                );

            httpRequest.Headers.TryAddWithoutValidation(
                "X-Lobix-Idempotency-Key",
                finalIdempotencyKey
            );

            using HttpResponseMessage response =
                await _httpClient.SendAsync(
                    httpRequest,
                    cancellationToken
                );

            string responseBody =
                await response.Content.ReadAsStringAsync(
                    cancellationToken
                );

            if (!response.IsSuccessStatusCode)
            {
                throw CreateApiException(
                    response.StatusCode,
                    responseBody
                );
            }

            BookingCreateResponse? result;

            try
            {
                result =
                    JsonSerializer.Deserialize<BookingCreateResponse>(
                        responseBody,
                        _jsonOptions
                    );
            }
            catch (JsonException ex)
            {
                throw CreateJsonParseException(
                    "ثبت رزرو",
                    responseBody,
                    ex
                );
            }
            catch (Exception ex)
            {
                throw new Exception(
                    "خطای غیرمنتظره هنگام پردازش پاسخ ثبت رزرو.\n\n" +
                    $"نوع خطا: {ex.GetType().Name}\n\n" +
                    $"جزئیات:\n{ex.Message}\n\n" +
                    "پاسخ خام سرور:\n" +
                    responseBody,
                    ex
                );
            }

            if (result == null)
            {
                throw new Exception(
                    "سرور پاسخ معتبری برای ثبت رزرو ارسال نکرد.\n\n" +
                    "پاسخ خام سرور:\n" +
                    responseBody
                );
            }

            if (!result.Success)
            {
                throw new Exception(
                    string.IsNullOrWhiteSpace(result.Message)
                        ? GetApiMessageFromJson(
                            responseBody,
                            "ثبت رزرو ناموفق بود."
                        )
                        : result.Message
                );
            }

            // API 2.2.2 returns the created booking identifier under data.booking_id
            // (not booking.id). Adapt that authoritative response to the app model.
            if (result.Booking == null)
            {
                try
                {
                    using JsonDocument responseDocument = JsonDocument.Parse(responseBody);
                    JsonElement root = responseDocument.RootElement;
                    JsonElement data = root;
                    if (root.TryGetProperty("data", out JsonElement dataElement) &&
                        dataElement.ValueKind == JsonValueKind.Object)
                    {
                        data = dataElement;
                    }

                    string bookingId = string.Empty;
                    if (data.TryGetProperty("booking_id", out JsonElement bookingIdElement))
                        bookingId = bookingIdElement.ToString();
                    if (string.IsNullOrWhiteSpace(bookingId) &&
                        data.TryGetProperty("id", out JsonElement idElement))
                        bookingId = idElement.ToString();

                    if (!string.IsNullOrWhiteSpace(bookingId))
                    {
                        result.Booking = new BookingCreateResult
                        {
                            Id = bookingId,
                            ProductId = request.ProductId,
                            Date = request.Date,
                            StartTime = request.StartTime,
                            EndTime = request.EndTime,
                            DurationMinutes = request.DurationMinutes,
                            Hours = request.Hours,
                            Customer = request.Customer,
                            CustomerId = request.CustomerId,
                            Phone = request.Phone,
                            Amount = request.Amount,
                            Note = request.Note,
                            Systems = request.Systems.Select(system => new BookingSystemResult
                            {
                                VariationId = system.VariationId,
                                Quantity = system.Quantity,
                                SystemNumber = system.SystemNumber,
                                GameId = system.GameId
                            }).ToList()
                        };
                    }
                }
                catch (JsonException)
                {
                    // The detailed error below includes the raw server response.
                }
            }

            if (result.Booking == null)
            {
                throw new Exception(
                    "ثبت رزرو موفق اعلام شد اما شناسه رزرو در پاسخ سرور پیدا نشد.\n\n" +
                    "پاسخ خام سرور:\n" +
                    responseBody
                );
            }

            return result;
        }

        // =====================================================
        // UPDATE MANUAL BOOKING
        // =====================================================

        public Task UpdateBookingAsync(
            int productId, string bookingId, BookingCreateRequest request,
            CancellationToken cancellationToken = default) =>
            UpdateBookingAsync(productId, bookingId, request, null, cancellationToken);

        public async Task UpdateBookingAsync(
            int productId,
            string bookingId,
            BookingCreateRequest request,
            string? idempotencyKey,
            CancellationToken cancellationToken = default)
        {
            EnsureAuthenticated();

            if (productId <= 0)
            {
                throw new ArgumentException(
                    "شناسه گیمنت معتبر نیست.",
                    nameof(productId)
                );
            }

            if (string.IsNullOrWhiteSpace(bookingId))
            {
                throw new ArgumentException(
                    "شناسه رزرو مشخص نشده است.",
                    nameof(bookingId)
                );
            }

            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            if (request.ProductId != productId)
            {
                throw new ArgumentException(
                    "شناسه گیمنت درخواست با گیمنت انتخاب‌شده یکسان نیست.",
                    nameof(request)
                );
            }

            ValidateBookingRequest(request);

            var requestData = new
            {
                product_id = productId,
                booking_id = bookingId.Trim(),
                date = request.Date,
                start_time = request.StartTime,
                end_time = request.EndTime,
                duration_minutes = request.DurationMinutes,
                hours = request.Hours,
                customer = request.Customer,
                phone = request.Phone,
                amount = request.Amount,
                note = request.Note,
                systems = request.Systems.ConvertAll(system => new
                {
                    variation_id = system.VariationId,
                    quantity = system.Quantity,
                    system_number = system.SystemNumber,
                    system_id = system.SystemId,
                    game_id = system.GameId
                })
            };

            string requestBody = JsonSerializer.Serialize(
                requestData,
                _jsonOptions
            );

            using HttpRequestMessage httpRequest = new HttpRequestMessage(
                HttpMethod.Post,
                "booking/update"
            );

            httpRequest.Content = new StringContent(
                requestBody,
                Encoding.UTF8,
                "application/json"
            );
            if (!string.IsNullOrWhiteSpace(idempotencyKey))
                httpRequest.Headers.TryAddWithoutValidation("X-Lobix-Idempotency-Key", idempotencyKey.Trim());

            using HttpResponseMessage response = await _httpClient.SendAsync(
                httpRequest,
                cancellationToken
            );

            string responseBody = await response.Content.ReadAsStringAsync(
                cancellationToken
            );

            if (!response.IsSuccessStatusCode)
            {
                throw CreateApiException(response.StatusCode, responseBody);
            }

            JsonDocument document;
            try
            {
                document = JsonDocument.Parse(responseBody);
            }
            catch (JsonException ex)
            {
                throw CreateJsonParseException(
                    "ویرایش رزرو",
                    responseBody,
                    ex
                );
            }

            JsonElement root = document.RootElement;
            if (!root.TryGetProperty("success", out JsonElement successElement) ||
                successElement.ValueKind != JsonValueKind.True)
            {
                string message = GetApiMessageFromJson(
                    responseBody,
                    "ویرایش رزرو ناموفق بود."
                );
                document.Dispose();
                throw new Exception(message + "\n\nپاسخ خام سرور:\n" + responseBody);
            }

            document.Dispose();
        }

        // =====================================================
        // SET ONLINE BOOKING DECISION (CONFIRM / REJECT)
        // =====================================================

        public Task<JsonDocument> SetBookingDecisionAsync(
            int productId,
            int orderId,
            string decision,
            string? decisionNote = null,
            CancellationToken cancellationToken = default)
        {
            return SetBookingDecisionCoreAsync(
                productId, orderId, decision, decisionNote, cancellationToken);
        }

        // Compatibility overload for callers that pass the cancellation token
        // immediately after the decision.
        public Task<JsonDocument> SetBookingDecisionAsync(
            int productId,
            int orderId,
            string decision,
            CancellationToken cancellationToken)
        {
            return SetBookingDecisionCoreAsync(
                productId, orderId, decision, null, cancellationToken);
        }

        private async Task<JsonDocument> SetBookingDecisionCoreAsync(
            int productId,
            int orderId,
            string decision,
            string? decisionNote,
            CancellationToken cancellationToken)
        {
            EnsureAuthenticated();

            if (productId <= 0)
                throw new ArgumentOutOfRangeException(nameof(productId), "شناسه گیمنت معتبر نیست.");
            if (orderId <= 0)
                throw new ArgumentOutOfRangeException(nameof(orderId), "شناسه سفارش معتبر نیست.");

            string normalizedDecision = (decision ?? string.Empty).Trim().ToLowerInvariant();
            if (normalizedDecision != "confirmed" && normalizedDecision != "rejected")
                throw new ArgumentException("تصمیم باید confirmed یا rejected باشد.", nameof(decision));

            var requestData = new
            {
                product_id = productId,
                order_id = orderId,
                decision = normalizedDecision,
                decision_note = decisionNote ?? string.Empty
            };

            using HttpRequestMessage request = new HttpRequestMessage(
                HttpMethod.Post, "booking/decision");
            request.Content = new StringContent(
                JsonSerializer.Serialize(requestData, _jsonOptions),
                Encoding.UTF8,
                "application/json");

            using HttpResponseMessage response = await _httpClient.SendAsync(
                request, cancellationToken);
            string responseBody = await response.Content.ReadAsStringAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
                throw CreateApiException(response.StatusCode, responseBody);

            JsonDocument document;
            try
            {
                document = JsonDocument.Parse(responseBody);
            }
            catch (JsonException ex)
            {
                throw CreateJsonParseException("تعیین تکلیف رزرو آنلاین", responseBody, ex);
            }

            if (!document.RootElement.TryGetProperty("success", out JsonElement success) ||
                success.ValueKind != JsonValueKind.True)
            {
                string message = GetApiMessageFromJson(
                    responseBody, "ثبت تصمیم رزرو آنلاین ناموفق بود.");
                document.Dispose();
                throw new Exception(message + "\n\nپاسخ خام سرور:\n" + responseBody);
            }

            return document;
        }

        // =====================================================
        // DELETE BOOKING
        // =====================================================

        public Task<JsonDocument> DeleteBookingAsync(
            int productId, string bookingId, CancellationToken cancellationToken = default) =>
            DeleteBookingAsync(productId, bookingId, null, cancellationToken);

        public async Task<JsonDocument> DeleteBookingAsync(
            int productId,
            string bookingId,
            string? idempotencyKey,
            CancellationToken cancellationToken = default)
        {
            EnsureAuthenticated();

            if (productId <= 0)
            {
                throw new ArgumentException(
                    "شناسه گیمنت معتبر نیست.",
                    nameof(productId)
                );
            }

            if (string.IsNullOrWhiteSpace(bookingId))
            {
                throw new ArgumentException(
                    "شناسه رزرو مشخص نشده است.",
                    nameof(bookingId)
                );
            }

            bookingId =
                bookingId.Trim();

            var requestData = new
            {
                product_id = productId,
                booking_id = bookingId
            };

            string requestBody =
                JsonSerializer.Serialize(
                    requestData,
                    _jsonOptions
                );

            using HttpRequestMessage httpRequest =
                new HttpRequestMessage(
                    HttpMethod.Post,
                    "booking/delete"
                );

            httpRequest.Content =
                new StringContent(
                    requestBody,
                    Encoding.UTF8,
                    "application/json"
                );
            if (!string.IsNullOrWhiteSpace(idempotencyKey))
                httpRequest.Headers.TryAddWithoutValidation("X-Lobix-Idempotency-Key", idempotencyKey.Trim());

            using HttpResponseMessage response =
                await _httpClient.SendAsync(
                    httpRequest,
                    cancellationToken
                );

            string responseBody =
                await response.Content.ReadAsStringAsync(
                    cancellationToken
                );

            if (!response.IsSuccessStatusCode)
            {
                throw CreateApiException(
                    response.StatusCode,
                    responseBody
                );
            }

            JsonDocument document;

            try
            {
                document =
                    JsonDocument.Parse(
                        responseBody
                    );
            }
            catch (JsonException ex)
            {
                throw CreateJsonParseException(
                    "حذف رزرو",
                    responseBody,
                    ex
                );
            }

            JsonElement root =
                document.RootElement;

            if (root.TryGetProperty(
                    "success",
                    out JsonElement successElement))
            {
                if (successElement.ValueKind ==
                    JsonValueKind.False)
                {
                    string message =
                        GetApiMessage(
                            root,
                            "حذف رزرو ناموفق بود."
                        );

                    document.Dispose();

                    throw new Exception(
                        message
                    );
                }
            }

            return document;
        }

        // =====================================================
        // LOGOUT
        // =====================================================

        public async Task LogoutAsync(
            CancellationToken cancellationToken = default)
        {
            if (!IsAuthenticated)
            {
                return;
            }

            try
            {
                using HttpResponseMessage response =
                    await _httpClient.PostAsync(
                        "logout",
                        null,
                        cancellationToken
                    );
            }
            finally
            {
                ClearAuthentication();
            }
        }

        // =====================================================
        // CLEAR AUTHENTICATION
        // =====================================================

        public void ClearAuthentication()
        {
            Token = null;

            _httpClient.DefaultRequestHeaders.Authorization =
                null;

            LastSyncRawResponse = null;
            LastSyncRequestUrl = null;
        }

        // =====================================================
        // CONNECTION TEST
        // =====================================================

        public async Task<bool> CheckConnectionAsync(
            CancellationToken cancellationToken = default)
        {
            try
            {
                EnsureAuthenticated();

                using HttpResponseMessage response =
                    await _httpClient.GetAsync(
                        "me",
                        cancellationToken
                    );

                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        // =====================================================
        // BOOKING VALIDATION
        // =====================================================

        private static void ValidateBookingRequest(
            BookingCreateRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(
                    nameof(request)
                );
            }

            if (request.ProductId <= 0)
            {
                throw new ArgumentException(
                    "شناسه گیمنت معتبر نیست.",
                    nameof(request)
                );
            }

            if (string.IsNullOrWhiteSpace(request.Date))
            {
                throw new ArgumentException(
                    "تاریخ رزرو مشخص نشده است.",
                    nameof(request)
                );
            }

            if (string.IsNullOrWhiteSpace(request.StartTime))
            {
                throw new ArgumentException(
                    "ساعت شروع رزرو مشخص نشده است.",
                    nameof(request)
                );
            }

            if (!TimeSpan.TryParse(
                    request.StartTime,
                    out TimeSpan startTime))
            {
                throw new ArgumentException(
                    "ساعت شروع رزرو معتبر نیست.",
                    nameof(request)
                );
            }

            if (startTime.TotalMinutes < 0 ||
                startTime.TotalMinutes >= 24 * 60)
            {
                throw new ArgumentException(
                    "ساعت شروع رزرو خارج از محدوده معتبر است.",
                    nameof(request)
                );
            }

            int durationMinutes = request.DurationMinutes > 0
                ? request.DurationMinutes
                : request.Hours * 60;
            if (durationMinutes < 5 || durationMinutes > 24 * 60 ||
                startTime.TotalMinutes + durationMinutes > 24 * 60)
            {
                throw new ArgumentException(
                    "مدت رزرو باید حداقل ۵ دقیقه و حداکثر تا پایان همان روز باشد.",
                    nameof(request)
                );
            }
            if (!string.IsNullOrWhiteSpace(request.EndTime) &&
                TimeSpan.TryParse(request.EndTime, out TimeSpan endTime) &&
                Math.Abs((endTime - startTime).TotalMinutes - durationMinutes) > 0.1)
            {
                throw new ArgumentException(
                    "ساعت پایان با مدت رزرو مطابقت ندارد.",
                    nameof(request)
                );
            }

            if (string.IsNullOrWhiteSpace(request.Customer))
            {
                throw new ArgumentException(
                    "نام مشتری مشخص نشده است.",
                    nameof(request)
                );
            }

            // Phone is optional in the WordPress API. Validate its format only
            // when the operator actually supplied a phone number.
            if (!string.IsNullOrWhiteSpace(request.Phone) &&
                (request.Phone.Length != 11 || !request.Phone.StartsWith("09", StringComparison.Ordinal)))
            {
                throw new ArgumentException(
                    "شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.",
                    nameof(request)
                );
            }

            if (request.Amount < 0)
            {
                throw new ArgumentException(
                    "مبلغ رزرو نمی‌تواند منفی باشد.",
                    nameof(request)
                );
            }

            if (request.Systems == null ||
                request.Systems.Count == 0)
            {
                throw new ArgumentException(
                    "حداقل یک سیستم برای رزرو باید انتخاب شود.",
                    nameof(request)
                );
            }

            foreach (BookingSystemRequest system
                     in request.Systems)
            {
                if (system == null)
                {
                    throw new ArgumentException(
                        "اطلاعات یکی از سیستم‌های رزرو معتبر نیست.",
                        nameof(request)
                    );
                }

                // WooCommerce variable products use a positive variation ID.
                // A simple product is represented by variation_id = 0 in the
                // WordPress API, so zero must remain valid for that product type.
                if (system.VariationId < 0)
                {
                    throw new ArgumentException(
                        "شناسه سیستم رزرو معتبر نیست.",
                        nameof(request)
                    );
                }

                if (system.Quantity <= 0)
                {
                    throw new ArgumentException(
                        "تعداد سیستم باید بیشتر از صفر باشد.",
                        nameof(request)
                    );
                }
            }
        }

        // =====================================================
        // IDEMPOTENCY KEY VALIDATION
        // =====================================================

        private static void ValidateIdempotencyKey(
            string idempotencyKey)
        {
            if (string.IsNullOrWhiteSpace(
                    idempotencyKey))
            {
                throw new ArgumentException(
                    "Idempotency Key معتبر نیست.",
                    nameof(idempotencyKey)
                );
            }

            if (idempotencyKey.Length > 128)
            {
                throw new ArgumentException(
                    "Idempotency Key نمی‌تواند بیشتر از ۱۲۸ کاراکتر باشد.",
                    nameof(idempotencyKey)
                );
            }

            foreach (char character in idempotencyKey)
            {
                bool valid =
                    char.IsLetterOrDigit(character) ||
                    character == '.' ||
                    character == '_' ||
                    character == ':' ||
                    character == '-';

                if (!valid)
                {
                    throw new ArgumentException(
                        "Idempotency Key شامل کاراکتر غیرمجاز است.",
                        nameof(idempotencyKey)
                    );
                }
            }
        }

        // =====================================================
        // AUTHENTICATION CHECK
        // =====================================================

        private void EnsureAuthenticated()
        {
            if (!IsAuthenticated)
            {
                throw new InvalidOperationException(
                    "برای انجام این درخواست ابتدا باید وارد حساب شوید."
                );
            }
        }

        // =====================================================
        // JSON PARSE
        // =====================================================

        private static JsonDocument ParseJsonOrThrow(
            string operationName,
            string responseBody)
        {
            try
            {
                return JsonDocument.Parse(
                    responseBody
                );
            }
            catch (JsonException ex)
            {
                throw CreateJsonParseException(
                    operationName,
                    responseBody,
                    ex
                );
            }
        }

        // =====================================================
        // JSON STRING HELPER
        // =====================================================

        private static string GetString(
            JsonElement element,
            string propertyName)
        {
            if (!element.TryGetProperty(
                    propertyName,
                    out JsonElement value))
            {
                return string.Empty;
            }

            return value.ValueKind ==
                   JsonValueKind.String
                ? value.GetString() ?? string.Empty
                : value.ToString();
        }

        // =====================================================
        // JSON INT HELPER
        // =====================================================

        private static int GetInt(
            JsonElement element,
            string propertyName)
        {
            if (!element.TryGetProperty(
                    propertyName,
                    out JsonElement value))
            {
                return 0;
            }

            if (value.ValueKind ==
                    JsonValueKind.Number &&
                value.TryGetInt32(
                    out int number))
            {
                return number;
            }

            if (int.TryParse(
                    value.ToString(),
                    out int parsed))
            {
                return parsed;
            }

            return 0;
        }

        // =====================================================
        // API MESSAGE HELPER
        // =====================================================

        private static string GetApiMessage(
            JsonElement root,
            string fallback)
        {
            if (root.TryGetProperty(
                    "message",
                    out JsonElement message))
            {
                string text =
                    message.ToString();

                if (!string.IsNullOrWhiteSpace(
                        text))
                {
                    return text;
                }
            }

            return fallback;
        }

        // =====================================================
        // API MESSAGE FROM JSON
        // =====================================================

        private static string GetApiMessageFromJson(
            string responseBody,
            string fallback)
        {
            try
            {
                using JsonDocument document =
                    JsonDocument.Parse(
                        responseBody
                    );

                return GetApiMessage(
                    document.RootElement,
                    fallback
                );
            }
            catch
            {
                return fallback;
            }
        }

        // =====================================================
        // JSON PARSE EXCEPTION
        // =====================================================

        private static Exception CreateJsonParseException(
            string operationName,
            string responseBody,
            JsonException ex)
        {
            string path =
                string.IsNullOrWhiteSpace(ex.Path)
                    ? "(نامشخص)"
                    : ex.Path;

            string line =
                ex.LineNumber.HasValue
                    ? ex.LineNumber.Value.ToString()
                    : "(نامشخص)";

            string position =
                ex.BytePositionInLine.HasValue
                    ? ex.BytePositionInLine.Value.ToString()
                    : "(نامشخص)";

            return new Exception(
                $"پاسخ {operationName} سرور قابل تبدیل به مدل C# نیست.\n\n" +

                "جزئیات خطا:\n" +
                $"{ex.Message}\n\n" +

                "مسیر فیلد مشکل‌دار:\n" +
                $"{path}\n\n" +

                $"شماره خط: {line}\n" +
                $"موقعیت: {position}\n\n" +

                "پاسخ خام سرور:\n" +
                responseBody,
                ex
            );
        }

        // =====================================================
        // API EXCEPTION
        // =====================================================

        private static Exception CreateApiException(
            HttpStatusCode statusCode,
            string responseBody)
        {
            string message =
                "خطا در درخواست به سرور لابیکس.\n" +
                $"HTTP: {(int)statusCode} ({statusCode})";

            if (!string.IsNullOrWhiteSpace(responseBody))
            {
                try
                {
                    using JsonDocument document =
                        JsonDocument.Parse(responseBody);

                    JsonElement root =
                        document.RootElement;

                    string apiMessage =
                        GetApiMessage(
                            root,
                            string.Empty
                        );

                    if (!string.IsNullOrWhiteSpace(apiMessage))
                    {
                        message +=
                            "\n\nپیام سرور:\n" +
                            apiMessage;
                    }

                    if (root.TryGetProperty(
                            "code",
                            out JsonElement codeElement))
                    {
                        string code =
                            codeElement.ToString();

                        if (!string.IsNullOrWhiteSpace(code))
                        {
                            message +=
                                "\n\nکد خطای سرور:\n" +
                                code;
                        }
                    }
                }
                catch
                {
                    // پاسخ JSON معتبر نبود.
                }

                message +=
                    "\n\nپاسخ خام سرور:\n" +
                    responseBody;
            }

            return new HttpRequestException(
                message,
                null,
                statusCode
            );
        }

        public void Dispose()
        {
            _httpClient.Dispose();
        }
    }
}
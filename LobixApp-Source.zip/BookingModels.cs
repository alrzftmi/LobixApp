using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace LobixApp.Models
{
    // =========================================================
    // BOOKING CREATE REQUEST
    // =========================================================

    public class BookingCreateRequest
    {
        [JsonPropertyName("product_id")]
        public int ProductId { get; set; }

        [JsonPropertyName("date")]
        public string Date { get; set; } = string.Empty;

        [JsonPropertyName("start_time")]
        public string StartTime { get; set; } = string.Empty;

        // Legacy whole-hour duration. New clients also send exact end_time and duration_minutes.
        [JsonPropertyName("hours")]
        public int Hours { get; set; }

        [JsonPropertyName("end_time")]
        public string EndTime { get; set; } = string.Empty;

        [JsonPropertyName("duration_minutes")]
        public int DurationMinutes { get; set; }

        [JsonPropertyName("customer")]
        public string Customer { get; set; } = string.Empty;

        [JsonPropertyName("customer_id")]
        public string CustomerId { get; set; } = string.Empty;

        [JsonPropertyName("phone")]
        public string Phone { get; set; } = string.Empty;

        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }

        [JsonPropertyName("note")]
        public string Note { get; set; } = string.Empty;

        [JsonPropertyName("systems")]
        public List<BookingSystemRequest> Systems { get; set; } = new();
    }

    // =========================================================
    // BOOKING SYSTEM REQUEST
    // =========================================================


    public class BookingSystemRequest
    {
        [JsonPropertyName("variation_id")]
        public int VariationId { get; set; }

        [JsonPropertyName("quantity")]
        public int Quantity { get; set; }

        [JsonPropertyName("system_number")]
        public string SystemNumber { get; set; } = string.Empty;

        [JsonPropertyName("system_id")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string? SystemId { get; set; }

        [JsonPropertyName("game_id")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public int? GameId { get; set; }
    }


    // =========================================================
    // BOOKING CREATE RESPONSE
    // =========================================================

    public class BookingCreateResponse
    {
        [JsonPropertyName("success")]
        public bool Success { get; set; }

        [JsonPropertyName("api_version")]
        public string ApiVersion { get; set; } = string.Empty;

        [JsonPropertyName("message")]
        public string Message { get; set; } = string.Empty;

        [JsonPropertyName("booking")]
        public BookingCreateResult? Booking { get; set; }

        [JsonPropertyName("server_time")]
        public string ServerTime { get; set; } = string.Empty;
    }

    // =========================================================
    // CREATED BOOKING
    // =========================================================

    public class BookingCreateResult
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;

        [JsonPropertyName("product_id")]
        public int ProductId { get; set; }

        [JsonPropertyName("date")]
        public string Date { get; set; } = string.Empty;

        [JsonPropertyName("start_time")]
        public string StartTime { get; set; } = string.Empty;

        [JsonPropertyName("hours")]
        public int Hours { get; set; }

        [JsonPropertyName("end_time")]
        public string EndTime { get; set; } = string.Empty;

        [JsonPropertyName("duration_minutes")]
        public int DurationMinutes { get; set; }

        [JsonPropertyName("customer")]
        public string Customer { get; set; } = string.Empty;

        [JsonPropertyName("customer_id")]
        public string CustomerId { get; set; } = string.Empty;

        [JsonPropertyName("phone")]
        public string Phone { get; set; } = string.Empty;

        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }

        [JsonPropertyName("note")]
        public string Note { get; set; } = string.Empty;

        [JsonPropertyName("systems")]
        public List<BookingSystemResult> Systems { get; set; } = new();

        [JsonPropertyName("source")]
        public string Source { get; set; } = string.Empty;
    }

    // =========================================================
    // CREATED BOOKING SYSTEM
    // =========================================================

    public class BookingSystemResult
    {
        [JsonPropertyName("variation_id")]
        public int VariationId { get; set; }

        [JsonPropertyName("quantity")]
        public int Quantity { get; set; }

        [JsonPropertyName("system_number")]
        public string SystemNumber { get; set; } = string.Empty;

        [JsonPropertyName("game_id")]
        public int? GameId { get; set; }
    }
}
// =========================================================
// RESERVATION LIST ITEM
// =========================================================

public class ReservationItem
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    [JsonPropertyName("source")]
    public string Source { get; set; } = string.Empty;

    [JsonPropertyName("order_id")]
    public int OrderId { get; set; }

    [JsonPropertyName("item_id")]
    public int ItemId { get; set; }

    [JsonPropertyName("variation_id")]
    public int VariationId { get; set; }

    [JsonPropertyName("date")]
    public string Date { get; set; } = string.Empty;

    [JsonPropertyName("start_time")]
    public string StartTime { get; set; } = string.Empty;

    [JsonPropertyName("hours")]
    public int Hours { get; set; }

    [JsonPropertyName("end_time")]
    public string EndTime { get; set; } = string.Empty;

    [JsonPropertyName("duration_minutes")]
    public int DurationMinutes { get; set; }

    [JsonPropertyName("quantity")]
    public int Quantity { get; set; }

    [JsonPropertyName("customer")]
    public string Customer { get; set; } = string.Empty;

    [JsonPropertyName("phone")]
    public string Phone { get; set; } = string.Empty;

    [JsonPropertyName("amount")]
    public decimal Amount { get; set; }

    [JsonPropertyName("status")]
    public string Status { get; set; } = string.Empty;

    [JsonPropertyName("operator_status")]
    public string OperatorStatus { get; set; } = string.Empty;

    // Legacy field used by reservation lists and system-type filters.
    [JsonPropertyName("system_type")]
    public string SystemType { get; set; } = string.Empty;

    [JsonIgnore]
    public string LocalSyncState { get; set; } = "Synced";

    [JsonPropertyName("created_at")]
    public string CreatedAt { get; set; } = string.Empty;

    [JsonPropertyName("note")]
    public string Note { get; set; } = string.Empty;

    [JsonPropertyName("systems")]
    public List<ReservationSystem> Systems { get; set; } = new();
}


// =========================================================
// RESERVATION SYSTEM
// =========================================================

public class ReservationSystem
{
    [JsonPropertyName("variation_id")]
    public int VariationId { get; set; }

    [JsonPropertyName("quantity")]
    public int Quantity { get; set; }

    [JsonPropertyName("system_number")]
    public string SystemNumber { get; set; } = string.Empty;

    [JsonPropertyName("game_id")]
    public int GameId { get; set; }

    [JsonPropertyName("game_name")]
    public string GameName { get; set; } = string.Empty;

    [JsonPropertyName("hours")]
    public List<string> Hours { get; set; } = new();
}
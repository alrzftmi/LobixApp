using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Text.Json;
using Microsoft.Data.Sqlite;


namespace LobixApp.Services;

public sealed record LocalEntityRecord<T>(string EntityType, string EntityId, int ProductId, T Payload, long Revision, bool IsDeleted, string SyncState, DateTimeOffset UpdatedAtUtc);

/// <summary>SQLite storage owned by the current Windows user. All SQL values are parameterized.</summary>
public sealed class LocalDatabase
{
    private static readonly Lazy<LocalDatabase> LazyInstance = new(() => new LocalDatabase());
    public static LocalDatabase Instance => LazyInstance.Value;

    private readonly string _connectionString;
    private readonly SemaphoreSlim _initializeLock = new(1, 1);
    private bool _initialized;
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private LocalDatabase()
    {
        var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Lobix", "Data");
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, "lobix-local.db");
        _connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = path,
            Mode = SqliteOpenMode.ReadWriteCreate,
            Cache = SqliteCacheMode.Shared,
            Pooling = true,
            ForeignKeys = true
        }.ToString();
    }

    public string DatabasePath => new SqliteConnectionStringBuilder(_connectionString).DataSource;

    public async Task InitializeAsync(CancellationToken ct = default)
    {
        if (_initialized) return;
        await _initializeLock.WaitAsync(ct);
        try
        {
            if (_initialized) return;
            await using var db = new SqliteConnection(_connectionString);
            await db.OpenAsync(ct);
            await using (var pragmas = db.CreateCommand())
            {
                pragmas.CommandText = "PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=10000;";
                await pragmas.ExecuteNonQueryAsync(ct);
            }
            await using var cmd = db.CreateCommand();
            cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS SchemaInfo(Id INTEGER PRIMARY KEY CHECK(Id=1), Version INTEGER NOT NULL);
INSERT OR IGNORE INTO SchemaInfo(Id,Version) VALUES(1,4);
CREATE TABLE IF NOT EXISTS LocalEntities(
 EntityType TEXT NOT NULL, EntityId TEXT NOT NULL, ProductId INTEGER NOT NULL DEFAULT 0,
 Payload TEXT NOT NULL, Revision INTEGER NOT NULL DEFAULT 0, IsDeleted INTEGER NOT NULL DEFAULT 0,
 UpdatedAtUtc TEXT NOT NULL, SyncState TEXT NOT NULL DEFAULT 'Synced',
 PRIMARY KEY(EntityType,EntityId,ProductId));
CREATE INDEX IF NOT EXISTS IX_LocalEntities_Product ON LocalEntities(ProductId,EntityType);
CREATE TABLE IF NOT EXISTS SyncSnapshots(
 ProductId INTEGER NOT NULL, DateFrom TEXT NOT NULL, DateTo TEXT NOT NULL,
 Payload TEXT NOT NULL, ServerSyncAt REAL NOT NULL DEFAULT 0, SavedAtUtc TEXT NOT NULL,
 PRIMARY KEY(ProductId,DateFrom,DateTo));
CREATE TABLE IF NOT EXISTS Outbox(
 OperationId TEXT PRIMARY KEY, DeviceId TEXT NOT NULL, ProductId INTEGER NOT NULL,
 EntityType TEXT NOT NULL, EntityId TEXT NOT NULL, OperationType TEXT NOT NULL,
 BaseRevision INTEGER NOT NULL DEFAULT 0, Payload TEXT NOT NULL,
 CreatedAtUtc TEXT NOT NULL, Status TEXT NOT NULL DEFAULT 'Pending',
 RetryCount INTEGER NOT NULL DEFAULT 0, LastAttemptUtc TEXT NULL, LastError TEXT NULL);
CREATE INDEX IF NOT EXISTS IX_Outbox_Status_Created ON Outbox(Status,CreatedAtUtc);
CREATE INDEX IF NOT EXISTS IX_Outbox_Entity ON Outbox(EntityType,EntityId,ProductId);
CREATE TABLE IF NOT EXISTS SyncState(
 ProductId INTEGER PRIMARY KEY, LastSuccessfulSyncUtc TEXT NULL,
 LastServerSyncAt REAL NOT NULL DEFAULT 0, LastError TEXT NULL);
CREATE TABLE IF NOT EXISTS Conflicts(
 ConflictId TEXT PRIMARY KEY, OperationId TEXT NOT NULL, ProductId INTEGER NOT NULL,
 EntityType TEXT NOT NULL, EntityId TEXT NOT NULL, LocalPayload TEXT NOT NULL,
 ServerPayload TEXT NOT NULL, LocalRevision INTEGER NOT NULL DEFAULT 0,
 ServerRevision INTEGER NOT NULL DEFAULT 0, CreatedAtUtc TEXT NOT NULL,
 Status TEXT NOT NULL DEFAULT 'Open', Resolution TEXT NULL);
CREATE INDEX IF NOT EXISTS IX_Conflicts_Status ON Conflicts(Status,CreatedAtUtc);
CREATE TABLE IF NOT EXISTS AppMetadata(Key TEXT PRIMARY KEY, Value TEXT NOT NULL, UpdatedAtUtc TEXT NOT NULL);
";
            await cmd.ExecuteNonQueryAsync(ct);
            // Additive migration for databases created by the earlier offline foundation.
            await EnsureColumnAsync(db, "Outbox", "DeviceId", "TEXT NOT NULL DEFAULT ''", ct);
            await EnsureColumnAsync(db, "Outbox", "BaseRevision", "INTEGER NOT NULL DEFAULT 0", ct);
            await EnsureColumnAsync(db, "Outbox", "LastAttemptUtc", "TEXT NULL", ct);
            await using var version = db.CreateCommand();
            version.CommandText = "UPDATE SchemaInfo SET Version=4 WHERE Id=1 AND Version<4;";
            await version.ExecuteNonQueryAsync(ct);
            _initialized = true;
        }
        finally { _initializeLock.Release(); }
    }

    private static async Task EnsureColumnAsync(SqliteConnection db, string table, string column, string definition, CancellationToken ct)
    {
        await using var check = db.CreateCommand();
        check.CommandText = $"PRAGMA table_info({table});";
        await using var reader = await check.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
            if (string.Equals(reader.GetString(1), column, StringComparison.OrdinalIgnoreCase)) return;
        await reader.DisposeAsync();
        await using var alter = db.CreateCommand();
        alter.CommandText = $"ALTER TABLE {table} ADD COLUMN {column} {definition};";
        await alter.ExecuteNonQueryAsync(ct);
    }

    public async Task PutEntityAsync<T>(string entityType, string entityId, int productId, T value, long revision = 0, string syncState = "Synced", CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(entityType) || string.IsNullOrWhiteSpace(entityId)) throw new ArgumentException("Entity type and ID are required.");
        await InitializeAsync(ct);
        await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand();
        cmd.CommandText = @"INSERT INTO LocalEntities(EntityType,EntityId,ProductId,Payload,Revision,IsDeleted,UpdatedAtUtc,SyncState)
VALUES($type,$id,$product,$payload,$revision,0,$now,$state)
ON CONFLICT(EntityType,EntityId,ProductId) DO UPDATE SET Payload=excluded.Payload,Revision=excluded.Revision,IsDeleted=0,UpdatedAtUtc=excluded.UpdatedAtUtc,SyncState=excluded.SyncState;";
        cmd.Parameters.AddWithValue("$type", entityType); cmd.Parameters.AddWithValue("$id", entityId); cmd.Parameters.AddWithValue("$product", productId);
        cmd.Parameters.AddWithValue("$payload", JsonSerializer.Serialize(value, JsonOptions)); cmd.Parameters.AddWithValue("$revision", revision);
        cmd.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O")); cmd.Parameters.AddWithValue("$state", syncState);
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<T?> GetEntityAsync<T>(string entityType, string entityId, int productId = 0, CancellationToken ct = default)
    {
        await InitializeAsync(ct); await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand(); cmd.CommandText = "SELECT Payload FROM LocalEntities WHERE EntityType=$type AND EntityId=$id AND ProductId=$product AND IsDeleted=0 LIMIT 1;";
        cmd.Parameters.AddWithValue("$type", entityType); cmd.Parameters.AddWithValue("$id", entityId); cmd.Parameters.AddWithValue("$product", productId);
        var result = await cmd.ExecuteScalarAsync(ct);
        return result is string json ? JsonSerializer.Deserialize<T>(json, JsonOptions) : default;
    }

    public async Task<IReadOnlyList<T>> GetEntitiesAsync<T>(string entityType, int productId = 0, CancellationToken ct = default)
    {
        await InitializeAsync(ct); var items = new List<T>();
        await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand(); cmd.CommandText = "SELECT Payload FROM LocalEntities WHERE EntityType=$type AND ProductId=$product AND IsDeleted=0 ORDER BY UpdatedAtUtc DESC;";
        cmd.Parameters.AddWithValue("$type", entityType); cmd.Parameters.AddWithValue("$product", productId);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) { var item = JsonSerializer.Deserialize<T>(reader.GetString(0), JsonOptions); if (item is not null) items.Add(item); }
        return items;
    }

    public async Task<string> EnqueueOperationAsync(int productId, string entityType, string entityId, string operationType, object payload, long baseRevision = 0, CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        var operationId = Guid.NewGuid().ToString("D");
        var deviceId = await GetOrCreateDeviceIdAsync(ct);
        await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand();
        cmd.CommandText = @"INSERT INTO Outbox(OperationId,DeviceId,ProductId,EntityType,EntityId,OperationType,BaseRevision,Payload,CreatedAtUtc,Status)
VALUES($op,$device,$product,$type,$entity,$operation,$revision,$payload,$now,'Pending');";
        cmd.Parameters.AddWithValue("$op", operationId); cmd.Parameters.AddWithValue("$device", deviceId); cmd.Parameters.AddWithValue("$product", productId);
        cmd.Parameters.AddWithValue("$type", entityType); cmd.Parameters.AddWithValue("$entity", entityId); cmd.Parameters.AddWithValue("$operation", operationType);
        cmd.Parameters.AddWithValue("$revision", baseRevision); cmd.Parameters.AddWithValue("$payload", JsonSerializer.Serialize(payload, JsonOptions));
        cmd.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O")); await cmd.ExecuteNonQueryAsync(ct);
        return operationId;
    }


    public async Task<int> GetPendingOperationCountAsync(
        int productId = 0,
        CancellationToken ct = default)
    {
        await InitializeAsync(ct);

        await using var db = new SqliteConnection(_connectionString);
        await db.OpenAsync(ct);

        await using var cmd = db.CreateCommand();

        cmd.CommandText = productId > 0
            ? "SELECT COUNT(*) FROM Outbox WHERE ProductId=$product AND Status IN ('Pending','Retry','Sending');"
            : "SELECT COUNT(*) FROM Outbox WHERE Status IN ('Pending','Retry','Sending');";

        if (productId > 0)
            cmd.Parameters.AddWithValue("$product", productId);

        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));
    }


    /// <summary>Atomically writes a local entity and its durable outbox operation.</summary>
    public async Task<string> SaveLocalChangeAsync<T>(int productId, string entityType, string entityId, T value,
        string operationType, long baseRevision = 0, CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        var operationId = Guid.NewGuid().ToString("D");
        var deviceId = await GetOrCreateDeviceIdAsync(ct);
        var now = DateTimeOffset.UtcNow.ToString("O");
        var payload = JsonSerializer.Serialize(value, JsonOptions);
        await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var tx = await db.BeginTransactionAsync(ct);
        await using (var entity = db.CreateCommand())
        {
            entity.Transaction = (SqliteTransaction)tx;
            entity.CommandText = @"INSERT INTO LocalEntities(EntityType,EntityId,ProductId,Payload,Revision,IsDeleted,UpdatedAtUtc,SyncState)
VALUES($type,$id,$product,$payload,$revision,0,$now,'Pending')
ON CONFLICT(EntityType,EntityId,ProductId) DO UPDATE SET Payload=excluded.Payload,Revision=excluded.Revision,IsDeleted=0,UpdatedAtUtc=excluded.UpdatedAtUtc,SyncState='Pending';";
            entity.Parameters.AddWithValue("$type", entityType); entity.Parameters.AddWithValue("$id", entityId); entity.Parameters.AddWithValue("$product", productId);
            entity.Parameters.AddWithValue("$payload", payload); entity.Parameters.AddWithValue("$revision", baseRevision); entity.Parameters.AddWithValue("$now", now);
            await entity.ExecuteNonQueryAsync(ct);
        }
        await using (var operation = db.CreateCommand())
        {
            operation.Transaction = (SqliteTransaction)tx;
            operation.CommandText = @"INSERT INTO Outbox(OperationId,DeviceId,ProductId,EntityType,EntityId,OperationType,BaseRevision,Payload,CreatedAtUtc,Status)
VALUES($op,$device,$product,$type,$id,$operation,$revision,$payload,$now,'Pending');";
            operation.Parameters.AddWithValue("$op", operationId); operation.Parameters.AddWithValue("$device", deviceId); operation.Parameters.AddWithValue("$product", productId);
            operation.Parameters.AddWithValue("$type", entityType); operation.Parameters.AddWithValue("$id", entityId); operation.Parameters.AddWithValue("$operation", operationType);
            operation.Parameters.AddWithValue("$revision", baseRevision); operation.Parameters.AddWithValue("$payload", payload); operation.Parameters.AddWithValue("$now", now);
            await operation.ExecuteNonQueryAsync(ct);
        }
        await tx.CommitAsync(ct);
        return operationId;
    }
    public async Task MarkLocalEntityDeletedAsync(
    int productId,
    string entityType,
    string entityId,
    CancellationToken ct = default)
    {
        await InitializeAsync(ct);

        await using var db = new SqliteConnection(_connectionString);
        await db.OpenAsync(ct);

        await using var cmd = db.CreateCommand();

        cmd.CommandText = @"
UPDATE LocalEntities
SET IsDeleted = 1,
    SyncState = 'Synced',
    UpdatedAtUtc = $now
WHERE ProductId = $product
  AND EntityType = $type
  AND EntityId = $id;
";

        cmd.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O"));
        cmd.Parameters.AddWithValue("$product", productId);
        cmd.Parameters.AddWithValue("$type", entityType);
        cmd.Parameters.AddWithValue("$id", entityId);

        await cmd.ExecuteNonQueryAsync(ct);
    }
    public async Task<string> DeleteLocalEntityAsync(int productId, string entityType, string entityId, long baseRevision = 0, CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        var operationId = Guid.NewGuid().ToString("D"); var deviceId = await GetOrCreateDeviceIdAsync(ct); var now = DateTimeOffset.UtcNow.ToString("O");
        await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct); await using var tx = await db.BeginTransactionAsync(ct);
        // A local create that has never reached the server can be cancelled locally; do not enqueue a delete for an ID that does not exist remotely.
        await using (var pendingCreate = db.CreateCommand())
        {
            pendingCreate.Transaction = (SqliteTransaction)tx;
            pendingCreate.CommandText = "SELECT OperationId FROM Outbox WHERE ProductId=$product AND EntityType=$type AND EntityId=$id AND OperationType='Create' AND Status IN ('Pending','Retry') LIMIT 1;";
            pendingCreate.Parameters.AddWithValue("$product", productId); pendingCreate.Parameters.AddWithValue("$type", entityType); pendingCreate.Parameters.AddWithValue("$id", entityId);
            var createId = await pendingCreate.ExecuteScalarAsync(ct) as string;
            if (!string.IsNullOrWhiteSpace(createId))
            {
                await using var cancel = db.CreateCommand(); cancel.Transaction = (SqliteTransaction)tx;
                cancel.CommandText = "DELETE FROM Outbox WHERE ProductId=$product AND EntityType=$type AND EntityId=$id AND Status IN ('Pending','Retry'); DELETE FROM LocalEntities WHERE ProductId=$product AND EntityType=$type AND EntityId=$id;";
                cancel.Parameters.AddWithValue("$product", productId); cancel.Parameters.AddWithValue("$type", entityType); cancel.Parameters.AddWithValue("$id", entityId);
                await cancel.ExecuteNonQueryAsync(ct); await tx.CommitAsync(ct); return createId;
            }
        }
        string payload;
        await using (var read = db.CreateCommand())
        {
            read.Transaction = (SqliteTransaction)tx; read.CommandText = "SELECT Payload FROM LocalEntities WHERE EntityType=$type AND EntityId=$id AND ProductId=$product LIMIT 1;";
            read.Parameters.AddWithValue("$type", entityType); read.Parameters.AddWithValue("$id", entityId); read.Parameters.AddWithValue("$product", productId);
            payload = (await read.ExecuteScalarAsync(ct)) as string ?? "null";
        }
        await using (var update = db.CreateCommand())
        {
            update.Transaction = (SqliteTransaction)tx; update.CommandText = "UPDATE LocalEntities SET IsDeleted=1,SyncState='Pending',UpdatedAtUtc=$now WHERE EntityType=$type AND EntityId=$id AND ProductId=$product;";
            update.Parameters.AddWithValue("$now", now); update.Parameters.AddWithValue("$type", entityType); update.Parameters.AddWithValue("$id", entityId); update.Parameters.AddWithValue("$product", productId);
            await update.ExecuteNonQueryAsync(ct);
        }
        await using (var operation = db.CreateCommand())
        {
            operation.Transaction = (SqliteTransaction)tx; operation.CommandText = @"INSERT INTO Outbox(OperationId,DeviceId,ProductId,EntityType,EntityId,OperationType,BaseRevision,Payload,CreatedAtUtc,Status)
VALUES($op,$device,$product,$type,$id,'Delete',$revision,$payload,$now,'Pending');";
            operation.Parameters.AddWithValue("$op", operationId); operation.Parameters.AddWithValue("$device", deviceId); operation.Parameters.AddWithValue("$product", productId);
            operation.Parameters.AddWithValue("$type", entityType); operation.Parameters.AddWithValue("$id", entityId); operation.Parameters.AddWithValue("$revision", baseRevision);
            operation.Parameters.AddWithValue("$payload", payload); operation.Parameters.AddWithValue("$now", now); await operation.ExecuteNonQueryAsync(ct);
        }
        await tx.CommitAsync(ct); return operationId;
    }

    public async Task<string> GetOrCreateDeviceIdAsync(CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        var created = Guid.NewGuid().ToString("D");
        await using var db = new SqliteConnection(_connectionString);
        await db.OpenAsync(ct);
        await using (var insert = db.CreateCommand())
        {
            insert.CommandText = "INSERT OR IGNORE INTO AppMetadata(Key,Value,UpdatedAtUtc) VALUES('DeviceId',$id,$now);";
            insert.Parameters.AddWithValue("$id", created);
            insert.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O"));
            await insert.ExecuteNonQueryAsync(ct);
        }
        await using var read = db.CreateCommand();
        read.CommandText = "SELECT Value FROM AppMetadata WHERE Key='DeviceId';";
        var value = await read.ExecuteScalarAsync(ct) as string;
        if (string.IsNullOrWhiteSpace(value)) throw new InvalidOperationException("شناسه دستگاه ساخته نشد.");
        return value;
    }

    public async Task SaveSyncSnapshotAsync<T>(int productId, string from, string to, T response, double serverSyncAt = 0, CancellationToken ct = default)
    {
        await InitializeAsync(ct); await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand(); cmd.CommandText = @"INSERT INTO SyncSnapshots(ProductId,DateFrom,DateTo,Payload,ServerSyncAt,SavedAtUtc) VALUES($p,$f,$t,$json,$sync,$now)
ON CONFLICT(ProductId,DateFrom,DateTo) DO UPDATE SET Payload=excluded.Payload,ServerSyncAt=excluded.ServerSyncAt,SavedAtUtc=excluded.SavedAtUtc;";
        cmd.Parameters.AddWithValue("$p", productId); cmd.Parameters.AddWithValue("$f", from); cmd.Parameters.AddWithValue("$t", to);
        cmd.Parameters.AddWithValue("$json", JsonSerializer.Serialize(response, JsonOptions)); cmd.Parameters.AddWithValue("$sync", serverSyncAt);
        cmd.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O")); await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<T?> GetSyncSnapshotAsync<T>(int productId, string from, string to, CancellationToken ct = default)
    {
        await InitializeAsync(ct); await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand(); cmd.CommandText = "SELECT Payload FROM SyncSnapshots WHERE ProductId=$p AND DateFrom=$f AND DateTo=$t LIMIT 1;";
        cmd.Parameters.AddWithValue("$p", productId); cmd.Parameters.AddWithValue("$f", from); cmd.Parameters.AddWithValue("$t", to);
        var result = await cmd.ExecuteScalarAsync(ct); return result is string json ? JsonSerializer.Deserialize<T>(json, JsonOptions) : default;
    }

    public async Task<T?> GetContainingSyncSnapshotAsync<T>(int productId, string from, string to, CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand();
        cmd.CommandText = "SELECT Payload FROM SyncSnapshots WHERE ProductId=$p AND DateFrom<=$f AND DateTo>=$t ORDER BY SavedAtUtc DESC LIMIT 1;";
        cmd.Parameters.AddWithValue("$p", productId); cmd.Parameters.AddWithValue("$f", from); cmd.Parameters.AddWithValue("$t", to);
        var result = await cmd.ExecuteScalarAsync(ct);
        return result is string json ? JsonSerializer.Deserialize<T>(json, JsonOptions) : default;
    }

    /// <summary>Returns local entities with their synchronization metadata.</summary>
    public async Task<IReadOnlyList<LocalEntityRecord<T>>> GetEntityRecordsAsync<T>(string entityType, int productId, bool includeDeleted = false, CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        var items = new List<LocalEntityRecord<T>>();
        await using var db = new SqliteConnection(_connectionString);
        await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand();
        cmd.CommandText = @"SELECT EntityType,EntityId,ProductId,Payload,Revision,IsDeleted,SyncState,UpdatedAtUtc
FROM LocalEntities WHERE EntityType=$type AND ProductId=$product AND ($includeDeleted=1 OR IsDeleted=0)
ORDER BY UpdatedAtUtc DESC;";
        cmd.Parameters.AddWithValue("$type", entityType);
        cmd.Parameters.AddWithValue("$product", productId);
        cmd.Parameters.AddWithValue("$includeDeleted", includeDeleted ? 1 : 0);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var value = JsonSerializer.Deserialize<T>(reader.GetString(3), JsonOptions);
            if (value is null) continue;
            items.Add(new LocalEntityRecord<T>(reader.GetString(0), reader.GetString(1), reader.GetInt32(2), value,
                reader.GetInt64(4), reader.GetInt32(5) != 0, reader.GetString(6), DateTimeOffset.Parse(reader.GetString(7))));
        }
        return items;
    }

    /// <summary>Atomically stores a local view model and a distinct server-operation payload.</summary>
    public async Task<string> SaveLocalChangeWithPayloadAsync<TLocal, TOperation>(int productId, string entityType, string entityId,
        TLocal localValue, string operationType, TOperation operationPayload, long baseRevision = 0, CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        if (string.IsNullOrWhiteSpace(entityType) || string.IsNullOrWhiteSpace(entityId))
            throw new ArgumentException("Entity type and ID are required.");
        var operationId = Guid.NewGuid().ToString("D");
        var deviceId = await GetOrCreateDeviceIdAsync(ct);
        var now = DateTimeOffset.UtcNow.ToString("O");
        var localJson = JsonSerializer.Serialize(localValue, JsonOptions);
        var operationJson = JsonSerializer.Serialize(operationPayload, JsonOptions);
        await using var db = new SqliteConnection(_connectionString);
        await db.OpenAsync(ct);
        await using var tx = await db.BeginTransactionAsync(ct);
        await using (var entity = db.CreateCommand())
        {
            entity.Transaction = (SqliteTransaction)tx;
            entity.CommandText = @"INSERT INTO LocalEntities(EntityType,EntityId,ProductId,Payload,Revision,IsDeleted,UpdatedAtUtc,SyncState)
VALUES($type,$id,$product,$payload,$revision,0,$now,'Pending')
ON CONFLICT(EntityType,EntityId,ProductId) DO UPDATE SET Payload=excluded.Payload,Revision=excluded.Revision,IsDeleted=0,UpdatedAtUtc=excluded.UpdatedAtUtc,SyncState='Pending';";
            entity.Parameters.AddWithValue("$type", entityType); entity.Parameters.AddWithValue("$id", entityId);
            entity.Parameters.AddWithValue("$product", productId); entity.Parameters.AddWithValue("$payload", localJson);
            entity.Parameters.AddWithValue("$revision", baseRevision); entity.Parameters.AddWithValue("$now", now);
            await entity.ExecuteNonQueryAsync(ct);
        }
        await using (var operation = db.CreateCommand())
        {
            operation.Transaction = (SqliteTransaction)tx;
            operation.CommandText = @"INSERT INTO Outbox(OperationId,DeviceId,ProductId,EntityType,EntityId,OperationType,BaseRevision,Payload,CreatedAtUtc,Status)
VALUES($op,$device,$product,$type,$id,$operation,$revision,$payload,$now,'Pending');";
            operation.Parameters.AddWithValue("$op", operationId); operation.Parameters.AddWithValue("$device", deviceId);
            operation.Parameters.AddWithValue("$product", productId); operation.Parameters.AddWithValue("$type", entityType);
            operation.Parameters.AddWithValue("$id", entityId); operation.Parameters.AddWithValue("$operation", operationType);
            operation.Parameters.AddWithValue("$revision", baseRevision); operation.Parameters.AddWithValue("$payload", operationJson);
            operation.Parameters.AddWithValue("$now", now); await operation.ExecuteNonQueryAsync(ct);
        }
        await tx.CommitAsync(ct);
        return operationId;
    }

    /// <summary>Finalizes an acknowledged operation and maps a temporary local ID to its server ID atomically.</summary>
    public async Task CompleteOutboxOperationAsync(string operationId, string entityType, string localEntityId,
        int productId, string? serverEntityId, string? serverPayload, bool isDelete = false, long serverRevision = 0,
        CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        await using var db = new SqliteConnection(_connectionString);
        await db.OpenAsync(ct);
        await using var tx = await db.BeginTransactionAsync(ct);
        if (isDelete)
        {
            await using var delete = db.CreateCommand();
            delete.Transaction = (SqliteTransaction)tx;
            delete.CommandText = "DELETE FROM LocalEntities WHERE EntityType=$type AND EntityId=$id AND ProductId=$product;";
            delete.Parameters.AddWithValue("$type", entityType); delete.Parameters.AddWithValue("$id", localEntityId); delete.Parameters.AddWithValue("$product", productId);
            await delete.ExecuteNonQueryAsync(ct);
        }
        else if (!string.IsNullOrWhiteSpace(serverPayload))
        {
            var finalId = string.IsNullOrWhiteSpace(serverEntityId) ? localEntityId : serverEntityId!;
            await using var entity = db.CreateCommand();
            entity.Transaction = (SqliteTransaction)tx;
            entity.CommandText = @"INSERT INTO LocalEntities(EntityType,EntityId,ProductId,Payload,Revision,IsDeleted,UpdatedAtUtc,SyncState)
VALUES($type,$id,$product,$payload,$revision,0,$now,'Synced')
ON CONFLICT(EntityType,EntityId,ProductId) DO UPDATE SET Payload=excluded.Payload,Revision=excluded.Revision,IsDeleted=0,UpdatedAtUtc=excluded.UpdatedAtUtc,SyncState='Synced';";
            entity.Parameters.AddWithValue("$type", entityType); entity.Parameters.AddWithValue("$id", finalId);
            entity.Parameters.AddWithValue("$product", productId); entity.Parameters.AddWithValue("$payload", serverPayload);
            entity.Parameters.AddWithValue("$revision", serverRevision); entity.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O"));
            await entity.ExecuteNonQueryAsync(ct);
            if (!string.Equals(finalId, localEntityId, StringComparison.Ordinal))
            {
                await using var removeOld = db.CreateCommand();
                removeOld.Transaction = (SqliteTransaction)tx;
                removeOld.CommandText = "DELETE FROM LocalEntities WHERE EntityType=$type AND EntityId=$id AND ProductId=$product;";
                removeOld.Parameters.AddWithValue("$type", entityType); removeOld.Parameters.AddWithValue("$id", localEntityId); removeOld.Parameters.AddWithValue("$product", productId);
                await removeOld.ExecuteNonQueryAsync(ct);
            }
        }
        if (!isDelete && !string.IsNullOrWhiteSpace(serverEntityId) && !string.Equals(serverEntityId, localEntityId, StringComparison.Ordinal))
        {
            await using var remapQueue = db.CreateCommand();
            remapQueue.Transaction = (SqliteTransaction)tx;
            remapQueue.CommandText = "UPDATE Outbox SET EntityId=$serverId WHERE EntityType=$type AND EntityId=$localId AND ProductId=$product AND OperationId<>$op AND Status IN ('Pending','Retry');";
            remapQueue.Parameters.AddWithValue("$serverId", serverEntityId!); remapQueue.Parameters.AddWithValue("$type", entityType);
            remapQueue.Parameters.AddWithValue("$localId", localEntityId); remapQueue.Parameters.AddWithValue("$product", productId);
            remapQueue.Parameters.AddWithValue("$op", operationId); await remapQueue.ExecuteNonQueryAsync(ct);
        }
        await using (var ack = db.CreateCommand())
        {
            ack.Transaction = (SqliteTransaction)tx;
            ack.CommandText = "UPDATE Outbox SET Status='Acknowledged',LastError=NULL WHERE OperationId=$op;";
            ack.Parameters.AddWithValue("$op", operationId); await ack.ExecuteNonQueryAsync(ct);
        }
        await tx.CommitAsync(ct);
    }

    public async Task RecoverStaleSendingOperationsAsync(TimeSpan? staleAfter = null, CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        var cutoff = DateTimeOffset.UtcNow - (staleAfter ?? TimeSpan.FromMinutes(2));
        await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand();
        cmd.CommandText = "UPDATE Outbox SET Status='Retry',LastError='بازیابی عملیات ناتمام پس از بسته‌شدن برنامه' WHERE Status='Sending' AND (LastAttemptUtc IS NULL OR LastAttemptUtc<$cutoff);";
        cmd.Parameters.AddWithValue("$cutoff", cutoff.ToString("O"));
        await cmd.ExecuteNonQueryAsync(ct);
        await using var entities = db.CreateCommand();
        entities.CommandText = @"UPDATE LocalEntities SET SyncState='Retry',UpdatedAtUtc=$now
WHERE EXISTS (SELECT 1 FROM Outbox WHERE Status='Retry' AND EntityType=LocalEntities.EntityType AND EntityId=LocalEntities.EntityId AND ProductId=LocalEntities.ProductId AND LastError='بازیابی عملیات ناتمام پس از بسته‌شدن برنامه');";
        entities.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O"));
        await entities.ExecuteNonQueryAsync(ct);
    }

    public async Task<int> GetOutboxCountAsync(string status, int productId = 0, CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand();
        cmd.CommandText = productId > 0
            ? "SELECT COUNT(*) FROM Outbox WHERE Status=$status AND ProductId=$product;"
            : "SELECT COUNT(*) FROM Outbox WHERE Status=$status;";
        cmd.Parameters.AddWithValue("$status", status);
        if (productId > 0) cmd.Parameters.AddWithValue("$product", productId);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));
    }

    public async Task<IReadOnlyList<(string ConflictId, string OperationId, string EntityId, string LocalPayload, string ServerPayload, string CreatedAtUtc)>> GetOpenConflictsAsync(int productId, CancellationToken ct = default)
    {
        await InitializeAsync(ct);
        var result = new List<(string,string,string,string,string,string)>();
        await using var db = new SqliteConnection(_connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand();
        cmd.CommandText = "SELECT ConflictId,OperationId,EntityId,LocalPayload,ServerPayload,CreatedAtUtc FROM Conflicts WHERE ProductId=$product AND Status='Open' ORDER BY CreatedAtUtc DESC;";
        cmd.Parameters.AddWithValue("$product", productId);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) result.Add((reader.GetString(0),reader.GetString(1),reader.GetString(2),reader.GetString(3),reader.GetString(4),reader.GetString(5)));
        return result;
    }

}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using LobixApp.Models;
using LobixApp.Services;

namespace LobixApp.Views;

/// <summary>Premium customer and reporting workspace. Customer notes are intentionally local to this Windows profile.</summary>
public sealed class OperationsHubView : UserControl
{
    private static readonly Color Bg = Color.FromRgb(13, 14, 20);
    private static readonly Color Surface = Color.FromRgb(23, 25, 35);
    private static readonly Color Surface2 = Color.FromRgb(29, 32, 44);
    private static readonly Color LineColor = Color.FromRgb(47, 50, 66);
    private static readonly Color Text = Color.FromRgb(244, 245, 250);
    private static readonly Color Muted = Color.FromRgb(157, 162, 180);
    private static readonly Color Accent = Color.FromRgb(219, 60, 69);
    private static readonly Color Green = Color.FromRgb(67, 194, 139);
    private static readonly Color Amber = Color.FromRgb(232, 177, 83);
    private static readonly FontFamily Peyda = new("pack://application:,,,/Fonts/#Peyda");

    private readonly GamenetInfo _gamenet;
    private readonly LobixExtendedApiService _api;
    private readonly LobixApiService _bookingApi;
    private readonly ObservableCollection<CustomerRecord> _customers = new();
    private List<CustomerRecord> _customerRecords = new();
    private readonly ComboBox _customerFilter = new() { Width = 138, Height = 40, Margin = new Thickness(4, 0, 4, 0), FontFamily = Peyda, FontSize = 11, VerticalContentAlignment = VerticalAlignment.Center };
    private readonly Dictionary<string, string> _customerNotes = new(StringComparer.OrdinalIgnoreCase);
    private readonly TextBox _customerQuery = new() { MinWidth = 240 };
    private readonly TextBlock _customerCount = new() { Text = "۰ مشتری", Foreground = Brush(Muted), VerticalAlignment = VerticalAlignment.Center };
    private readonly DataGrid _customerGrid = new();
    private readonly TextBlock _detailName = new() { Text = "یک مشتری را انتخاب کنید", FontSize = 21, FontWeight = FontWeights.Bold, Foreground = Brush(Text) };
    private readonly TextBlock _detailPhone = new() { Text = "اطلاعات پروفایل در این بخش نمایش داده می‌شود", Foreground = Brush(Muted), Margin = new Thickness(0, 5, 0, 18) };
    private readonly TextBlock _detailId = new() { Foreground = Brush(Text) };
    private readonly TextBlock _detailBookingId = new() { Foreground = Brush(Text) };
    private readonly TextBlock _detailLast = new() { Foreground = Brush(Text) };
    private readonly TextBlock _detailAmount = new() { Foreground = Brush(Text) };
    private readonly TextBlock _detailPeriod = new() { Foreground = Brush(Text) };
    private readonly TextBlock _detailHistory = new() { Foreground = Brush(Muted), TextWrapping = TextWrapping.Wrap };
    private readonly TextBox _customerNote = new() { AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 110, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private readonly TextBox _from = new() { Text = DateTime.Today.AddDays(-6).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), Width = 125 };
    private readonly TextBox _to = new() { Text = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), Width = 125 };
    private readonly List<TextBlock> _kpiValues = new();
    private readonly StackPanel _reservationChart = new();
    private readonly StackPanel _amountChart = new();
    private readonly StackPanel _peakHoursChart = new();
    private readonly StackPanel _systemCustomerChart = new();
    private readonly TextBlock _reportNote = new() { Foreground = Brush(Muted), TextWrapping = TextWrapping.Wrap };
    private readonly TextBlock _status = new() { Foreground = Brush(Muted), FontSize = 11, VerticalAlignment = VerticalAlignment.Center };
    private readonly TextBox _maintenanceText = new() { AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 130, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private readonly ListBox _auditList = new() { MinHeight = 130 };
    private readonly Grid _loadingLayer = new();
    private bool _busy;

    public OperationsHubView(GamenetInfo gamenet, OperatorSession session)
    {
        _gamenet = gamenet;
        _api = new LobixExtendedApiService(session.Token);
        _bookingApi = new LobixApiService();
        _bookingApi.SetAuthentication(session.Token);
        FlowDirection = FlowDirection.RightToLeft;
        Background = Brush(Bg);
        FontFamily = Peyda;
        BuildUi();
        Loaded += async (_, _) =>
        {
            LoadLocalData();
            await SearchCustomersAsync();
            await LoadReportAsync();
        };
        Unloaded += (_, _) => { _api.Dispose(); _bookingApi.Dispose(); };
    }

    private void BuildUi()
    {
        var root = new Grid { Margin = new Thickness(22, 18, 22, 16), Background = Brush(Bg) };
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var header = new Grid { Margin = new Thickness(0, 0, 0, 18) };
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var titleStack = new StackPanel();
        titleStack.Children.Add(Txt("مرکز عملیات", 25, Text, FontWeights.Bold));
        titleStack.Children.Add(Txt("مدیریت مشتریان، تحلیل رزروها و عملکرد گیمنت", 12, Muted, margin: new Thickness(0, 4, 0, 0)));
        header.Children.Add(titleStack);
        var venue = Pill($"●  {_gamenet.Name}", Color.FromRgb(38, 42, 55), Text);
        venue.VerticalAlignment = VerticalAlignment.Center;
        Grid.SetColumn(venue, 1);
        header.Children.Add(venue);
        root.Children.Add(header);

        var tabs = new TabControl { Background = Brush(Bg), BorderThickness = new Thickness(0), Foreground = Brush(Text), Margin = new Thickness(0, 0, 0, 12) };
        tabs.ItemContainerStyle = BuildTabStyle();
        tabs.Items.Add(new TabItem { Header = "مشتریان و CRM", Content = BuildCustomersPage() });
        tabs.Items.Add(new TabItem { Header = "گزارش و تحلیل", Content = BuildReportsPage() });
        tabs.Items.Add(new TabItem { Header = "یادداشت‌های شیفت", Content = BuildMaintenancePage() });
        tabs.Items.Add(new TabItem { Header = "سلامت سیستم", Content = BuildReliabilityPage() });
        Grid.SetRow(tabs, 1);
        root.Children.Add(tabs);

        var statusBar = new Border { Background = Brush(Surface), BorderBrush = Brush(LineColor), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(10), Padding = new Thickness(12, 7, 12, 7), Margin = new Thickness(0, 8, 0, 0) };
        statusBar.Child = _status;
        Grid.SetRow(statusBar, 2);
        root.Children.Add(statusBar);

        _loadingLayer.Background = new SolidColorBrush(Color.FromArgb(215, 9, 10, 15));
        _loadingLayer.Visibility = Visibility.Collapsed;
        var loadingCard = new Border { Width = 300, Padding = new Thickness(26), Background = Brush(Surface2), BorderBrush = Brush(LineColor), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(18), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        var loadingStack = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
        var spinner = new ProgressBar { IsIndeterminate = true, Width = 180, Height = 5, Foreground = Brush(Accent), Background = Brush(LineColor), BorderThickness = new Thickness(0), Margin = new Thickness(0, 0, 0, 16) };
        loadingStack.Children.Add(spinner);
        loadingStack.Children.Add(Txt("در حال دریافت اطلاعات...", 14, Text, FontWeights.SemiBold));
        loadingCard.Child = loadingStack;
        _loadingLayer.Children.Add(loadingCard);
        Grid.SetRowSpan(_loadingLayer, 3);
        root.Children.Add(_loadingLayer);
        Content = root;
    }

    private UIElement BuildCustomersPage()
    {
        var page = new Grid { Margin = new Thickness(0, 8, 0, 0) };
        page.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        page.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        var toolbar = new Grid { Margin = new Thickness(0, 0, 0, 14) };
        toolbar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        toolbar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var searchWrap = new Border { Background = Brush(Surface), BorderBrush = Brush(LineColor), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(11), Padding = new Thickness(12, 2, 12, 2), Height = 46 };
        _customerQuery.Background = Brushes.Transparent;
        _customerQuery.BorderThickness = new Thickness(0);
        _customerQuery.Foreground = Brush(Text);
        _customerQuery.CaretBrush = Brush(Accent);
        _customerQuery.FontFamily = Peyda;
        _customerQuery.FontSize = 13;
        _customerQuery.VerticalContentAlignment = VerticalAlignment.Center;
        _customerQuery.ToolTip = "نام، شماره موبایل یا شناسه مشتری؛ حداقل دو نویسه";
        _customerQuery.KeyDown += async (_, e) => { if (e.Key == System.Windows.Input.Key.Enter) await SearchCustomersAsync(); };
        searchWrap.Child = _customerQuery;
        toolbar.Children.Add(searchWrap);
        var actions = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 0, 0) };
        actions.Children.Add(_customerCount);
        _customerFilter.Items.Add("همه مشتریان");
        _customerFilter.Items.Add("مشتریان پرتکرار");
        _customerFilter.Items.Add("دارای شماره تماس");
        _customerFilter.Items.Add("بدون شماره تماس");
        _customerFilter.SelectedIndex = 0;
        _customerFilter.Background = Brush(Surface2);
        _customerFilter.Foreground = Brush(Text);
        _customerFilter.BorderBrush = Brush(LineColor);
        _customerFilter.SelectionChanged += (_, _) => ApplyCustomerFilter();
        actions.Children.Add(_customerFilter);
        actions.Children.Add(Button("جست‌وجو", async (_, _) => await SearchCustomersAsync(), true, 104));
        actions.Children.Add(Button("پاک‌کردن", (_, _) => { _customerQuery.Clear(); _ = SearchCustomersAsync(); }, false, 88));
        Grid.SetColumn(actions, 1);
        toolbar.Children.Add(actions);
        page.Children.Add(toolbar);

        var body = new Grid();
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.8, GridUnitType.Star) });
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var tableCard = Card();
        _customerGrid.AutoGenerateColumns = false;
        _customerGrid.ItemsSource = _customers;
        _customerGrid.IsReadOnly = true;
        _customerGrid.SelectionMode = DataGridSelectionMode.Single;
        _customerGrid.SelectionUnit = DataGridSelectionUnit.FullRow;
        _customerGrid.HeadersVisibility = DataGridHeadersVisibility.Column;
        _customerGrid.GridLinesVisibility = DataGridGridLinesVisibility.None;
        _customerGrid.Background = Brush(Surface);
        _customerGrid.Foreground = Brush(Text);
        _customerGrid.BorderThickness = new Thickness(0);
        _customerGrid.RowBackground = Brush(Surface);
        _customerGrid.AlternatingRowBackground = Brush(Color.FromRgb(26, 29, 40));
        _customerGrid.HorizontalGridLinesBrush = Brush(LineColor);
        _customerGrid.VerticalGridLinesBrush = Brushes.Transparent;
        _customerGrid.FontFamily = Peyda;
        _customerGrid.FontSize = 12;
        _customerGrid.RowHeight = 48;
        _customerGrid.ColumnHeaderHeight = 42;
        var headerStyle = new Style(typeof(DataGridColumnHeader));
        headerStyle.Setters.Add(new Setter(Control.BackgroundProperty, Brush(Color.FromRgb(32, 35, 48))));
        headerStyle.Setters.Add(new Setter(Control.ForegroundProperty, Brush(Text)));
        headerStyle.Setters.Add(new Setter(Control.FontFamilyProperty, Peyda));
        headerStyle.Setters.Add(new Setter(Control.FontWeightProperty, FontWeights.SemiBold));
        headerStyle.Setters.Add(new Setter(Control.BorderBrushProperty, Brush(LineColor)));
        headerStyle.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(10, 8, 10, 8)));
        _customerGrid.ColumnHeaderStyle = headerStyle;
        var cellStyle = new Style(typeof(DataGridCell));
        cellStyle.Setters.Add(new Setter(Control.ForegroundProperty, Brush(Text)));
        cellStyle.Setters.Add(new Setter(Control.BackgroundProperty, Brushes.Transparent));
        cellStyle.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(0)));
        cellStyle.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(9, 6, 9, 6)));
        var selectedCell = new Trigger { Property = DataGridCell.IsSelectedProperty, Value = true };
        selectedCell.Setters.Add(new Setter(Control.BackgroundProperty, Brush(Color.FromRgb(67, 34, 43))));
        selectedCell.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.White));
        cellStyle.Triggers.Add(selectedCell);
        _customerGrid.CellStyle = cellStyle;
        _customerGrid.SelectionChanged += (_, _) => ShowCustomerDetails(_customerGrid.SelectedItem as CustomerRecord);
        _customerGrid.Columns.Add(new DataGridTextColumn { Header = "نام مشتری", Binding = new System.Windows.Data.Binding(nameof(CustomerRecord.Name)), Width = new DataGridLength(1.4, DataGridLengthUnitType.Star) });
        _customerGrid.Columns.Add(new DataGridTextColumn { Header = "شماره موبایل", Binding = new System.Windows.Data.Binding(nameof(CustomerRecord.Phone)), Width = new DataGridLength(1.1, DataGridLengthUnitType.Star) });
        _customerGrid.Columns.Add(new DataGridTextColumn { Header = "رزرو در ۳۰ روز", Binding = new System.Windows.Data.Binding(nameof(CustomerRecord.PeriodBookings)), Width = new DataGridLength(.8, DataGridLengthUnitType.Star) });
        _customerGrid.Columns.Add(new DataGridTextColumn { Header = "مجموع ۳۰ روز", Binding = new System.Windows.Data.Binding(nameof(CustomerRecord.PeriodAmountText)), Width = new DataGridLength(1.1, DataGridLengthUnitType.Star) });
        tableCard.Child = _customerGrid;
        body.Children.Add(tableCard);

        var detail = Card();
        detail.Margin = new Thickness(12, 0, 0, 0);
        var detailScroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
        var detailStack = new StackPanel();
        detailStack.Children.Add(Txt("پروفایل مشتری", 12, Muted, FontWeights.SemiBold));
        detailStack.Children.Add(_detailName);
        detailStack.Children.Add(_detailPhone);
        detailStack.Children.Add(DetailLine("شناسه مشتری", _detailId));
        detailStack.Children.Add(DetailLine("کد آخرین رزرو", _detailBookingId));
        detailStack.Children.Add(DetailLine("آخرین رزرو", _detailLast));
        detailStack.Children.Add(DetailLine("مبلغ آخرین رزرو", _detailAmount));
        detailStack.Children.Add(DetailLine("رزروهای ۳۰ روز", _detailPeriod));
        detailStack.Children.Add(Txt("سوابق اخیر", 13, Text, FontWeights.SemiBold, new Thickness(0, 14, 0, 6)));
        detailStack.Children.Add(_detailHistory);
        detailStack.Children.Add(new Border { Height = 1, Background = Brush(LineColor), Margin = new Thickness(0, 16, 0, 14) });
        detailStack.Children.Add(Txt("یادداشت داخلی", 14, Text, FontWeights.SemiBold));
        detailStack.Children.Add(Txt("این یادداشت فقط روی همین کامپیوتر ذخیره می‌شود.", 11, Muted, margin: new Thickness(0, 4, 0, 8)));
        StyleInput(_customerNote);
        detailStack.Children.Add(_customerNote);
        detailStack.Children.Add(Button("ذخیره یادداشت مشتری", (_, _) => SaveSelectedCustomerNote(), true));
        detailScroll.Content = detailStack;
        detail.Child = detailScroll;
        Grid.SetColumn(detail, 1);
        body.Children.Add(detail);
        Grid.SetRow(body, 1);
        page.Children.Add(body);
        return page;
    }

    private UIElement BuildReportsPage()
    {
        var page = new Grid { Margin = new Thickness(0, 8, 0, 0) };
        page.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        page.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        page.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        var filter = new Border { Background = Brush(Surface), BorderBrush = Brush(LineColor), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(12), Padding = new Thickness(12), Margin = new Thickness(0, 0, 0, 14) };
        var filterGrid = new Grid();
        filterGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        filterGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        filterGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        filterGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        filterGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        filterGrid.Children.Add(Txt("بازه گزارش", 12, Muted, FontWeights.SemiBold));
        StyleInput(_from); _from.Width = 126; _from.Margin = new Thickness(12, 0, 8, 0);
        Grid.SetColumn(_from, 1); filterGrid.Children.Add(_from);
        StyleInput(_to); _to.Width = 126; _to.Margin = new Thickness(0, 0, 10, 0);
        Grid.SetColumn(_to, 2); filterGrid.Children.Add(_to);
        var quick = new StackPanel { Orientation = Orientation.Horizontal };
        quick.Children.Add(Button("۷ روز", (_, _) => SetRange(7), false, 70));
        quick.Children.Add(Button("۳۰ روز", (_, _) => SetRange(30), false, 76));
        quick.Children.Add(Button("ماه جاری", (_, _) => SetCurrentMonth(), false, 88));
        Grid.SetColumn(quick, 3); filterGrid.Children.Add(quick);
        var refresh = Button("اعمال بازه", async (_, _) => await LoadReportAsync(), true, 112);
        Grid.SetColumn(refresh, 4); filterGrid.Children.Add(refresh);
        filter.Child = filterGrid;
        page.Children.Add(filter);

        var kpiGrid = new Grid { Margin = new Thickness(0, 0, 0, 14) };
        for (int i = 0; i < 4; i++) { kpiGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); if (i < 3) kpiGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(10) }); }
        string[] labels = { "کل رزروها", "رزرو دستی", "رزرو آنلاین", "مجموع مبالغ ثبت‌شده" };
        for (int i = 0; i < labels.Length; i++)
        {
            var value = Txt("—", 24, Text, FontWeights.Bold);
            var card = KpiCard(labels[i], value);
            card.Tag = "kpi" + i;
            Grid.SetColumn(card, i * 2);
            kpiGrid.Children.Add(card);
            _kpiValues.Add(value);
        }
        Grid.SetRow(kpiGrid, 1);
        page.Children.Add(kpiGrid);

        var charts = new Grid();
        charts.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        charts.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        charts.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        charts.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var reservationCard = ChartCard("ترکیب رزروها", "مقایسه تعداد رزروهای دستی و آنلاین", _reservationChart);
        reservationCard.Margin = new Thickness(0, 0, 6, 6);
        charts.Children.Add(reservationCard);

        var amountCard = ChartCard("ترکیب مبالغ", "مبالغ ثبت‌شده بر اساس منبع رزرو", _amountChart);
        amountCard.Margin = new Thickness(6, 0, 0, 6);
        if (amountCard.Child is StackPanel amountStack)
        {
            amountStack.Children.Add(new Border { Height = 1, Background = Brush(LineColor), Margin = new Thickness(0, 14, 0, 10) });
            amountStack.Children.Add(_reportNote);
        }
        Grid.SetColumn(amountCard, 1); charts.Children.Add(amountCard);

        var peakCard = ChartCard("ساعت‌های پرتردد", "بر اساس ساعت شروع رزروهای بازه انتخاب‌شده", _peakHoursChart);
        peakCard.Margin = new Thickness(0, 6, 6, 0);
        Grid.SetRow(peakCard, 1); charts.Children.Add(peakCard);

        var systemsCard = ChartCard("سیستم‌ها و مشتریان پرتکرار", "بالاترین تعداد مراجعه/رزرو در بازه", _systemCustomerChart);
        systemsCard.Margin = new Thickness(6, 6, 0, 0);
        Grid.SetRow(systemsCard, 1); Grid.SetColumn(systemsCard, 1); charts.Children.Add(systemsCard);

        var chartScroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Content = charts };
        Grid.SetRow(chartScroll, 2); page.Children.Add(chartScroll);
        return page;
    }

    private UIElement BuildMaintenancePage()
    {
        var grid = new Grid { Margin = new Thickness(0, 8, 0, 0) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var notes = Card(); notes.Margin = new Thickness(0, 0, 6, 0);
        var stack = new StackPanel();
        stack.Children.Add(Txt("یادداشت شیفت و تعمیرات", 17, Text, FontWeights.Bold));
        stack.Children.Add(Txt("ثبت نکته‌های مهم برای اپراتورهای همین دستگاه", 11, Muted, margin: new Thickness(0, 4, 0, 12)));
        StyleInput(_maintenanceText); stack.Children.Add(_maintenanceText);
        stack.Children.Add(Txt("اطلاعات این بخش به‌صورت محلی ذخیره می‌شود و بین کامپیوترها همگام نیست.", 11, Amber, margin: new Thickness(0, 8, 0, 0)));
        stack.Children.Add(Button("ذخیره یادداشت شیفت", (_, _) => { SaveLocalData(); Log("یادداشت شیفت ذخیره شد."); SetStatus("یادداشت شیفت ذخیره شد."); }, true));
        notes.Child = stack; grid.Children.Add(notes);
        var audit = Card(); audit.Margin = new Thickness(6, 0, 0, 0);
        var auditStack = new StackPanel();
        auditStack.Children.Add(Txt("سوابق فعالیت این دستگاه", 17, Text, FontWeights.Bold));
        auditStack.Children.Add(Txt("آخرین رویدادهای محلی ثبت‌شده در این بخش", 11, Muted, margin: new Thickness(0, 4, 0, 12)));
        _auditList.Background = Brush(Surface); _auditList.Foreground = Brush(Text); _auditList.BorderThickness = new Thickness(0); _auditList.FontFamily = Peyda;
        auditStack.Children.Add(_auditList); audit.Child = auditStack;
        Grid.SetColumn(audit, 1); grid.Children.Add(audit);
        return grid;
    }

    private UIElement BuildReliabilityPage()
    {
        var stack = new StackPanel { Margin = new Thickness(0, 8, 0, 0) };
        stack.Children.Add(InfoCard("اتصال امن", "درخواست‌های این بخش با HTTPS و توکن نشست فعلی ارسال می‌شوند. توکن در این صفحه روی دیسک ذخیره نمی‌شود."));
        stack.Children.Add(InfoCard("داده‌های مشتری", "فهرست مشتریان از endpoint جست‌وجوی رزروهای دستی به دست می‌آید؛ این endpoint تاریخچه کامل همه سفارش‌های آنلاین و دفترکل مشتری را ارائه نمی‌کند."));
        stack.Children.Add(InfoCard("محدودیت گزارش", "ساعت‌های پرتردد، سیستم‌های پرتکرار و مشتریان پرتکرار از جزئیات رزروهای Sync محاسبه می‌شوند؛ سود خالص، هزینه‌ها و گزارش حسابداری به دفترکل مالی نیاز دارند."));
        stack.Children.Add(InfoCard("وضعیت نقشه سالن", "نقشه سالن وضعیت رزرو و ظرفیت را از روی رزروها نمایش می‌دهد. وضعیت روشن بودن دستگاه یا اتصال زنده کلاینت در این نسخه اندازه‌گیری نمی‌شود."));
        stack.Children.Add(Button("بررسی اتصال API", async (_, _) => { try { using var d = await _api.GetReportAsync(_gamenet.Id, DateTime.Today.ToString("yyyy-MM-dd"), DateTime.Today.ToString("yyyy-MM-dd")); SetStatus("ارتباط API برقرار است."); Log("بررسی اتصال موفق بود."); } catch (Exception ex) { SetStatus("اتصال ناموفق: " + ex.Message); Log("بررسی اتصال ناموفق بود."); } }, true, 160));
        return new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = stack };
    }

    private async Task SearchCustomersAsync()
    {
        if (_busy) return;
        string q = _customerQuery.Text.Trim();
        if (q.Length == 1) { SetStatus("برای جست‌وجو حداقل دو نویسه وارد کنید."); return; }
        try
        {
            SetBusy(true, "در حال دریافت پرونده مشتریان و سوابق اخیر...");
            var records = new List<CustomerRecord>();
            using (var doc = await _api.SearchCustomersAsync(_gamenet.Id, q))
            {
                JsonElement payload = Unwrap(doc.RootElement);
                if (TryArray(payload, "customers", out var arr))
                {
                    foreach (var c in arr.EnumerateArray())
                    {
                        var record = new CustomerRecord
                        {
                            Name = S(c, "customer"), Phone = S(c, "phone"), CustomerId = S(c, "customer_id"),
                            LastBookingId = S(c, "last_booking_id"), LastDate = S(c, "date_iso"), Amount = N(c, "amount")
                        };
                        if (string.IsNullOrWhiteSpace(record.Name)) record.Name = "مشتری بدون نام";
                        records.Add(record);
                    }
                }
            }

            string historyWarning = string.Empty;
            try
            {
                string from = DateTime.Today.AddDays(-29).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                string to = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                var sync = await _bookingApi.SyncAsync(_gamenet.Id, from, to);
                var bookings = _bookingApi.GetReservationsFromSync(sync);
                foreach (var booking in bookings.Where(b => !string.IsNullOrWhiteSpace(b.Customer)))
                {
                    var record = records.FirstOrDefault(c =>
                        (!string.IsNullOrWhiteSpace(booking.Phone) && string.Equals(c.Phone, booking.Phone, StringComparison.OrdinalIgnoreCase)) ||
                        (string.IsNullOrWhiteSpace(booking.Phone) && string.Equals(c.Name, booking.Customer, StringComparison.OrdinalIgnoreCase)));
                    if (record == null)
                    {
                        record = new CustomerRecord { Name = booking.Customer, Phone = booking.Phone };
                        records.Add(record);
                    }
                    record.PeriodBookings++;
                    record.PeriodAmount += (double)booking.Amount;
                    record.RecentHistory.Add($"{booking.Date}  •  {booking.StartTime}  •  {booking.Amount:N0} تومان");
                    if (string.CompareOrdinal(booking.Date, record.LastDate) > 0)
                    {
                        record.LastDate = booking.Date;
                        record.Amount = (double)booking.Amount;
                        record.LastBookingId = booking.Id;
                    }
                }
            }
            catch (Exception ex) { historyWarning = "سوابق ۳۰ روز اخیر کامل دریافت نشد: " + ex.Message; }

            _customerRecords = records;
            ApplyCustomerFilter();
            _customerGrid.SelectedItem = _customers.FirstOrDefault();
            SetStatus(_customers.Count == 0 ? "مشتری‌ای با این مشخصات پیدا نشد." : $"{_customers.Count:N0} مشتری • سوابق تجمیعی ۳۰ روز اخیر؛ یادداشت‌ها محلی هستند. {historyWarning}");
        }
        catch (Exception ex) { SetStatus("دریافت مشتریان ناموفق بود: " + ex.Message); }
        finally { SetBusy(false); }
    }

    private void ApplyCustomerFilter()
    {
        IEnumerable<CustomerRecord> filtered = _customerRecords;
        string q = _customerQuery.Text.Trim();
        if (q.Length >= 2)
            filtered = filtered.Where(c => (c.Name + " " + c.Phone + " " + c.CustomerId).Contains(q, StringComparison.OrdinalIgnoreCase));
        string filter = _customerFilter.SelectedItem?.ToString() ?? "همه مشتریان";
        if (filter == "مشتریان پرتکرار") filtered = filtered.Where(c => c.PeriodBookings >= 2);
        else if (filter == "دارای شماره تماس") filtered = filtered.Where(c => !string.IsNullOrWhiteSpace(c.Phone));
        else if (filter == "بدون شماره تماس") filtered = filtered.Where(c => string.IsNullOrWhiteSpace(c.Phone));
        _customers.Clear();
        foreach (var item in filtered.OrderByDescending(x => x.PeriodBookings).ThenBy(x => x.Name)) _customers.Add(item);
        _customerCount.Text = $"{_customers.Count:N0} مشتری";
    }

    private async Task LoadReportAsync()
    {
        if (_busy) return;
        if (!DateTime.TryParseExact(_from.Text.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var from) ||
            !DateTime.TryParseExact(_to.Text.Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var to) || to < from)
        { SetStatus("تاریخ‌ها باید معتبر و با قالب YYYY-MM-DD باشند."); return; }
        try
        {
            SetBusy(true, "در حال ساخت گزارش بازه انتخاب‌شده...");
            using var doc = await _api.GetReportAsync(_gamenet.Id, _from.Text.Trim(), _to.Text.Trim());
            JsonElement root = Unwrap(doc.RootElement);
            // Detailed Sync data enables peak-hour, physical-system and repeat-customer insights.
            // The summary endpoint remains the source for the headline totals.
            List<ReservationItem> detailedBookings = new();
            string detailWarning = string.Empty;
            try
            {
                var sync = await _bookingApi.SyncAsync(_gamenet.Id, _from.Text.Trim(), _to.Text.Trim());
                detailedBookings = _bookingApi.GetReservationsFromSync(sync);
            }
            catch (Exception detailEx)
            {
                detailWarning = "تحلیل جزئیات رزرو در دسترس نبود: " + detailEx.Message;
            }
            JsonElement reservations = Get(root, "reservations");
            JsonElement amounts = Get(root, "amounts");
            double manualCount = N(reservations, "manual"), onlineCount = N(reservations, "online"), totalCount = N(reservations, "total");
            double manualAmount = N(amounts, "manual"), onlineAmount = N(amounts, "online"), totalAmount = N(amounts, "total");
            SetKpi(0, $"{totalCount:N0}"); SetKpi(1, $"{manualCount:N0}"); SetKpi(2, $"{onlineCount:N0}"); SetKpi(3, $"{totalAmount:N0} تومان");
            BuildBars(_reservationChart, new[] { ("رزرو دستی", manualCount, Amber), ("رزرو آنلاین", onlineCount, Accent) }, Math.Max(1, manualCount + onlineCount), "رزرو");
            BuildBars(_amountChart, new[] { ("رزرو دستی", manualAmount, Amber), ("رزرو آنلاین", onlineAmount, Accent) }, Math.Max(1, manualAmount + onlineAmount), "تومان");
            BuildDetailedInsights(detailedBookings);
            string note = S(root, "note");
            _reportNote.Text = string.Join("  ", new[] { note, detailWarning }.Where(x => !string.IsNullOrWhiteSpace(x)));
            SetStatus($"گزارش از {from:yyyy-MM-dd} تا {to:yyyy-MM-dd} به‌روزرسانی شد.");
            Log("گزارش رزرو و مبالغ دریافت شد.");
        }
        catch (Exception ex) { SetStatus("دریافت گزارش ناموفق بود: " + ex.Message); }
        finally { SetBusy(false); }
    }

    private void BuildBars(Panel host, (string Label, double Value, Color Color)[] values, double max, string unit)
    {
        host.Children.Clear();
        foreach (var item in values)
        {
            var row = new Grid { Margin = new Thickness(0, 7, 0, 7) };
            row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            row.RowDefinitions.Add(new RowDefinition { Height = new GridLength(12) });
            var labelRow = new Grid();
            labelRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            labelRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            labelRow.Children.Add(Txt(item.Label, 12, Text, FontWeights.SemiBold));
            var valueText = Txt($"{item.Value:N0} {unit}", 11, Muted);
            Grid.SetColumn(valueText, 1); labelRow.Children.Add(valueText);
            row.Children.Add(labelRow);
            var bar = new ProgressBar { Minimum = 0, Maximum = 100, Value = Math.Clamp(item.Value / max * 100, 0, 100), Height = 10, Margin = new Thickness(0, 7, 0, 0), Foreground = Brush(item.Color), Background = Brush(Color.FromRgb(39, 42, 54)), BorderThickness = new Thickness(0), HorizontalAlignment = HorizontalAlignment.Stretch };
            Grid.SetRow(bar, 1); row.Children.Add(bar);
            host.Children.Add(row);
        }
    }

    private void SetKpi(int index, string value)
    {
        if (index >= 0 && index < _kpiValues.Count) _kpiValues[index].Text = value;
    }

    private void BuildDetailedInsights(List<ReservationItem> bookings)
    {
        var hours = bookings
            .Select(b => int.TryParse((b.StartTime ?? string.Empty).Split(':').FirstOrDefault(), out var h) ? h : -1)
            .Where(h => h >= 0 && h <= 23)
            .GroupBy(h => h)
            .Select(g => ($"{g.Key:00}:00", (double)g.Count(), Accent))
            .OrderByDescending(x => x.Item2)
            .Take(6)
            .ToArray();
        if (hours.Length == 0)
            BuildBars(_peakHoursChart, new[] { ("اطلاعات ساعت شروع در این بازه موجود نیست", 0d, Muted) }, 1, "رزرو");
        else
            BuildBars(_peakHoursChart, hours, Math.Max(1, hours.Max(x => x.Item2)), "رزرو");

        var systems = bookings
            .SelectMany(b => b.Systems ?? new List<ReservationSystem>())
            .Where(x => !string.IsNullOrWhiteSpace(x.SystemNumber))
            .GroupBy(x => x.SystemNumber.Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(g => ($"سیستم {g.Key}", (double)g.Sum(x => Math.Max(1, x.Quantity)), Green))
            .OrderByDescending(x => x.Item2)
            .Take(5)
            .ToArray();
        var customers = bookings
            .Where(b => !string.IsNullOrWhiteSpace(b.Customer))
            .GroupBy(b => !string.IsNullOrWhiteSpace(b.Phone) ? b.Phone.Trim() : b.Customer.Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(g => ($"{g.First().Customer}  •  {g.Count()} رزرو", (double)g.Count(), Amber))
            .OrderByDescending(x => x.Item2)
            .Take(5)
            .ToArray();

        _systemCustomerChart.Children.Clear();
        _systemCustomerChart.Children.Add(Txt("سیستم‌های پرتکرار", 12, Text, FontWeights.SemiBold));
        var systemBars = new StackPanel();
        _systemCustomerChart.Children.Add(systemBars);
        if (systems.Length == 0)
            systemBars.Children.Add(Txt("شماره سیستم در داده رزروهای این بازه ثبت نشده است.", 11, Muted, margin: new Thickness(0, 5, 0, 10)));
        else
            BuildBars(systemBars, systems, Math.Max(1, systems.Max(x => x.Item2)), "بار");
        _systemCustomerChart.Children.Add(new Border { Height = 1, Background = Brush(LineColor), Margin = new Thickness(0, 12, 0, 10) });
        _systemCustomerChart.Children.Add(Txt("مشتریان پرتکرار", 12, Text, FontWeights.SemiBold));
        var customerBars = new StackPanel();
        _systemCustomerChart.Children.Add(customerBars);
        if (customers.Length == 0)
            customerBars.Children.Add(Txt("مشتری ثبت‌شده‌ای در این بازه پیدا نشد.", 11, Muted, margin: new Thickness(0, 5, 0, 0)));
        else
            BuildBars(customerBars, customers, Math.Max(1, customers.Max(x => x.Item2)), "رزرو");
    }

    private static Border ChartCard(string title, string subtitle, UIElement content)
    {
        var stack = new StackPanel();
        stack.Children.Add(Txt(title, 15, Text, FontWeights.Bold));
        stack.Children.Add(Txt(subtitle, 11, Muted, margin: new Thickness(0, 3, 0, 14)));
        stack.Children.Add(content);
        return new Border { Background = Brush(Surface), BorderBrush = Brush(LineColor), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(13), Padding = new Thickness(16), Child = stack };
    }

    private void SetRange(int days)
    {
        _from.Text = DateTime.Today.AddDays(-(days - 1)).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        _to.Text = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        _ = LoadReportAsync();
    }

    private void SetCurrentMonth()
    {
        var today = DateTime.Today;
        _from.Text = new DateTime(today.Year, today.Month, 1).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        _to.Text = today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        _ = LoadReportAsync();
    }

    private void ShowCustomerDetails(CustomerRecord? c)
    {
        if (c == null)
        {
            _detailName.Text = "یک مشتری را انتخاب کنید"; _detailPhone.Text = ""; _detailId.Text = _detailBookingId.Text = _detailLast.Text = _detailAmount.Text = _detailPeriod.Text = "—"; _detailHistory.Text = ""; _customerNote.Text = ""; return;
        }
        _detailName.Text = c.Name;
        _detailPhone.Text = string.IsNullOrWhiteSpace(c.Phone) ? "شماره موبایل ثبت نشده" : c.Phone;
        _detailId.Text = string.IsNullOrWhiteSpace(c.CustomerId) ? "ثبت نشده" : c.CustomerId;
        _detailBookingId.Text = string.IsNullOrWhiteSpace(c.LastBookingId) ? "ثبت نشده" : c.LastBookingId;
        _detailLast.Text = string.IsNullOrWhiteSpace(c.LastDate) ? "نامشخص" : c.LastDate;
        _detailAmount.Text = $"{c.Amount:N0} تومان";
        _detailPeriod.Text = $"{c.PeriodBookings:N0} رزرو • {c.PeriodAmount:N0} تومان";
        _detailHistory.Text = c.RecentHistory.Count == 0 ? "جزئیات رزرو در این بازه ثبت نشده است." : string.Join("\n", c.RecentHistory.TakeLast(5).Reverse());
        _customerNote.Text = _customerNotes.TryGetValue(c.Key, out var note) ? note : "";
    }

    private void SaveSelectedCustomerNote()
    {
        if (_customerGrid.SelectedItem is not CustomerRecord c) { SetStatus("ابتدا یک مشتری را انتخاب کنید."); return; }
        _customerNotes[c.Key] = _customerNote.Text;
        SaveLocalData();
        SetStatus("یادداشت مشتری روی همین دستگاه ذخیره شد.");
    }

    private void SetBusy(bool busy, string? message = null)
    {
        _busy = busy;
        _loadingLayer.Visibility = busy ? Visibility.Visible : Visibility.Collapsed;
        if (!string.IsNullOrWhiteSpace(message)) SetStatus(message);
    }

    private void SetStatus(string text) => _status.Text = text;
    private void Log(string line)
    {
        _auditList.Items.Insert(0, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}  •  {line}");
        while (_auditList.Items.Count > 100) _auditList.Items.RemoveAt(_auditList.Items.Count - 1);
        SaveLocalData();
    }

    private void LoadLocalData()
    {
        try
        {
            if (!File.Exists(LocalDataPath)) return;
            using var doc = JsonDocument.Parse(File.ReadAllText(LocalDataPath));
            var root = doc.RootElement;
            if (root.TryGetProperty("notes", out var notes) && notes.ValueKind == JsonValueKind.String) _maintenanceText.Text = notes.GetString() ?? "";
            if (root.TryGetProperty("audit", out var audit) && audit.ValueKind == JsonValueKind.Array)
                foreach (var item in audit.EnumerateArray()) _auditList.Items.Add(item.GetString() ?? "");
            if (root.TryGetProperty("customer_notes", out var customerNotes) && customerNotes.ValueKind == JsonValueKind.Object)
                foreach (var p in customerNotes.EnumerateObject()) _customerNotes[p.Name] = p.Value.GetString() ?? "";
        }
        catch { }
    }

    private void SaveLocalData()
    {
        try
        {
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(LocalDataPath)!);
            var data = new { notes = _maintenanceText.Text, audit = _auditList.Items.Cast<object>().Select(x => x?.ToString() ?? "").Take(100).ToArray(), customer_notes = _customerNotes };
            File.WriteAllText(LocalDataPath, JsonSerializer.Serialize(data));
        }
        catch (Exception ex) { SetStatus("ذخیره محلی انجام نشد: " + ex.Message); }
    }

    private string LocalDataPath => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Lobix", "ops-" + _gamenet.Id + ".json");

    private static Style BuildTabStyle()
    {
        var style = new Style(typeof(TabItem));
        style.Setters.Add(new Setter(Control.ForegroundProperty, Brush(Muted)));
        style.Setters.Add(new Setter(Control.BackgroundProperty, Brush(Surface)));
        style.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(8, 8, 8, 8)));
        style.Setters.Add(new Setter(FrameworkElement.MinHeightProperty, 48d));
        style.Setters.Add(new Setter(FrameworkElement.MinWidthProperty, 0d));
        style.Setters.Add(new Setter(Control.MarginProperty, new Thickness(0, 0, 4, 0)));
        style.Setters.Add(new Setter(Control.FontFamilyProperty, Peyda));
        style.Setters.Add(new Setter(Control.FontSizeProperty, 12d));
        style.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(1)));
        style.Setters.Add(new Setter(Control.BorderBrushProperty, Brush(LineColor)));
        var template = new ControlTemplate(typeof(TabItem));
        var border = new FrameworkElementFactory(typeof(Border));
        border.SetValue(Border.CornerRadiusProperty, new CornerRadius(10));
        border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Control.BackgroundProperty));
        border.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Control.BorderBrushProperty));
        border.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Control.BorderThicknessProperty));
        var cp = new FrameworkElementFactory(typeof(ContentPresenter));
        cp.SetValue(ContentPresenter.ContentSourceProperty, "Header"); cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center); cp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center); cp.SetValue(ContentPresenter.MarginProperty, new Thickness(1, 0, 1, 0)); cp.SetValue(ContentPresenter.RecognizesAccessKeyProperty, true);
        border.AppendChild(cp); template.VisualTree = border; style.Setters.Add(new Setter(Control.TemplateProperty, template));
        var trigger = new Trigger { Property = TabItem.IsSelectedProperty, Value = true };
        trigger.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(54, 29, 37))));
        trigger.Setters.Add(new Setter(Control.ForegroundProperty, Brush(Text)));
        trigger.Setters.Add(new Setter(Control.BorderBrushProperty, Brush(Accent)));
        style.Triggers.Add(trigger);
        return style;
    }

    private static Border KpiCard(string label, TextBlock value)
    {
        var stack = new StackPanel();
        stack.Children.Add(Txt(label, 11, Muted, FontWeights.SemiBold));
        value.Margin = new Thickness(0, 7, 0, 0); stack.Children.Add(value);
        return new Border { Background = Brush(Surface), BorderBrush = Brush(LineColor), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(13), Padding = new Thickness(16, 13, 16, 13), Child = stack };
    }

    private static Border DetailLine(string label, TextBlock value)
    {
        var grid = new Grid { Margin = new Thickness(0, 7, 0, 7) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(105) }); grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.Children.Add(Txt(label, 11, Muted)); Grid.SetColumn(value, 1); grid.Children.Add(value);
        return new Border { BorderBrush = Brush(LineColor), BorderThickness = new Thickness(0, 0, 0, 1), Padding = new Thickness(0, 0, 0, 8), Child = grid };
    }

    private static Border InfoCard(string title, string detail)
    {
        var stack = new StackPanel(); stack.Children.Add(Txt(title, 15, Text, FontWeights.SemiBold)); stack.Children.Add(Txt(detail, 12, Muted, margin: new Thickness(0, 7, 0, 0)));
        return new Border { Background = Brush(Surface), BorderBrush = Brush(LineColor), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(13), Padding = new Thickness(18), Margin = new Thickness(0, 0, 0, 10), Child = stack };
    }

    private static Border Card() => new() { Background = Brush(Surface), BorderBrush = Brush(LineColor), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(14), Padding = new Thickness(16), ClipToBounds = true };
    private static Border Pill(string text, Color bg, Color fg) => new() { Background = Brush(bg), BorderBrush = Brush(LineColor), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(20), Padding = new Thickness(13, 8, 13, 8), Child = Txt(text, 11, fg, FontWeights.SemiBold) };
    private static TextBlock Txt(string text, double size, Color color, FontWeight? weight = null, Thickness? margin = null) => new() { Text = text, FontFamily = Peyda, FontSize = size, Foreground = Brush(color), FontWeight = weight ?? FontWeights.Normal, Margin = margin ?? new Thickness(0), TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center };
    private static SolidColorBrush Brush(Color c) => new(c);

    private static Button Button(string label, RoutedEventHandler click, bool primary = false, double minWidth = 96)
    {
        var b = new Button { Content = label, MinWidth = minWidth, Height = 40, Margin = new Thickness(4, 0, 4, 0), Padding = new Thickness(14, 8, 14, 8), FontFamily = Peyda, FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = Brush(Text), Background = Brush(primary ? Accent : Surface2), BorderBrush = Brush(primary ? Accent : LineColor), BorderThickness = new Thickness(1), Cursor = System.Windows.Input.Cursors.Hand };
        var template = new ControlTemplate(typeof(Button)); var bd = new FrameworkElementFactory(typeof(Border));
        bd.SetValue(Border.CornerRadiusProperty, new CornerRadius(9)); bd.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Control.BackgroundProperty)); bd.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Control.BorderBrushProperty)); bd.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Control.BorderThicknessProperty));
        var cp = new FrameworkElementFactory(typeof(ContentPresenter)); cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center); cp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center); bd.AppendChild(cp); template.VisualTree = bd; b.Template = template;
        b.Click += click; return b;
    }

    private static void StyleInput(Control c)
    {
        c.FontFamily = Peyda; c.FontSize = 12; c.Foreground = Brush(Text); c.Background = Brush(Color.FromRgb(17, 19, 27)); c.BorderBrush = Brush(LineColor); c.BorderThickness = new Thickness(1); c.Padding = new Thickness(10, 8, 10, 8);
    }

    private static JsonElement Unwrap(JsonElement root) => root.TryGetProperty("data", out var d) && d.ValueKind == JsonValueKind.Object ? d : root;
    private static JsonElement Get(JsonElement e, string key) => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(key, out var v) ? v : default;
    private static bool TryArray(JsonElement e, string key, out JsonElement arr) { arr = Get(e, key); return arr.ValueKind == JsonValueKind.Array; }
    private static string S(JsonElement e, string key) { var v = Get(e, key); return v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : v.ValueKind == JsonValueKind.Number ? v.ToString() : ""; }
    private static double N(JsonElement e, string key) { var v = Get(e, key); return v.ValueKind == JsonValueKind.Number && v.TryGetDouble(out var n) ? n : 0; }

    private sealed class CustomerRecord
    {
        public string Name { get; set; } = "";
        public string Phone { get; set; } = "";
        public string CustomerId { get; set; } = "";
        public string LastBookingId { get; set; } = "";
        public string LastDate { get; set; } = "";
        public double Amount { get; set; }
        public int PeriodBookings { get; set; }
        public double PeriodAmount { get; set; }
        public List<string> RecentHistory { get; } = new();
        public string PeriodAmountText => $"{PeriodAmount:N0} تومان";
        public string Key => !string.IsNullOrWhiteSpace(CustomerId) || !string.IsNullOrWhiteSpace(Phone) ? CustomerId + "|" + Phone : Name;
    }
}

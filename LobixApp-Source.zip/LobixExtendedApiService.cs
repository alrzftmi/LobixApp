﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace LobixApp.Services;

/// <summary>Small, backward-compatible client for the additive v2.3 operator endpoints.</summary>
public sealed class LobixExtendedApiService : IDisposable
{
    private const string BaseUrl = "https://lobixapp.ir/wp-json/lobix/operator/v2/";
    private readonly HttpClient _http = new() { BaseAddress = new Uri(BaseUrl), Timeout = TimeSpan.FromSeconds(22) };
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true };

    public LobixExtendedApiService(string token)
    {
        _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        if (!string.IsNullOrWhiteSpace(token)) _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    public async Task<JsonDocument> GetAsync(string route, CancellationToken ct = default)
    {
        int productId = ExtractProductId(route);
        string cacheRoute = string.Join("&", route.Split('&')
            .Where(part => !part.StartsWith("_nocache=", StringComparison.OrdinalIgnoreCase)));
        bool cacheable = productId > 0 &&
            (route.StartsWith("layout?", StringComparison.OrdinalIgnoreCase) ||
             route.StartsWith("systems?", StringComparison.OrdinalIgnoreCase) ||
             route.StartsWith("customers/search?", StringComparison.OrdinalIgnoreCase));
        try
        {
            var document = await SendAsync(HttpMethod.Get, route, null, ct);
            if (cacheable)
                await LocalDatabase.Instance.PutEntityAsync("ApiCache", cacheRoute, productId, document.RootElement.GetRawText(), 0, "Synced", ct);
            return document;
        }
        catch (HttpRequestException) when (!ct.IsCancellationRequested && cacheable)
        {
            var cached = await LocalDatabase.Instance.GetEntityAsync<string>("ApiCache", cacheRoute, productId, ct);
            if (!string.IsNullOrWhiteSpace(cached)) return JsonDocument.Parse(cached);
            throw new InvalidOperationException("اینترنت در دسترس نیست و اطلاعات ذخیره‌شده‌ای برای این بخش وجود ندارد.");
        }
        catch (TaskCanceledException) when (!ct.IsCancellationRequested && cacheable)
        {
            var cached = await LocalDatabase.Instance.GetEntityAsync<string>("ApiCache", cacheRoute, productId, ct);
            if (!string.IsNullOrWhiteSpace(cached)) return JsonDocument.Parse(cached);
            throw new InvalidOperationException("اتصال به سرور برقرار نشد و اطلاعات ذخیره‌شده‌ای برای این بخش وجود ندارد.");
        }
    }

    private static int ExtractProductId(string route)
    {
        var marker = "product_id=";
        int start = route.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
        if (start < 0) return 0;
        start += marker.Length;
        int end = route.IndexOf('&', start);
        var value = end < 0 ? route[start..] : route[start..end];
        return int.TryParse(value, out var id) ? id : 0;
    }
    public async Task<JsonDocument> PostAsync(string route, object body, CancellationToken ct = default) => await SendAsync(HttpMethod.Post, route, body, ct);

    private async Task<JsonDocument> SendAsync(HttpMethod method, string route, object? body, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(method, route);
        if (body != null) request.Content = new StringContent(JsonSerializer.Serialize(body, JsonOptions), Encoding.UTF8, "application/json");
        using var response = await _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false);
        var text = await response.Content.ReadAsStringAsync(ct).ConfigureAwait(false);
        JsonDocument doc;
        try { doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(text) ? "{}" : text); }
        catch { throw new InvalidOperationException("پاسخ سرور قابل خواندن نیست. لطفاً دوباره تلاش کنید."); }
        if (!response.IsSuccessStatusCode || (doc.RootElement.TryGetProperty("success", out var ok) && ok.ValueKind == JsonValueKind.False))
        {
            var message = "درخواست به سرور ناموفق بود.";
            if (doc.RootElement.TryGetProperty("message", out var m) && m.ValueKind == JsonValueKind.String) message = m.GetString() ?? message;
            else if (doc.RootElement.TryGetProperty("code", out var c) && c.ValueKind == JsonValueKind.String) message = c.GetString() ?? message;
            doc.Dispose();
            throw new InvalidOperationException(message + $" (HTTP {(int)response.StatusCode})");
        }
        return doc;
    }

    // Always request a fresh server representation. Offline fallback is handled by
    // ReservationsView/FloorPlanView from the per-gamenet local layout file; returning
    // a stale API-cache document here could overwrite a just-saved layout.
    public Task<JsonDocument> GetLayoutAsync(int productId, CancellationToken ct = default)
    {
        string route = $"layout?product_id={productId}&_nocache={DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}";
        // Do not fall back to a cached layout here: the caller must either receive the
        // latest server layout or fall back to its per-gamenet local JSON file.
        return SendAsync(HttpMethod.Get, route, null, ct);
    }
    public Task<JsonDocument> SaveLayoutAsync(int productId, object layout, CancellationToken ct = default) => PostAsync("layout/save", new { product_id = productId, layout }, ct);
    public Task<JsonDocument> GetSystemsAsync(int productId, CancellationToken ct = default) => GetAsync($"systems?product_id={productId}", ct);
    public Task<JsonDocument> SaveSystemAsync(int productId, int number, string category, int variationId = 0, string? systemId = null, CancellationToken ct = default)
        => PostAsync("systems/save", new { product_id = productId, number, category, variation_id = variationId, system_id = systemId ?? "" }, ct);
    public Task<JsonDocument> DeactivateSystemAsync(int productId, string systemId, CancellationToken ct = default)
        => PostAsync("systems/deactivate", new { product_id = productId, system_id = systemId }, ct);
    public Task<JsonDocument> GetDeviceAvailabilityAsync(int productId, string date, string start, int hours, CancellationToken ct = default)
        => GetAsync($"devices/availability?product_id={productId}&date={Uri.EscapeDataString(date)}&start_time={Uri.EscapeDataString(start)}&hours={hours}", ct);
    public Task<JsonDocument> GetReportAsync(int productId, string from, string to, CancellationToken ct = default)
        => GetAsync($"reports/summary?product_id={productId}&from={Uri.EscapeDataString(from)}&to={Uri.EscapeDataString(to)}", ct);
    public Task<JsonDocument> SearchCustomersAsync(int productId, string query, CancellationToken ct = default)
        => GetAsync($"customers/search?product_id={productId}&q={Uri.EscapeDataString(query)}", ct);
    public void Dispose() => _http.Dispose();
}

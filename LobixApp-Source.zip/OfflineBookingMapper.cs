using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using LobixApp.Models;

namespace LobixApp.Services.Sync;

public static class OfflineBookingMapper
{
    public static global::ReservationItem ToReservation(BookingCreateRequest request, string id, string syncState)
    {
        if (request == null) throw new ArgumentNullException(nameof(request));

        int startMinute = ParseMinutes(request.StartTime);
        int duration = request.DurationMinutes > 0
            ? request.DurationMinutes
            : Math.Max(1, request.Hours) * 60;
        int expectedEndMinute = startMinute + duration;
        int endMinute = !string.IsNullOrWhiteSpace(request.EndTime)
            ? ParseMinutes(request.EndTime)
            : expectedEndMinute;

        if (startMinute < 0 || startMinute >= 1440 || duration < 5 || duration % 5 != 0 || expectedEndMinute > 1440)
            throw new ArgumentException("بازه زمانی رزرو آفلاین معتبر نیست.", nameof(request));
        if (endMinute != expectedEndMinute)
            throw new ArgumentException("ساعت پایان با مدت رزرو آفلاین مطابقت ندارد.", nameof(request));
        string endTime = FormatTime(endMinute);
        int startHour = startMinute / 60;
        int lastHour = Math.Max(startHour, (endMinute - 1) / 60);
        var hourLabels = Enumerable.Range(startHour, lastHour - startHour + 1)
            .Select(h => h.ToString("00", CultureInfo.InvariantCulture)).ToList();

        return new global::ReservationItem
        {
            Id = id,
            Source = "manual",
            Date = request.Date,
            StartTime = FormatTime(startMinute),
            EndTime = endTime,
            DurationMinutes = endMinute - startMinute,
            Hours = (int)Math.Ceiling((endMinute - startMinute) / 60.0),
            Customer = request.Customer,
            Phone = request.Phone,
            Amount = request.Amount,
            Note = request.Note,
            Status = "manual",
            CreatedAt = DateTimeOffset.Now.ToString("O"),
            LocalSyncState = syncState,
            Systems = (request.Systems ?? new List<BookingSystemRequest>()).Select(x => new global::ReservationSystem
            {
                VariationId = x.VariationId,
                Quantity = x.Quantity,
                SystemNumber = x.SystemNumber,
                GameId = x.GameId ?? 0,
                Hours = hourLabels.Select(h => h + ":00").ToList()
            }).ToList()
        };
    }

    private static int ParseMinutes(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return -1;
        string normalized = value.Trim()
            .Replace('۰', '0').Replace('۱', '1').Replace('۲', '2')
            .Replace('۳', '3').Replace('۴', '4').Replace('۵', '5')
            .Replace('۶', '6').Replace('۷', '7').Replace('۸', '8')
            .Replace('۹', '9').Replace('٠', '0').Replace('١', '1')
            .Replace('٢', '2').Replace('٣', '3').Replace('٤', '4')
            .Replace('٥', '5').Replace('٦', '6').Replace('٧', '7')
            .Replace('٨', '8').Replace('٩', '9');
        if (normalized == "24:00") return 1440;
        if (TimeSpan.TryParse(normalized, CultureInfo.InvariantCulture, out var t) &&
            t >= TimeSpan.Zero && t <= TimeSpan.FromDays(1))
            return (int)t.TotalMinutes;
        return -1;
    }

    private static string FormatTime(int minutes)
    {
        minutes = Math.Clamp(minutes, 0, 1440);
        return minutes == 1440 ? "24:00" : $"{minutes / 60:00}:{minutes % 60:00}";
    }
}

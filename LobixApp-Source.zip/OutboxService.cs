using Microsoft.Data.Sqlite;
using System.Text.Json;

namespace LobixApp.Services.Sync;

public sealed record PendingOperation(string OperationId, string DeviceId, int ProductId, string EntityType,
    string EntityId, string OperationType, long BaseRevision, string Payload, DateTimeOffset CreatedAtUtc, int RetryCount);

public sealed class OutboxService
{
    private readonly LocalDatabase _database;
    public OutboxService(LocalDatabase? database = null) => _database = database ?? LocalDatabase.Instance;

    public Task<string> EnqueueAsync(int productId, string entityType, string entityId, string operationType,
        object payload, long baseRevision = 0, CancellationToken ct = default) =>
        _database.EnqueueOperationAsync(productId, entityType, entityId, operationType, payload, baseRevision, ct);

    public async Task<IReadOnlyList<PendingOperation>> GetPendingAsync(int limit = 50, CancellationToken ct = default)
    {
        await _database.InitializeAsync(ct);
        await _database.RecoverStaleSendingOperationsAsync(ct: ct);
        var connectionString = new Microsoft.Data.Sqlite.SqliteConnectionStringBuilder { DataSource = _database.DatabasePath, Mode = SqliteOpenMode.ReadWriteCreate, Cache = SqliteCacheMode.Shared, Pooling = true }.ToString();
        var items = new List<PendingOperation>();
        await using var db = new SqliteConnection(connectionString); await db.OpenAsync(ct);
        await using var cmd = db.CreateCommand();
        cmd.CommandText = @"SELECT OperationId,DeviceId,ProductId,EntityType,EntityId,OperationType,BaseRevision,Payload,CreatedAtUtc,RetryCount
FROM Outbox WHERE Status IN ('Pending','Retry') ORDER BY CreatedAtUtc LIMIT $limit;";
        cmd.Parameters.AddWithValue("$limit", Math.Clamp(limit, 1, 500));
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) items.Add(new PendingOperation(reader.GetString(0), reader.GetString(1), reader.GetInt32(2), reader.GetString(3), reader.GetString(4), reader.GetString(5), reader.GetInt64(6), reader.GetString(7), DateTimeOffset.Parse(reader.GetString(8)), reader.GetInt32(9)));
        return items;
    }

    public async Task MarkSendingAsync(string operationId, CancellationToken ct = default)
    {
        await UpdateAsync(operationId,
            "UPDATE Outbox SET Status='Sending',LastAttemptUtc=$now,LastError=NULL WHERE OperationId=$id AND Status IN ('Pending','Retry');", ct);
        await SetEntitySyncStateAsync(operationId, "Sending", ct);
    }

    public async Task MarkAcknowledgedAsync(string operationId, CancellationToken ct = default)
    {
        await UpdateAsync(operationId, "UPDATE Outbox SET Status='Acknowledged',LastError=NULL WHERE OperationId=$id;", ct);
        await SetEntitySyncStateAsync(operationId, "Synced", ct);
    }

    public async Task MarkRetryAsync(string operationId, string error, CancellationToken ct = default)
    {
        await _database.InitializeAsync(ct); await using var db = await OpenAsync(ct); await using var cmd = db.CreateCommand();
        cmd.CommandText = "UPDATE Outbox SET Status='Retry',RetryCount=RetryCount+1,LastError=$error WHERE OperationId=$id;";
        cmd.Parameters.AddWithValue("$id", operationId); cmd.Parameters.AddWithValue("$error", error.Length > 2000 ? error[..2000] : error); await cmd.ExecuteNonQueryAsync(ct);
        await SetEntitySyncStateAsync(operationId, "Retry", ct);
    }

    private async Task SetEntitySyncStateAsync(string operationId, string state, CancellationToken ct)
    {
        await _database.InitializeAsync(ct);
        await using var db = await OpenAsync(ct);
        await using var cmd = db.CreateCommand();
        cmd.CommandText = @"UPDATE LocalEntities SET SyncState=$state,UpdatedAtUtc=$now
WHERE EXISTS (SELECT 1 FROM Outbox WHERE OperationId=$op AND EntityType=LocalEntities.EntityType AND EntityId=LocalEntities.EntityId AND ProductId=LocalEntities.ProductId);";
        cmd.Parameters.AddWithValue("$state", state); cmd.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O"));
        cmd.Parameters.AddWithValue("$op", operationId); await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task MarkConflictAsync(string operationId, int productId, string entityType, string entityId,
        string localPayload, string serverPayload, long localRevision, long serverRevision, CancellationToken ct = default)
    {
        await _database.InitializeAsync(ct); await using var db = await OpenAsync(ct); await using var tx = await db.BeginTransactionAsync(ct);
        await using (var conflict = db.CreateCommand())
        {
            conflict.Transaction = (SqliteTransaction)tx;
            conflict.CommandText = @"INSERT INTO Conflicts(ConflictId,OperationId,ProductId,EntityType,EntityId,LocalPayload,ServerPayload,LocalRevision,ServerRevision,CreatedAtUtc,Status)
VALUES($cid,$op,$p,$type,$entity,$local,$server,$lr,$sr,$now,'Open');";
            conflict.Parameters.AddWithValue("$cid", Guid.NewGuid().ToString("D")); conflict.Parameters.AddWithValue("$op", operationId); conflict.Parameters.AddWithValue("$p", productId);
            conflict.Parameters.AddWithValue("$type", entityType); conflict.Parameters.AddWithValue("$entity", entityId); conflict.Parameters.AddWithValue("$local", localPayload);
            conflict.Parameters.AddWithValue("$server", serverPayload); conflict.Parameters.AddWithValue("$lr", localRevision); conflict.Parameters.AddWithValue("$sr", serverRevision);
            conflict.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O")); await conflict.ExecuteNonQueryAsync(ct);
        }
        await using (var update = db.CreateCommand()) { update.Transaction = (SqliteTransaction)tx; update.CommandText = "UPDATE Outbox SET Status='Conflict',LastError='تعارض با اطلاعات سرور' WHERE OperationId=$id;"; update.Parameters.AddWithValue("$id", operationId); await update.ExecuteNonQueryAsync(ct); }
        await using (var entity = db.CreateCommand()) { entity.Transaction = (SqliteTransaction)tx; entity.CommandText = "UPDATE LocalEntities SET SyncState='Conflict',UpdatedAtUtc=$now WHERE EntityType=$type AND EntityId=$entity AND ProductId=$product;"; entity.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O")); entity.Parameters.AddWithValue("$type", entityType); entity.Parameters.AddWithValue("$entity", entityId); entity.Parameters.AddWithValue("$product", productId); await entity.ExecuteNonQueryAsync(ct); }
        await tx.CommitAsync(ct);
    }

    public Task CompleteAsync(string operationId, string entityType, string localEntityId, int productId,
        string? serverEntityId, string? serverPayload, bool isDelete = false, long serverRevision = 0,
        CancellationToken ct = default) =>
        _database.CompleteOutboxOperationAsync(operationId, entityType, localEntityId, productId,
            serverEntityId, serverPayload, isDelete, serverRevision, ct);

    public Task<int> GetCountAsync(string status, int productId = 0, CancellationToken ct = default) =>
        _database.GetOutboxCountAsync(status, productId, ct);

    public Task<IReadOnlyList<(string ConflictId, string OperationId, string EntityId, string LocalPayload, string ServerPayload, string CreatedAtUtc)>>
        GetOpenConflictsAsync(int productId, CancellationToken ct = default) =>
        _database.GetOpenConflictsAsync(productId, ct);

    private async Task UpdateAsync(string operationId, string sql, CancellationToken ct)
    {
        await _database.InitializeAsync(ct); await using var db = await OpenAsync(ct); await using var cmd = db.CreateCommand(); cmd.CommandText = sql;
        cmd.Parameters.AddWithValue("$id", operationId); if (sql.Contains("$now", StringComparison.Ordinal)) cmd.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O")); await cmd.ExecuteNonQueryAsync(ct);
    }

    private async Task<SqliteConnection> OpenAsync(CancellationToken ct) { var db = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = _database.DatabasePath, Mode = SqliteOpenMode.ReadWriteCreate, Cache = SqliteCacheMode.Shared, Pooling = true }.ToString()); await db.OpenAsync(ct); return db; }
}

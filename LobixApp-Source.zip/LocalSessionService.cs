using LobixApp.Models;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace LobixApp.Services.Security;

/// <summary>Stores an encrypted last-known session and a PBKDF2 password verifier for time-limited offline startup; plaintext passwords are never persisted.</summary>
public sealed class LocalSessionService
{
    private static readonly Lazy<LocalSessionService> Lazy = new(() => new LocalSessionService());
    public static LocalSessionService Instance => Lazy.Value;
    private readonly string _path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Lobix", "Security", "session.bin");
    private static readonly TimeSpan MaximumOfflineAge = TimeSpan.FromDays(7);
    private LocalSessionService() { }

    public async Task SaveAfterOnlineLoginAsync(OperatorSession session, string password, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(session);
        if (string.IsNullOrWhiteSpace(session.Token)) throw new ArgumentException("A valid server token is required.", nameof(session));
        if (string.IsNullOrEmpty(password)) throw new ArgumentException("Password verifier cannot be created from an empty password.", nameof(password));
        byte[] passwordSalt = RandomNumberGenerator.GetBytes(16);
        byte[] passwordHash = Rfc2898DeriveBytes.Pbkdf2(password, passwordSalt, 310_000, HashAlgorithmName.SHA256, 32);
        DateTimeOffset? tokenExpiry = ParseExpiry(session.TokenExpiresAt);
        if (tokenExpiry is null) throw new InvalidOperationException("Server session expiry was not provided; offline login cannot be enabled safely.");
        var record = new StoredSession(session.Token, session.UserId, session.Username, session.DisplayName,
            DateTimeOffset.UtcNow, tokenExpiry.Value, Convert.ToBase64String(passwordSalt), Convert.ToBase64String(passwordHash));
        var plain = JsonSerializer.SerializeToUtf8Bytes(record);
        var encrypted = ProtectedData.Protect(plain, Encoding.UTF8.GetBytes("Lobix.Offline.Session.v1"), DataProtectionScope.CurrentUser);
        Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
        var temp = _path + ".tmp";
        await File.WriteAllBytesAsync(temp, encrypted, ct);
        if (File.Exists(_path)) File.Replace(temp, _path, null); else File.Move(temp, _path);
    }

    public async Task<OperatorSession?> TryGetOfflineSessionAsync(string username, string password, CancellationToken ct = default)
    {
        if (!File.Exists(_path)) return null;
        try
        {
            var encrypted = await File.ReadAllBytesAsync(_path, ct);
            var plain = ProtectedData.Unprotect(encrypted, Encoding.UTF8.GetBytes("Lobix.Offline.Session.v1"), DataProtectionScope.CurrentUser);
            var record = JsonSerializer.Deserialize<StoredSession>(plain);
            if (record is null || string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password)) return null;
            if (!string.Equals(record.Username, username.Trim(), StringComparison.OrdinalIgnoreCase)) return null;
            if (string.IsNullOrWhiteSpace(record.PasswordSalt) || string.IsNullOrWhiteSpace(record.PasswordHash)) return null;
            byte[] salt = Convert.FromBase64String(record.PasswordSalt);
            byte[] expectedHash = Convert.FromBase64String(record.PasswordHash);
            byte[] actualHash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 310_000, HashAlgorithmName.SHA256, expectedHash.Length);
            if (!CryptographicOperations.FixedTimeEquals(actualHash, expectedHash)) return null;
            CryptographicOperations.ZeroMemory(actualHash);
            var now = DateTimeOffset.UtcNow;
            // Offline access is a local, time-limited authorization based on the last successful
            // online validation. The stored server token may have expired; it is never treated as
            // proof of current server authorization and every online request must be revalidated.
            if (now - record.LastOnlineValidationUtc > MaximumOfflineAge || record.LastOnlineValidationUtc > now.AddMinutes(5)) return null;
            return new OperatorSession { Token = record.Token, UserId = record.UserId, Username = record.Username, DisplayName = record.DisplayName, TokenExpiresAt = record.ServerExpiresAtUtc.ToString("O") };
        }
        catch (CryptographicException) { return null; }
        catch (JsonException) { return null; }
        catch (FormatException) { return null; }
        catch (IOException) { return null; }
        catch (UnauthorizedAccessException) { return null; }
    }

    public Task ClearAsync(CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        if (File.Exists(_path)) File.Delete(_path);
        return Task.CompletedTask;
    }

    private static DateTimeOffset? ParseExpiry(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        return DateTimeOffset.TryParse(value, out var parsed) ? parsed : null;
    }

    private sealed record StoredSession(string Token, int UserId, string Username, string DisplayName,
        DateTimeOffset LastOnlineValidationUtc, DateTimeOffset ServerExpiresAtUtc, string PasswordSalt, string PasswordHash);
}

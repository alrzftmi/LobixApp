﻿
using System;
using System.Globalization;
using System.Linq;

namespace LobixApp.Utilities
{
    /// <summary>
    /// ابزار مشترک تاریخ شمسی برای تمام بخش‌های برنامه.
    /// تاریخ داخلی و تاریخ ارسالی به API همچنان میلادی است.
    /// </summary>
    public static class JalaliDateHelper
    {
        private static readonly PersianCalendar Calendar = new();

        private static readonly CultureInfo Invariant =
            CultureInfo.InvariantCulture;

        private static readonly string[] PersianMonthNames =
        {
            "فروردین",
            "اردیبهشت",
            "خرداد",
            "تیر",
            "مرداد",
            "شهریور",
            "مهر",
            "آبان",
            "آذر",
            "دی",
            "بهمن",
            "اسفند"
        };

        public static DateTime Today => DateTime.Today;

        public static string FormatDate(DateTime date)
        {
            string value =
                $"{Calendar.GetYear(date):0000}/" +
                $"{Calendar.GetMonth(date):00}/" +
                $"{Calendar.GetDayOfMonth(date):00}";

            return ToPersianDigits(value);
        }

        public static string FormatDateWithMonthName(DateTime date)
        {
            int year = Calendar.GetYear(date);
            int month = Calendar.GetMonth(date);
            int day = Calendar.GetDayOfMonth(date);

            return ToPersianDigits(
                $"{day:00} {PersianMonthNames[month - 1]} {year:0000}"
            );
        }

        public static string FormatMonth(int year, int month)
        {
            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException(nameof(month));

            return ToPersianDigits(
                $"{PersianMonthNames[month - 1]} {year:0000}"
            );
        }

        public static int GetYear(DateTime date)
        {
            return Calendar.GetYear(date);
        }

        public static int GetMonth(DateTime date)
        {
            return Calendar.GetMonth(date);
        }

        public static int GetDay(DateTime date)
        {
            return Calendar.GetDayOfMonth(date);
        }

        public static int GetDaysInMonth(int year, int month)
        {
            return Calendar.GetDaysInMonth(year, month);
        }

        public static DateTime ToGregorianDate(
            int year,
            int month,
            int day)
        {
            return Calendar.ToDateTime(
                year,
                month,
                day,
                0,
                0,
                0,
                0
            ).Date;
        }

        public static string ToApiDate(DateTime date)
        {
            return date.Date.ToString(
                "yyyy-MM-dd",
                Invariant
            );
        }

        public static bool TryParseApiDate(
            string? value,
            out DateTime date)
        {
            date = DateTime.Today;

            if (string.IsNullOrWhiteSpace(value))
                return false;

            return DateTime.TryParseExact(
                value.Trim(),
                "yyyy-MM-dd",
                Invariant,
                DateTimeStyles.None,
                out date
            );
        }

        public static string ToPersianDigits(string? value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            return value
                .Replace('0', '۰')
                .Replace('1', '۱')
                .Replace('2', '۲')
                .Replace('3', '۳')
                .Replace('4', '۴')
                .Replace('5', '۵')
                .Replace('6', '۶')
                .Replace('7', '۷')
                .Replace('8', '۸')
                .Replace('9', '۹');
        }

        public static string ToEnglishDigits(string? value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            return value
                .Replace('۰', '0')
                .Replace('۱', '1')
                .Replace('۲', '2')
                .Replace('۳', '3')
                .Replace('۴', '4')
                .Replace('۵', '5')
                .Replace('۶', '6')
                .Replace('۷', '7')
                .Replace('۸', '8')
                .Replace('۹', '9')
                .Replace('٠', '0')
                .Replace('١', '1')
                .Replace('٢', '2')
                .Replace('٣', '3')
                .Replace('٤', '4')
                .Replace('٥', '5')
                .Replace('٦', '6')
                .Replace('٧', '7')
                .Replace('٨', '8')
                .Replace('٩', '9');
        }

        public static bool IsPastDate(DateTime date)
        {
            return date.Date < DateTime.Today;
        }

        public static DateTime GetFirstDayOfPersianMonth(
            int year,
            int month)
        {
            return ToGregorianDate(year, month, 1);
        }

        public static DayOfWeek GetFirstDayOfWeek(
            int year,
            int month)
        {
            return GetFirstDayOfPersianMonth(year, month).DayOfWeek;
        }

        public static DateTime AddPersianMonths(
            DateTime date,
            int months)
        {
            int year = Calendar.GetYear(date);
            int month = Calendar.GetMonth(date);
            int day = Calendar.GetDayOfMonth(date);

            int absoluteMonth = (year * 12) + (month - 1) + months;

            int newYear = absoluteMonth / 12;
            int newMonth = (absoluteMonth % 12) + 1;

            int maxDay = Calendar.GetDaysInMonth(newYear, newMonth);
            int newDay = Math.Min(day, maxDay);

            return ToGregorianDate(newYear, newMonth, newDay);
        }
    }
}

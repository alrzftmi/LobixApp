﻿using System;
using System.Globalization;

namespace LobixApp.Helpers
{
    public static class PersianDateHelper
    {
        private static readonly PersianCalendar Calendar =
            new PersianCalendar();

        // =====================================================
        // DATE TO PERSIAN
        // =====================================================

        public static string ToPersianDate(
            DateTime date)
        {
            int year =
                Calendar.GetYear(date);

            int month =
                Calendar.GetMonth(date);

            int day =
                Calendar.GetDayOfMonth(date);

            return
                $"{ToPersianNumber(year)} " +
                $"{GetPersianMonthName(month)} " +
                $"{ToPersianNumber(day)}";
        }

        // =====================================================
        // CURRENT DATE
        // =====================================================

        public static string Today()
        {
            return ToPersianDate(
                DateTime.Now
            );
        }

        // =====================================================
        // MONTH NAME
        // =====================================================

        private static string GetPersianMonthName(
            int month)
        {
            return month switch
            {
                1 => "فروردین",
                2 => "اردیبهشت",
                3 => "خرداد",
                4 => "تیر",
                5 => "مرداد",
                6 => "شهریور",
                7 => "مهر",
                8 => "آبان",
                9 => "آذر",
                10 => "دی",
                11 => "بهمن",
                12 => "اسفند",
                _ => ""
            };
        }

        // =====================================================
        // PERSIAN NUMBERS
        // =====================================================

        private static string ToPersianNumber(
            int number)
        {
            return number
                .ToString()
                .Replace("0", "۰")
                .Replace("1", "۱")
                .Replace("2", "۲")
                .Replace("3", "۳")
                .Replace("4", "۴")
                .Replace("5", "۵")
                .Replace("6", "۶")
                .Replace("7", "۷")
                .Replace("8", "۸")
                .Replace("9", "۹");
        }
    }
}
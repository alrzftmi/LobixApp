﻿namespace LobixApp.Models
{
    public class AvailabilityTestResult
    {
        public bool Success { get; set; }

        public string Message { get; set; } = string.Empty;

        public string RawJson { get; set; } = string.Empty;
    }
}
﻿
using System;
using System.Windows;
using LobixApp.Services;

namespace LobixApp
{
    public partial class App : Application
    {
        protected override async void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            try
            {
                // Initialize SQLite provider
                SQLitePCL.Batteries_V2.Init();

                // Initialize local database
                await LocalDatabase.Instance.InitializeAsync();

                var mainWindow = new MainWindow();
                MainWindow = mainWindow;
                mainWindow.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "پایگاه داده محلی لابیکس راه‌اندازی نشد."
                    + Environment.NewLine + ex.Message,
                    "خطای راه‌اندازی لابیکس",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                Shutdown(-1);
            }
        }
    }
}

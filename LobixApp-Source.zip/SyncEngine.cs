namespace LobixApp.Services.Sync;

/// <summary>
/// Coordinates sync batches. A transport is intentionally required: the currently supplied PHP API
/// does not yet expose the atomic batch/ack/conflict contract needed to safely drain this queue.
/// </summary>
public interface IOfflineSyncTransport
{
    Task<SyncBatchResult> PushAsync(IReadOnlyList<PendingOperation> operations, CancellationToken ct);
    Task PullAsync(CancellationToken ct);
}

public sealed record SyncOperationResult(string OperationId, bool Accepted, bool Conflict, string? Error = null,
    string? ServerPayload = null, long ServerRevision = 0);
public sealed record SyncBatchResult(IReadOnlyList<SyncOperationResult> Results);

public sealed class SyncEngine
{
    private readonly OutboxService _outbox;
    private readonly IOfflineSyncTransport _transport;
    private readonly SemaphoreSlim _runLock = new(1, 1);
    public SyncEngine(IOfflineSyncTransport transport, OutboxService? outbox = null)
    { _transport = transport ?? throw new ArgumentNullException(nameof(transport)); _outbox = outbox ?? new OutboxService(); }

    public async Task RunOnceAsync(CancellationToken ct = default)
    {
        if (!await _runLock.WaitAsync(0, ct)) return;
        try
        {
            ConnectionStateService.Instance.SetState(LobixConnectionState.Syncing);
            var batch = await _outbox.GetPendingAsync(50, ct);
            if (batch.Count > 0)
            {
                foreach (var operation in batch) await _outbox.MarkSendingAsync(operation.OperationId, ct);
                SyncBatchResult result;
                try { result = await _transport.PushAsync(batch, ct); }
                catch (Exception ex)
                {
                    foreach (var operation in batch) await _outbox.MarkRetryAsync(operation.OperationId, ex.Message, CancellationToken.None);
                    throw;
                }
                var returnedIds = result.Results.Select(x => x.OperationId).ToHashSet(StringComparer.OrdinalIgnoreCase);
                foreach (var operation in batch.Where(x => !returnedIds.Contains(x.OperationId)))
                    await _outbox.MarkRetryAsync(operation.OperationId, "No acknowledgement returned for this operation", ct);
                foreach (var item in result.Results)
                {
                    if (item.Accepted) await _outbox.MarkAcknowledgedAsync(item.OperationId, ct);
                    else if (item.Conflict)
                    {
                        var operation = batch.FirstOrDefault(x => x.OperationId == item.OperationId);
                        if (operation is not null)
                            await _outbox.MarkConflictAsync(operation.OperationId, operation.ProductId, operation.EntityType,
                                operation.EntityId, operation.Payload, item.ServerPayload ?? "null", operation.BaseRevision,
                                item.ServerRevision, ct);
                    }
                    else await _outbox.MarkRetryAsync(item.OperationId, item.Error ?? "Server did not acknowledge operation", ct);
                }
            }
            await _transport.PullAsync(ct);
            var remaining = await _outbox.GetPendingAsync(1, ct);
            ConnectionStateService.Instance.SetState(remaining.Count == 0 ? LobixConnectionState.Online : LobixConnectionState.Syncing);
        }
        catch
        {
            ConnectionStateService.Instance.SetState(LobixConnectionState.SyncError);
            throw;
        }
        finally { _runLock.Release(); }
    }
}

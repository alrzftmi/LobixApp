﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;

public class FlexibleStringListConverter : JsonConverter<List<string>>
{
    public override List<string> Read(
        ref Utf8JsonReader reader,
        Type typeToConvert,
        JsonSerializerOptions options)
    {
        var result = new List<string>();

        using JsonDocument document =
            JsonDocument.ParseValue(ref reader);

        foreach (JsonElement element in document.RootElement.EnumerateArray())
        {
            result.Add(element.ToString());
        }

        return result;
    }

    public override void Write(
        Utf8JsonWriter writer,
        List<string> value,
        JsonSerializerOptions options)
    {
        writer.WriteStartArray();

        foreach (string item in value)
        {
            writer.WriteStringValue(item);
        }

        writer.WriteEndArray();
    }
}
namespace LobixApp.Models
{
    // =========================================================
    // SYNC RESPONSE
    // =========================================================

    public class GamenetSyncResponse
    {
        [JsonPropertyName("success")]
        public bool Success { get; set; }

        [JsonPropertyName("api_version")]
        public string ApiVersion { get; set; } = string.Empty;

        [JsonPropertyName("server_time")]
        public string ServerTime { get; set; } = string.Empty;

        [JsonPropertyName("sync_at")]
        [JsonConverter(typeof(FlexibleDoubleConverter))]
        public double SyncAt { get; set; }

        [JsonPropertyName("hash")]
        public string Hash { get; set; } = string.Empty;

        [JsonPropertyName("data")]
        public GamenetSyncData Data { get; set; } = new();
    }


    // =========================================================
    // SYNC DATA
    // =========================================================

    public class GamenetSyncData
    {
        [JsonPropertyName("product_id")]
        public int ProductId { get; set; }

        [JsonPropertyName("range")]
        public GamenetSyncRange Range { get; set; } = new();

        [JsonPropertyName("gamenet")]
        public GamenetSyncGamenet Gamenet { get; set; } = new();

        [JsonPropertyName("variations")]
        public List<GamenetVariation> Variations { get; set; } = new();

        [JsonPropertyName("manual_bookings")]
        public List<ManualBooking> ManualBookings { get; set; } = new();

        [JsonPropertyName("online_bookings")]
        public List<OnlineBooking> OnlineBookings { get; set; } = new();
    }


    // =========================================================
    // RANGE
    // =========================================================

    public class GamenetSyncRange
    {
        [JsonPropertyName("from")]
        public string From { get; set; } = string.Empty;

        [JsonPropertyName("to")]
        public string To { get; set; } = string.Empty;
    }


    // =========================================================
    // GAMENET
    // =========================================================


    public class GamenetSyncGamenet
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;

        [JsonPropertyName("status")]
        public string Status { get; set; } = string.Empty;

        [JsonPropertyName("stock_status")]
        public string StockStatus { get; set; } = string.Empty;

        [JsonPropertyName("booking_mode")]
        public string BookingMode { get; set; } = string.Empty;

        [JsonPropertyName("work_start")]
        [JsonNumberHandling(JsonNumberHandling.AllowReadingFromString)]
        public int WorkStart { get; set; }

        [JsonPropertyName("work_end")]
        [JsonNumberHandling(JsonNumberHandling.AllowReadingFromString)]
        public int WorkEnd { get; set; }
    }



    // =========================================================
    // VARIATION / SYSTEM
    // =========================================================


    public class GamenetVariation
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;

        [JsonPropertyName("title")]
        public string Title { get; set; } = string.Empty;

        [JsonPropertyName("sku")]
        public string Sku { get; set; } = string.Empty;

        [JsonPropertyName("price")]
        [JsonConverter(typeof(FlexibleDecimalConverter))]
        public decimal Price { get; set; }

        [JsonPropertyName("regular_price")]
        [JsonConverter(typeof(FlexibleDecimalConverter))]
        public decimal RegularPrice { get; set; }

        [JsonPropertyName("sale_price")]
        [JsonConverter(typeof(FlexibleNullableDecimalConverter))]
        public decimal? SalePrice { get; set; }

        [JsonPropertyName("stock_status")]
        public string StockStatus { get; set; } = string.Empty;

        [JsonPropertyName("capacity")]
        public int Capacity { get; set; }

        [JsonPropertyName("system_numbers")]
        public List<string> SystemNumbers { get; set; } = new();

        [JsonPropertyName("games")]
        public List<GamenetGame> Games { get; set; } = new();

        [JsonPropertyName("work_start")]
        public string WorkStart { get; set; } = string.Empty;

        [JsonPropertyName("work_end")]
        public string WorkEnd { get; set; } = string.Empty;

        [JsonPropertyName("booking_mode")]
        public string BookingMode { get; set; } = string.Empty;

        [JsonPropertyName("description")]
        public string Description { get; set; } = string.Empty;

        [JsonPropertyName("attributes")]
        public Dictionary<string, string> Attributes { get; set; } = new();
    }



    public class GamenetGame
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;

        [JsonPropertyName("image_url")]
        public string ImageUrl { get; set; } = string.Empty;
    }


    // =========================================================
    // MANUAL BOOKING
    // =========================================================

    public class ManualBooking
    {
        // مهم:
        // ID رزرو دستی در API رشته‌ای و UUID مانند است.
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;

        [JsonPropertyName("date")]
        public string Date { get; set; } = string.Empty;

        [JsonPropertyName("start_time")]
        public string StartTime { get; set; } = string.Empty;

        [JsonPropertyName("end_time")]
        public string EndTime { get; set; } = string.Empty;

        [JsonPropertyName("duration_minutes")]
        public int DurationMinutes { get; set; }

        [JsonPropertyName("hours_count")]
        public int HoursCount { get; set; }

        [JsonPropertyName("day_code")]
        public string DayCode { get; set; } = string.Empty;

        [JsonPropertyName("customer")]
        public string Customer { get; set; } = string.Empty;

        [JsonPropertyName("phone")]
        public string Phone { get; set; } = string.Empty;

        [JsonPropertyName("amount")]
        [JsonConverter(typeof(FlexibleDecimalConverter))]
        public decimal Amount { get; set; }

        [JsonPropertyName("note")]
        public string Note { get; set; } = string.Empty;

        [JsonPropertyName("created_at")]
        public string CreatedAt { get; set; } = string.Empty;

        [JsonPropertyName("type")]
        public string Type { get; set; } = string.Empty;

        [JsonPropertyName("systems")]
        public List<ManualBookingSystem> Systems { get; set; } = new();
    }


    // =========================================================
    // MANUAL BOOKING SYSTEM
    // =========================================================

    public class ManualBookingSystem
    {
        [JsonPropertyName("variation_id")]
        public int VariationId { get; set; }

        [JsonPropertyName("quantity")]
        public int Quantity { get; set; }

        [JsonPropertyName("system_number")]
        public string SystemNumber { get; set; } = string.Empty;

        [JsonPropertyName("game_id")]
        public int GameId { get; set; }

        [JsonPropertyName("game_name")]
        public string GameName { get; set; } = string.Empty;

        [JsonPropertyName("hours")]
        [JsonConverter(typeof(FlexibleStringListConverter))]
        public List<string> Hours { get; set; } = new();
    }


    // =========================================================
    // ONLINE BOOKING
    // =========================================================

    public class OnlineBooking
    {
        [JsonPropertyName("order_id")]
        public int OrderId { get; set; }

        [JsonPropertyName("item_id")]
        public int ItemId { get; set; }

        [JsonPropertyName("var_id")]
        public int VarId { get; set; }

        [JsonPropertyName("variation_id")]
        public int VariationId { get; set; }

        [JsonPropertyName("date_iso")]
        public string DateIso { get; set; } = string.Empty;

        [JsonPropertyName("start_time")]
        public string StartTime { get; set; } = string.Empty;

        [JsonPropertyName("hours")]
        public int Hours { get; set; }

        [JsonPropertyName("end_time")]
        public string EndTime { get; set; } = string.Empty;

        [JsonPropertyName("duration_minutes")]
        public int DurationMinutes { get; set; }

        [JsonPropertyName("customer")]
        public string Customer { get; set; } = string.Empty;

        [JsonPropertyName("phone")]
        public string Phone { get; set; } = string.Empty;

        [JsonPropertyName("amount")]
        [JsonConverter(typeof(FlexibleDecimalConverter))]
        public decimal Amount { get; set; }

        [JsonPropertyName("status")]
        public string Status { get; set; } = string.Empty;

        [JsonPropertyName("operator_status")]
        public string OperatorStatus { get; set; } = string.Empty;

        [JsonPropertyName("system_number")]
        public string SystemNumber { get; set; } = string.Empty;

        [JsonPropertyName("game_id")]
        public int GameId { get; set; }

        [JsonPropertyName("game_name")]
        public string GameName { get; set; } = string.Empty;
    }


    // =========================================================
    // FLEXIBLE DECIMAL
    // =========================================================

    public class FlexibleDecimalConverter : JsonConverter<decimal>
    {
        public override decimal Read(
            ref Utf8JsonReader reader,
            Type typeToConvert,
            JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.Number)
            {
                if (reader.TryGetDecimal(out decimal number))
                {
                    return number;
                }

                if (reader.TryGetDouble(out double doubleNumber))
                {
                    return Convert.ToDecimal(
                        doubleNumber,
                        CultureInfo.InvariantCulture
                    );
                }
            }

            if (reader.TokenType == JsonTokenType.String)
            {
                string? value = reader.GetString();

                if (string.IsNullOrWhiteSpace(value))
                {
                    return 0m;
                }

                if (decimal.TryParse(
                        value,
                        NumberStyles.Any,
                        CultureInfo.InvariantCulture,
                        out decimal parsed))
                {
                    return parsed;
                }
            }

            if (reader.TokenType == JsonTokenType.Null)
            {
                return 0m;
            }

            throw new JsonException(
                $"مقدار اعشاری قابل پردازش نیست. نوع JSON: {reader.TokenType}"
            );
        }

        public override void Write(
            Utf8JsonWriter writer,
            decimal value,
            JsonSerializerOptions options)
        {
            writer.WriteNumberValue(value);
        }
    }


    // =========================================================
    // FLEXIBLE NULLABLE DECIMAL
    // =========================================================

    public class FlexibleNullableDecimalConverter
        : JsonConverter<decimal?>
    {
        public override decimal? Read(
            ref Utf8JsonReader reader,
            Type typeToConvert,
            JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.Null)
            {
                return null;
            }

            if (reader.TokenType == JsonTokenType.Number)
            {
                if (reader.TryGetDecimal(out decimal number))
                {
                    return number;
                }

                if (reader.TryGetDouble(out double doubleNumber))
                {
                    return Convert.ToDecimal(
                        doubleNumber,
                        CultureInfo.InvariantCulture
                    );
                }
            }

            if (reader.TokenType == JsonTokenType.String)
            {
                string? value = reader.GetString();

                if (string.IsNullOrWhiteSpace(value))
                {
                    return null;
                }

                if (decimal.TryParse(
                        value,
                        NumberStyles.Any,
                        CultureInfo.InvariantCulture,
                        out decimal parsed))
                {
                    return parsed;
                }
            }

            throw new JsonException(
                $"مقدار اعشاری قابل پردازش نیست. نوع JSON: {reader.TokenType}"
            );
        }

        public override void Write(
            Utf8JsonWriter writer,
            decimal? value,
            JsonSerializerOptions options)
        {
            if (value.HasValue)
            {
                writer.WriteNumberValue(value.Value);
            }
            else
            {
                writer.WriteNullValue();
            }
        }
    }


}

public class FlexibleDoubleConverter : JsonConverter<double>
{
    public override double Read(
        ref Utf8JsonReader reader,
        Type typeToConvert,
        JsonSerializerOptions options)
    {
        if (reader.TokenType == JsonTokenType.Number)
        {
            return reader.GetDouble();
        }

        if (reader.TokenType == JsonTokenType.String)
        {
            string? value = reader.GetString();

            if (double.TryParse(
                value,
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out double result))
            {
                return result;
            }

            return 0d;
        }

        if (reader.TokenType == JsonTokenType.Null)
        {
            return 0d;
        }

        throw new JsonException(
            "مقدار sync_at قابل تبدیل به عدد نیست."
        );
    }

    public override void Write(
        Utf8JsonWriter writer,
        double value,
        JsonSerializerOptions options)
    {
        writer.WriteNumberValue(value);
    }
}

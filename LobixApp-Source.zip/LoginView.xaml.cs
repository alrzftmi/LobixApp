using System;
using System.Windows;
using System.Windows.Controls;
using LobixApp.Models;
using LobixApp.Services;
using LobixApp.Services.Security;
using LobixApp.Utilities;
using LobixApp.Services.Sync;

namespace LobixApp.Views
{
    public partial class LoginView : UserControl
    {
        private readonly LobixApiService _apiService;

        public event Action<GamenetInfo, OperatorSession>? LoginSucceeded;

        public LoginView()
        {
            InitializeComponent();

            _apiService = new LobixApiService();
        }

        private async void LoginButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username))
            {
                StatusTextBlock.Text =
                    "لطفاً نام کاربری را وارد کنید.";

                UsernameTextBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                StatusTextBlock.Text =
                    "لطفاً رمز عبور را وارد کنید.";

                PasswordBox.Focus();
                return;
            }

            try
            {
                LoginButton.IsEnabled = false;
                LoginButton.Content = "در حال ورود...";
                LoginProgressBar.Visibility = Visibility.Visible;
                StatusTextBlock.Text = "در حال بررسی اطلاعات ورود...";

                StatusTextBlock.Foreground =
                    System.Windows.Media.Brushes.Gray;

                StatusTextBlock.Text =
                    "در حال اتصال به سرور لابیکس...";

                // =================================================
                // LOGIN
                // =================================================

                var session = await _apiService.LoginAsync(
                    username,
                    password
                );

                // =================================================
                // GET GAMENETS
                // =================================================

                StatusTextBlock.Text =
                    "ورود موفق بود. در حال دریافت اطلاعات گیمنت...";

                var gamenets =
                    await _apiService.GetGamenetsAsync();

                // =================================================
                // NO GAMENET
                // =================================================

                if (gamenets.Count == 0)
                {
                    StatusTextBlock.Foreground =
                        System.Windows.Media.Brushes.DarkOrange;

                    StatusTextBlock.Text =
                        $"ورود موفق بود، اما برای کاربر «{session.DisplayName}» " +
                        "هیچ گیمنتی پیدا نشد.";

                    LoginButton.IsEnabled = true;
                    LoginButton.Content = "ورود";
                    LoginProgressBar.Visibility = Visibility.Collapsed;

                    return;
                }

                // Persist the last server-validated session and the account's gamenet list.
                // The plaintext password is never stored; only a PBKDF2 verifier is protected by DPAPI.
                await LocalSessionService.Instance.SaveAfterOnlineLoginAsync(session, password);
                foreach (var gamenet in gamenets)
                    await LocalDatabase.Instance.PutEntityAsync("Gamenet", gamenet.Id.ToString(), 0, gamenet);
                // =================================================
                // SELECT GAMENET
                // =================================================

                GamenetInfo selectedGamenet = gamenets[0];

                // =================================================
                // SUCCESS
                // =================================================

                StatusTextBlock.Foreground =
                    System.Windows.Media.Brushes.Green;

                StatusTextBlock.Text =
                    $"اتصال به گیمنت «{selectedGamenet.Name}» موفق بود.";

                LoginButton.Content = "ورود موفق";

                // =================================================
                // SEND LOGIN RESULT TO MAIN WINDOW
                // =================================================

                LoginSucceeded?.Invoke(
                    selectedGamenet,
                    session
                );
            }
            catch (Exception ex)
            {
                if (IsNetworkFailure(ex))
                {
                    try
                    {
                        var offlineSession = await LocalSessionService.Instance.TryGetOfflineSessionAsync(username, password);
                        if (offlineSession != null &&
                            string.Equals(offlineSession.Username, username, StringComparison.OrdinalIgnoreCase))
                        {
                            var cachedGamenets = await LocalDatabase.Instance.GetEntitiesAsync<GamenetInfo>("Gamenet", 0);
                            if (cachedGamenets.Count > 0)
                            {
                                _apiService.SetAuthentication(offlineSession.Token);
                                StatusTextBlock.Foreground = System.Windows.Media.Brushes.DarkOrange;
                                StatusTextBlock.Text = "اینترنت در دسترس نیست؛ ورود آفلاین با اطلاعات ذخیره‌شده انجام شد.";
                                LoginSucceeded?.Invoke(cachedGamenets[0], offlineSession);
                                return;
                            }
                        }
                    }
                    catch (Exception offlineEx)
                    {
                        System.Diagnostics.Debug.WriteLine("Offline login failed: " + offlineEx);
                    }
                }

                StatusTextBlock.Foreground = System.Windows.Media.Brushes.IndianRed;
                StatusTextBlock.Text = UserFacingErrors.GetMessage(
                    ex,
                    "ورود انجام نشد. نام کاربری و رمز عبور را بررسی کنید و دوباره تلاش کنید.");
                LoginButton.IsEnabled = true;
                LoginButton.Content = "ورود";
            }
            finally
            {
                LoginProgressBar.Visibility = Visibility.Collapsed;
                if (LoginButton.IsEnabled == false && LoginButton.Content?.ToString() != "ورود موفق")
                {
                    LoginButton.IsEnabled = true;
                    LoginButton.Content = "ورود";
                }
            }
        }

        private static bool IsNetworkFailure(Exception exception)
        {
            for (Exception? current = exception; current != null; current = current.InnerException)
            {
                if ((current is System.Net.Http.HttpRequestException httpError &&
                     (httpError.StatusCode == null || (int)httpError.StatusCode.Value >= 500)) ||
                    current is TaskCanceledException ||
                    current is System.IO.IOException)
                    return true;
            }
            return false;
        }

    }
}
﻿namespace LobixApp.Models
{
    public class GamenetInfo
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string Status { get; set; } = string.Empty;

        public int OwnerUserId { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LobixApp.Models;

public class OperatorSession
{
    public string Token { get; set; } = string.Empty;
    public string TokenExpiresAt { get; set; } = string.Empty;
    public int UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public bool IsAuthenticated =>
        !string.IsNullOrWhiteSpace(Token);
}

using System;
using System.Linq;
using System.Net.Http;
using System.Net;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using LobixApp.Models;
using LobixApp.Services;

namespace LobixApp.Services.Sync;

/// <summary>Replays durable manual-booking operations. Server idempotency keys are the local OperationId.</summary>
public sealed class BookingOutboxSyncService
{
    private readonly LobixApiService _api;
    private readonly OutboxService _outbox;
    private readonly int _productId;
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public BookingOutboxSyncService(LobixApiService api, OutboxService? outbox = null, int productId = 0)
    {
        _api = api ?? throw new ArgumentNullException(nameof(api));
        _outbox = outbox ?? new OutboxService();
        _productId = productId;
    }

    public async Task<int> SyncBookingsAsync(CancellationToken cancellationToken = default)
    {
        if (!await _api.CheckConnectionAsync(cancellationToken))
        {
            ConnectionStateService.Instance.SetState(LobixConnectionState.Offline);
            return 0;
        }

        var operations = await _outbox.GetPendingAsync(100, cancellationToken);
        int successful = 0;
        var serverIds = new System.Collections.Generic.Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var operation in operations.Where(x => x.EntityType == "ManualBooking"))
        {
            cancellationToken.ThrowIfCancellationRequested();
            await _outbox.MarkSendingAsync(operation.OperationId, cancellationToken);
            string effectiveEntityId = operation.EntityId;
            try
            {
                switch (operation.OperationType)
                {
                    case "Create":
                    {
                        var request = JsonSerializer.Deserialize<BookingCreateRequest>(operation.Payload, JsonOptions)
                            ?? throw new InvalidOperationException("اطلاعات رزرو محلی قابل خواندن نیست.");
                        var response = await _api.CreateBookingAsync(request, operation.OperationId, cancellationToken);
                        var serverId = response.Booking?.Id;
                        if (string.IsNullOrWhiteSpace(serverId)) throw new InvalidOperationException("سرور شناسه رزرو را برنگرداند.");
                        var confirmed = OfflineBookingMapper.ToReservation(request, serverId, "Synced");
                        await _outbox.CompleteAsync(operation.OperationId, operation.EntityType, operation.EntityId,
                            operation.ProductId, serverId, JsonSerializer.Serialize(confirmed, JsonOptions), false, 0, cancellationToken);
                        serverIds[operation.EntityId] = serverId;
                        successful++;
                        break;
                    }
                    case "Update":
                    {
                        var request = JsonSerializer.Deserialize<BookingCreateRequest>(operation.Payload, JsonOptions)
                            ?? throw new InvalidOperationException("اطلاعات ویرایش رزرو محلی قابل خواندن نیست.");
                        var updateId = serverIds.TryGetValue(operation.EntityId, out var mappedUpdateId) ? mappedUpdateId : operation.EntityId;
                        effectiveEntityId = updateId;
                        await _api.UpdateBookingAsync(operation.ProductId, updateId, request,
                            operation.OperationId, cancellationToken);
                        var confirmed = OfflineBookingMapper.ToReservation(request, updateId, "Synced");
                        await _outbox.CompleteAsync(operation.OperationId, operation.EntityType, operation.EntityId,
                            operation.ProductId, updateId, JsonSerializer.Serialize(confirmed, JsonOptions), false, operation.BaseRevision, cancellationToken);
                        successful++;
                        break;
                    }
                    case "Delete":
                    {
                        var deleteId = serverIds.TryGetValue(operation.EntityId, out var mappedDeleteId) ? mappedDeleteId : operation.EntityId;
                        effectiveEntityId = deleteId;
                        await _api.DeleteBookingAsync(operation.ProductId, deleteId,
                            operation.OperationId, cancellationToken);
                        await _outbox.CompleteAsync(operation.OperationId, operation.EntityType, deleteId,
                            operation.ProductId, null, null, true, 0, cancellationToken);
                        successful++;
                        break;
                    }
                    default:
                        await _outbox.MarkRetryAsync(operation.OperationId,
                            "نوع عملیات آفلاین پشتیبانی نمی‌شود: " + operation.OperationType, cancellationToken);
                        break;
                }
            }
            catch (HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.Conflict)
            {
                if (ex.Message.Contains("booking_locked", StringComparison.OrdinalIgnoreCase))
                    await _outbox.MarkRetryAsync(operation.OperationId, ex.Message, CancellationToken.None);
                else
                    await _outbox.MarkConflictAsync(operation.OperationId, operation.ProductId,
                        operation.EntityType, effectiveEntityId, operation.Payload, ex.Message,
                        operation.BaseRevision, 0, CancellationToken.None);
            }
            catch (OperationCanceledException)
            {
                await _outbox.MarkRetryAsync(operation.OperationId, "عملیات همگام‌سازی لغو شد.", CancellationToken.None);
                throw;
            }
            catch (Exception ex)
            {
                await _outbox.MarkRetryAsync(operation.OperationId, ex.Message, CancellationToken.None);
            }
        }

        // Pull the current booking window after pushing local operations so the local snapshot
        // also receives changes made from other operator computers.
        if (_productId > 0)
        {
            try
            {
                string from = DateTime.Today.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
                string to = DateTime.Today.AddDays(30).ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
                await _api.SyncAsync(_productId, from, to, cancellationToken);
            }
            catch (Exception pullError)
            {
                System.Diagnostics.Debug.WriteLine("Offline sync pull failed: " + pullError);
            }
        }

        var pending = await _outbox.GetPendingAsync(1, cancellationToken);
        var conflicts = await _outbox.GetCountAsync("Conflict", ct: cancellationToken);
        ConnectionStateService.Instance.SetState(conflicts > 0
            ? LobixConnectionState.Conflict
            : pending.Count == 0 ? LobixConnectionState.Online : LobixConnectionState.Syncing);
        return successful;
    }
}

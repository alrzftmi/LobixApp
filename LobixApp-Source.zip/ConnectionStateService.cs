namespace LobixApp.Services.Sync;

public enum LobixConnectionState { Online, Offline, Syncing, Conflict, SyncError }

public sealed class ConnectionStateService
{
    private static readonly Lazy<ConnectionStateService> Lazy = new(() => new ConnectionStateService());
    public static ConnectionStateService Instance => Lazy.Value;
    private volatile LobixConnectionState _state = LobixConnectionState.Offline;
    public LobixConnectionState State => _state;
    public event EventHandler<LobixConnectionState>? StateChanged;
    private ConnectionStateService() { }
    public void SetState(LobixConnectionState state)
    {
        if (_state == state) return;
        _state = state;
        StateChanged?.Invoke(this, state);
    }
}

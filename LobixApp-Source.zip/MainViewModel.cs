﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace LobixApp.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private string _connectionStatus = "در حال آماده‌سازی...";

        public string ConnectionStatus
        {
            get => _connectionStatus;
            set
            {
                if (_connectionStatus == value)
                    return;

                _connectionStatus = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged(
            [CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(propertyName)
            );
        }
    }
}
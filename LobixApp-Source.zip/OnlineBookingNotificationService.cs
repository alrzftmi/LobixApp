using LobixApp.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using System.Windows.Forms;
using System.Drawing;

namespace LobixApp.Services
{
    /// <summary>
    /// Fast background polling for new online WooCommerce orders.
    /// Poll interval: 3 seconds.
    /// Orders are grouped by WooCommerce OrderId.
    /// Clicking a notification does not remove the order.
    /// </summary>
    public sealed class OnlineBookingNotificationService : IDisposable
    {
        private readonly LobixApiService _apiService = new();
        private readonly GamenetInfo _gamenet;
        private readonly NotifyIcon _notifyIcon;
        private readonly Dispatcher _dispatcher;
        private readonly CancellationTokenSource _cts = new();

        // Thread-safe access to pending orders.
        private readonly object _pendingLock = new();

        // OrderId -> booking items.
        private readonly Dictionary<int, List<ReservationItem>> _pending =
            new();

        // Orders already discovered by this application session.
        private readonly HashSet<int> _knownOrderIds = new();

        // Last notification time for each order.
        private readonly Dictionary<int, DateTime> _lastShownAt =
            new();

        private readonly TimeSpan _pollInterval =
            TimeSpan.FromSeconds(3);

        private readonly TimeSpan _repeatInterval =
            TimeSpan.FromSeconds(30);

        private bool _baselineReady;

        private int _polling;

        private volatile bool _disposed;

        private int? _currentlyShownOrderId;

        private DateTime _lastNotificationAt =
            DateTime.MinValue;

        /// <summary>
        /// Raised when the operator clicks a notification.
        /// </summary>
        public event Action<int>? OrderNotificationClicked;

        // ---------------------------------------------------------
        // Constructor
        // ---------------------------------------------------------

        public OnlineBookingNotificationService(
            GamenetInfo gamenet,
            OperatorSession session)
        {
            _gamenet = gamenet
                ?? throw new ArgumentNullException(nameof(gamenet));

            if (session == null)
                throw new ArgumentNullException(nameof(session));

            _apiService.SetAuthentication(session.Token);

            _dispatcher =
                System.Windows.Application.Current?.Dispatcher
                ?? Dispatcher.CurrentDispatcher;

            _notifyIcon = new NotifyIcon
            {
                Icon = SystemIcons.Information,
                Visible = true,
                Text = "لابیکس | اعلان رزرو آنلاین"
            };

            _notifyIcon.BalloonTipClicked +=
                NotifyIcon_BalloonTipClicked;

            // Start polling immediately.
            _ = Task.Run(PollLoopAsync);
        }

        // ---------------------------------------------------------
        // Background polling
        // ---------------------------------------------------------

        private async Task PollLoopAsync()
        {
            try
            {
                // First request runs immediately.
                await PollAsync();

                using var timer =
                    new PeriodicTimer(_pollInterval);

                while (await timer.WaitForNextTickAsync(_cts.Token))
                {
                    await PollAsync();
                }
            }
            catch (OperationCanceledException)
            {
                // Normal shutdown.
            }
            catch
            {
                // Keep the service alive.
            }
        }

        // ---------------------------------------------------------
        // Poll orders from server
        // ---------------------------------------------------------

        private async Task PollAsync()
        {
            if (_disposed)
                return;

            // Prevent overlapping requests.
            if (Interlocked.Exchange(ref _polling, 1) == 1)
                return;

            try
            {
                string from = DateTime.Today.ToString(
                    "yyyy-MM-dd",
                    CultureInfo.InvariantCulture);

                string to = DateTime.Today.AddDays(30).ToString(
                    "yyyy-MM-dd",
                    CultureInfo.InvariantCulture);

                GamenetSyncResponse sync =
                    await _apiService.SyncAsync(
                        _gamenet.Id,
                        from,
                        to);

                if (_disposed)
                    return;

                List<ReservationItem> online =
                    _apiService.GetReservationsFromSync(sync)
                        .Where(IsOnlineReservation)
                        .Where(x => x.OrderId > 0)
                        .Where(x => !string.IsNullOrWhiteSpace(x.Id))
                        .ToList();

                // Group reservations by WooCommerce order.
                Dictionary<int, List<ReservationItem>> orders =
                    online
                        .GroupBy(x => x.OrderId)
                        .ToDictionary(
                            group => group.Key,
                            group => group.ToList());

                bool newOrderFound = false;

                lock (_pendingLock)
                {
                    if (_disposed)
                        return;

                    // First Sync establishes the baseline.
                    // Existing orders are not treated as new.
                    if (!_baselineReady)
                    {
                        foreach (int orderId in orders.Keys)
                        {
                            _knownOrderIds.Add(orderId);
                        }

                        _baselineReady = true;
                        return;
                    }

                    foreach (var pair in orders)
                    {
                        int orderId = pair.Key;

                        List<ReservationItem> items =
                            pair.Value;

                        if (_knownOrderIds.Add(orderId))
                        {
                            // A completely new online order.
                            _pending[orderId] = items;

                            newOrderFound = true;
                        }
                        else if (_pending.ContainsKey(orderId))
                        {
                            // Update the items of an unresolved order.
                            _pending[orderId] = items;
                        }
                    }
                }

                if (_disposed)
                    return;

                bool hasPendingOrders;

                lock (_pendingLock)
                {
                    hasPendingOrders = _pending.Count > 0;
                }

                if (!hasPendingOrders)
                    return;

                // New orders receive immediate notification.
                if (newOrderFound)
                {
                    await ShowPendingNotificationAsync(force: true);
                    return;
                }

                // Repeat unresolved notifications every 30 seconds.
                bool shouldRepeat;

                lock (_pendingLock)
                {
                    shouldRepeat =
                        DateTime.UtcNow - _lastNotificationAt
                        >= _repeatInterval;
                }

                if (shouldRepeat)
                {
                    await ShowPendingNotificationAsync();
                }
            }
            catch
            {
                // A failed request must not stop future polling.
            }
            finally
            {
                Interlocked.Exchange(ref _polling, 0);
            }
        }

        // ---------------------------------------------------------
        // Identify online reservations
        // ---------------------------------------------------------

        private static bool IsOnlineReservation(
            ReservationItem item)
        {
            if (item == null)
                return false;

            if (string.IsNullOrWhiteSpace(item.Id))
                return false;

            if (item.Id.StartsWith(
                "manual_",
                StringComparison.OrdinalIgnoreCase))
                return false;

            if (string.Equals(
                item.Source,
                "manual",
                StringComparison.OrdinalIgnoreCase))
                return false;

            if (!string.IsNullOrEmpty(item.Source) &&
                item.Source.Contains(
                    "manual",
                    StringComparison.OrdinalIgnoreCase))
                return false;

            return true;
        }

        // ---------------------------------------------------------
        // Show notification
        // ---------------------------------------------------------

        private async Task ShowPendingNotificationAsync(
            bool force = false)
        {
            if (_disposed)
                return;

            await _dispatcher.InvokeAsync(() =>
            {
                if (_disposed)
                    return;

                int orderId;
                List<ReservationItem> items;

                lock (_pendingLock)
                {
                    if (_pending.Count == 0)
                        return;

                    DateTime now = DateTime.UtcNow;

                    if (!force &&
                        now - _lastNotificationAt < _repeatInterval)
                    {
                        return;
                    }

                    // Show the order that has waited the longest.
                    orderId = _pending.Keys
                        .OrderBy(id =>
                            _lastShownAt.TryGetValue(
                                id,
                                out DateTime shown)
                                    ? shown
                                    : DateTime.MinValue)
                        .First();

                    items = _pending[orderId].ToList();

                    if (items.Count == 0)
                        return;

                    _currentlyShownOrderId = orderId;

                    _lastShownAt[orderId] = now;

                    _lastNotificationAt = now;
                }

                ReservationItem first = items[0];

                string customer =
                    string.IsNullOrWhiteSpace(first.Customer)
                        ? "مشتری جدید"
                        : first.Customer.Trim();

                string date =
                    string.IsNullOrWhiteSpace(first.Date)
                        ? ""
                        : first.Date.Trim();

                string time =
                    string.IsNullOrWhiteSpace(first.StartTime)
                        ? "ساعت نامشخص"
                        : first.StartTime.Trim();

                string bookingCount =
                    items.Count == 1
                        ? "۱ رزرو"
                        : $"{items.Count} رزرو";

                _notifyIcon.BalloonTipTitle =
                    "سفارش آنلاین جدید لابیکس";

                _notifyIcon.BalloonTipText =
                    $"{customer}\n" +
                    $"{bookingCount} | {date} | {time}\n" +
                    "برای مشاهده جزئیات سفارش کلیک کنید.";

                _notifyIcon.ShowBalloonTip(10000);
            });
        }

        // ---------------------------------------------------------
        // Notification clicked
        // ---------------------------------------------------------

        private void NotifyIcon_BalloonTipClicked(
            object? sender,
            EventArgs e)
        {
            int? orderId;

            lock (_pendingLock)
            {
                orderId = _currentlyShownOrderId;
            }

            if (!orderId.HasValue)
                return;

            // Clicking does NOT remove the order.
            // It only opens the order details window.
            _dispatcher.BeginInvoke(new Action(() =>
            {
                if (_disposed)
                    return;

                OrderNotificationClicked?.Invoke(
                    orderId.Value);
            }));
        }

        // ---------------------------------------------------------
        // Get pending order
        // ---------------------------------------------------------

        public bool TryGetPendingOrder(
            int orderId,
            out List<ReservationItem> items)
        {
            lock (_pendingLock)
            {
                if (_pending.TryGetValue(
                    orderId,
                    out List<ReservationItem>? found))
                {
                    // Return a copy to avoid external modification.
                    items = found.ToList();

                    return true;
                }
            }

            items = new List<ReservationItem>();

            return false;
        }

        // ---------------------------------------------------------
        // Resolve order after successful server decision
        // ---------------------------------------------------------

        public void ResolveOrder(int orderId)
        {
            if (orderId <= 0 || _disposed)
                return;

            lock (_pendingLock)
            {
                _pending.Remove(orderId);

                _lastShownAt.Remove(orderId);

                if (_currentlyShownOrderId == orderId)
                {
                    _currentlyShownOrderId = null;
                }
            }
        }

        // ---------------------------------------------------------
        // Dispose
        // ---------------------------------------------------------

        public void Dispose()
        {
            if (_disposed)
                return;

            _disposed = true;

            _cts.Cancel();

            _notifyIcon.BalloonTipClicked -=
                NotifyIcon_BalloonTipClicked;

            _notifyIcon.Visible = false;

            _notifyIcon.Dispose();

            lock (_pendingLock)
            {
                _pending.Clear();

                _knownOrderIds.Clear();

                _lastShownAt.Clear();

                _currentlyShownOrderId = null;
            }

            OrderNotificationClicked = null;
        }
    }
}
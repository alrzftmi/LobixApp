﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace LobixApp.Utilities
{
    /// <summary>Branded, RTL dialog window used instead of the stock Windows MessageBox.</summary>
    public static class LobixDialog
    {
        public static void AnimateWindowIn(Window window)
        {
            window.Opacity = 0;
            window.Loaded += (_, _) =>
            {
                var fade = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(170))
                {
                    EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
                };
                window.BeginAnimation(Window.OpacityProperty, fade);
            };
        }

        public static MessageBoxResult Show(string message, string title = "لابیکس",
            MessageBoxButton buttons = MessageBoxButton.OK,
            MessageBoxImage image = MessageBoxImage.Information)
        {
            var accent = image == MessageBoxImage.Error || image == MessageBoxImage.Warning
                ? Color.FromRgb(244, 91, 105)
                : image == MessageBoxImage.Question
                    ? Color.FromRgb(219, 60, 69)
                    : Color.FromRgb(219, 60, 69);

            var dialog = new Window
            {
                Title = title,
                Width = 470,
                MinWidth = 390,
                SizeToContent = SizeToContent.Height,
                MaxHeight = 650,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                ResizeMode = ResizeMode.NoResize,
                WindowStyle = WindowStyle.None,
                AllowsTransparency = true,
                Background = Brushes.Transparent,
                FlowDirection = FlowDirection.RightToLeft,
                FontFamily = new FontFamily("pack://application:,,,/Fonts/#Peyda"),
                ShowInTaskbar = false,
                Topmost = false
            };

            var outer = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(24, 25, 35)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(60, 62, 81)),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(18),
                Padding = new Thickness(22),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    BlurRadius = 28, ShadowDepth = 5, Opacity = 0.35,
                    Color = Colors.Black
                }
            };
            var layout = new Grid();
            layout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            layout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            layout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var heading = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 14) };
            heading.Children.Add(new Border
            {
                Width = 12, Height = 12, CornerRadius = new CornerRadius(6),
                Background = new SolidColorBrush(accent), Margin = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center
            });
            heading.Children.Add(new TextBlock
            {
                Text = string.IsNullOrWhiteSpace(title) ? "پیام لابیکس" : title,
                FontSize = 18, FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(248, 248, 252)),
                VerticalAlignment = VerticalAlignment.Center
            });
            Grid.SetRow(heading, 0);
            layout.Children.Add(heading);

            var messageText = new TextBlock
            {
                Text = message ?? string.Empty,
                FontSize = 13,
                LineHeight = 24,
                TextWrapping = TextWrapping.Wrap,
                Foreground = new SolidColorBrush(Color.FromRgb(210, 211, 224)),
                Margin = new Thickness(0, 0, 0, 22),
                MaxWidth = 410
            };
            Grid.SetRow(messageText, 1);
            layout.Children.Add(messageText);

            var buttonRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Left };
            MessageBoxResult selected = MessageBoxResult.None;
            void AddButton(string label, MessageBoxResult result, bool primary)
            {
                var button = new Button
                {
                    Content = label,
                    MinWidth = 92,
                    Height = 40,
                    Padding = new Thickness(16, 7, 16, 7),
                    Margin = new Thickness(0, 0, 9, 0),
                    Cursor = System.Windows.Input.Cursors.Hand,
                    FontFamily = dialog.FontFamily,
                    FontSize = 13,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = Brushes.White,
                    Background = new SolidColorBrush(primary ? Color.FromRgb(219, 60, 69) : Color.FromRgb(42, 43, 58)),
                    BorderBrush = new SolidColorBrush(primary ? Color.FromRgb(201, 47, 57) : Color.FromRgb(65, 67, 85)),
                    BorderThickness = new Thickness(1)
                };
                button.Click += (_, _) =>
                {
                    selected = result;
                    // Window.DialogResult is bool?, not MessageBoxResult.
                    dialog.DialogResult = result == MessageBoxResult.OK || result == MessageBoxResult.Yes;
                };
                buttonRow.Children.Add(button);
            }

            if (buttons == MessageBoxButton.YesNo || buttons == MessageBoxButton.YesNoCancel)
                AddButton("بله، ادامه بده", MessageBoxResult.Yes, true);
            if (buttons == MessageBoxButton.OKCancel || buttons == MessageBoxButton.YesNoCancel)
                AddButton("انصراف", MessageBoxResult.Cancel, false);
            if (buttons == MessageBoxButton.YesNo || buttons == MessageBoxButton.YesNoCancel)
                AddButton("خیر", MessageBoxResult.No, false);
            else
                AddButton("متوجه شدم", MessageBoxResult.OK, true);

            Grid.SetRow(buttonRow, 2);
            layout.Children.Add(buttonRow);
            outer.Child = layout;
            dialog.Content = outer;

            var owner = Application.Current?.Windows.OfType<Window>().FirstOrDefault(w => w.IsActive && w.Visibility == Visibility.Visible);
            if (owner != null && owner != dialog) dialog.Owner = owner;
            dialog.Loaded += (_, _) =>
            {
                dialog.Opacity = 0;
                var fade = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(160)) { EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut } };
                dialog.BeginAnimation(Window.OpacityProperty, fade);
            };
            dialog.Closed += (_, _) => { if (selected == MessageBoxResult.None) selected = buttons == MessageBoxButton.YesNo ? MessageBoxResult.No : MessageBoxResult.Cancel; };
            dialog.ShowDialog();
            return selected == MessageBoxResult.None ? (buttons == MessageBoxButton.OK ? MessageBoxResult.OK : MessageBoxResult.Cancel) : selected;
        }
    }
}

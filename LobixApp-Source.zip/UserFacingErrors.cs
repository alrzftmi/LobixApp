﻿using System;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LobixApp.Utilities
{
    /// <summary>
    /// Keeps technical exception details out of the operator UI while leaving a small local diagnostic trail.
    /// </summary>
    public static class UserFacingErrors
    {
        public static void Record(Exception exception) => Log(exception);

        public static string GetMessage(Exception exception, string fallback = "عملیات انجام نشد. لطفاً اتصال را بررسی کنید و دوباره تلاش کنید.")
        {
            Log(exception);

            if (exception is HttpRequestException)
                return "ارتباط با سرور لابیکس برقرار نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.";

            if (exception is TaskCanceledException || exception is TimeoutException)
                return "پاسخ سرور بیش از حد طول کشید. چند لحظه دیگر دوباره تلاش کنید.";

            if (exception is JsonException)
                return "پاسخ سرور قابل خواندن نبود. لطفاً دوباره تلاش کنید؛ اگر مشکل ادامه داشت با پشتیبانی تماس بگیرید.";

            string message = (exception.Message ?? string.Empty).Trim();
            if (IsSafePersianMessage(message))
                return message;

            return fallback;
        }

        private static bool IsSafePersianMessage(string message)
        {
            if (message.Length == 0 || message.Length > 280)
                return false;

            // A Persian sentence may be shown, but raw JSON, stack traces, URLs and protocol details must not be.
            if (message.Contains('{') || message.Contains('}') || message.Contains('\n') || message.Contains('\r') ||
                message.Contains("http", StringComparison.OrdinalIgnoreCase) || message.Contains("status", StringComparison.OrdinalIgnoreCase) ||
                message.Contains("exception", StringComparison.OrdinalIgnoreCase) || message.Contains("stack", StringComparison.OrdinalIgnoreCase) ||
                message.Contains("Bearer", StringComparison.OrdinalIgnoreCase) || message.Contains("token", StringComparison.OrdinalIgnoreCase) ||
                message.Contains("جزئیات", StringComparison.OrdinalIgnoreCase) || message.Contains("api", StringComparison.OrdinalIgnoreCase) ||
                Regex.IsMatch(message, @"[A-Za-z]{3,}[_A-Za-z]*") || Regex.IsMatch(message, @"\b[45]\d{2}\b"))
                return false;

            foreach (char c in message)
                if (c >= '\u0600' && c <= '\u06FF')
                    return true;

            return false;
        }

        private static void Log(Exception exception)
        {
            try
            {
                string directory = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Lobix", "Logs");
                Directory.CreateDirectory(directory);
                string file = Path.Combine(directory, $"lobix-{DateTime.Now:yyyy-MM-dd}.log");
                string safeMessage = Regex.Replace(exception.Message ?? string.Empty,
                    @"(?i)(token|password|authorization|bearer)\s*[:= ]\s*[^\s,;]+", "$1=[redacted]");
                safeMessage = safeMessage.Replace("\r", " ").Replace("\n", " ");
                if (safeMessage.Contains('{') || safeMessage.Contains('}'))
                    safeMessage = "Structured server response omitted for privacy.";
                if (safeMessage.Length > 300) safeMessage = safeMessage[..300];
                File.AppendAllText(file,
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {exception.GetType().Name}: {safeMessage}{Environment.NewLine}");
            }
            catch
            {
                // Logging must never interrupt the operator workflow.
            }
        }
    }
}

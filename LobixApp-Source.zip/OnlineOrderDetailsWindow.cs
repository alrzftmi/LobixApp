﻿using LobixApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace LobixApp.Views
{
    public sealed class OnlineOrderDetailsWindow : Window
    {
        private readonly int _orderId;

        private readonly Button _confirmButton;
        private readonly Button _rejectButton;
        private readonly TextBlock _statusText;

        public event Action<int, string>? DecisionRequested;

        public OnlineOrderDetailsWindow(
            int orderId,
            IReadOnlyList<ReservationItem> items)
        {
            _orderId = orderId;

            Title = $"جزئیات سفارش #{orderId}";
            Width = 1000;
            Height = 650;
            MinWidth = 780;
            MinHeight = 500;

            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            FlowDirection = FlowDirection.RightToLeft;
            FontFamily = new FontFamily("Peyda");

            Background = Brush(19, 19, 27);
            Foreground = Brushes.White;

            var root = new Grid
            {
                Margin = new Thickness(22)
            };

            root.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            root.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            root.RowDefinitions.Add(
                new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            root.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            var header = new Border
            {
                Background = Brush(35, 30, 46),
                BorderBrush = Brush(76, 55, 99),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(12),
                Padding = new Thickness(18),
                Margin = new Thickness(0, 0, 0, 12)
            };

            header.Child = new TextBlock
            {
                Text = $"جزئیات سفارش آنلاین #{orderId}",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.White,
                VerticalAlignment = VerticalAlignment.Center
            };

            Grid.SetRow(header, 0);
            root.Children.Add(header);

            var summary = new TextBlock
            {
                Text = $"تعداد رزروهای این سفارش: {items.Count}",
                FontSize = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = Brush(205, 195, 220),
                Margin = new Thickness(4, 0, 0, 12)
            };

            Grid.SetRow(summary, 1);
            root.Children.Add(summary);

            var grid = new DataGrid
            {
                AutoGenerateColumns = false,
                IsReadOnly = true,
                CanUserAddRows = false,
                CanUserDeleteRows = false,
                CanUserResizeRows = false,
                HeadersVisibility = DataGridHeadersVisibility.Column,
                GridLinesVisibility = DataGridGridLinesVisibility.Horizontal,
                Background = Brush(25, 25, 35),
                Foreground = Brushes.White,
                BorderBrush = Brush(62, 62, 78),
                BorderThickness = new Thickness(1),
                RowBackground = Brush(29, 29, 40),
                AlternatingRowBackground = Brush(36, 36, 49),
                FontFamily = new FontFamily("Peyda"),
                FontSize = 12,
                CanUserSortColumns = false
            };

            grid.ColumnHeaderStyle = new Style(
                typeof(DataGridColumnHeader))
            {
                Setters =
                {
                    new Setter(
                        Control.BackgroundProperty,
                        Brush(52, 40, 67)),

                    new Setter(
                        Control.ForegroundProperty,
                        Brushes.White),

                    new Setter(
                        Control.FontFamilyProperty,
                        new FontFamily("Peyda")),

                    new Setter(
                        Control.FontWeightProperty,
                        FontWeights.Bold),

                    new Setter(
                        Control.PaddingProperty,
                        new Thickness(12, 12, 12, 12)),

                    new Setter(
                        Control.HorizontalContentAlignmentProperty,
                        HorizontalAlignment.Center)
                }
            };

            grid.RowStyle = new Style(typeof(DataGridRow))
            {
                Setters =
    {
        new Setter(
            Control.ForegroundProperty,
            Brushes.White),

        new Setter(
            Control.FontFamilyProperty,
            new FontFamily("Peyda")),

        new Setter(
            FrameworkElement.MinHeightProperty,
            43.0)
    }
            };

            grid.CellStyle = new Style(typeof(DataGridCell))
            {
                Setters =
                {
                    new Setter(
                        Control.ForegroundProperty,
                        Brushes.White),

                    new Setter(
                        Control.BackgroundProperty,
                        Brushes.Transparent),

                    new Setter(
                        Control.BorderThicknessProperty,
                        new Thickness(0)),

                    new Setter(
                        Control.PaddingProperty,
                        new Thickness(8, 5, 8, 5)),

                    new Setter(
                        Control.HorizontalContentAlignmentProperty,
                        HorizontalAlignment.Center)
                }
            };

            AddColumn(grid, "تاریخ", "Date", 1.2);
            AddColumn(grid, "ساعت شروع", "StartTime", 1);
            AddColumn(grid, "مدت (ساعت)", "Hours", 0.8);
            AddColumn(grid, "نوع سیستم", "SystemType", 1.3);
            AddColumn(grid, "شماره سیستم", "SystemNumber", 1.1);
            AddColumn(grid, "مبلغ", "Amount", 1.2);

            grid.ItemsSource = items.Select(item =>
            {
                string systemNumbers =
                    item.Systems == null
                        ? "-"
                        : string.Join(
                            "، ",
                            item.Systems
                                .Select(s => s.SystemNumber)
                                .Where(s => !string.IsNullOrWhiteSpace(s))
                                .Distinct());

                return new OrderLineDisplay
                {
                    Date = item.Date,
                    StartTime = item.StartTime,
                    Hours = item.Hours.ToString(),
                    SystemType = string.IsNullOrWhiteSpace(item.SystemType)
                        ? $"سیستم {item.VariationId}"
                        : item.SystemType,
                    SystemNumber = string.IsNullOrWhiteSpace(systemNumbers)
                        ? "-"
                        : systemNumbers,
                    Amount = $"{item.Amount:N0} تومان"
                };
            }).ToList();

            Grid.SetRow(grid, 2);
            root.Children.Add(grid);

            var footer = new Grid
            {
                Margin = new Thickness(0, 16, 0, 0)
            };

            footer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            footer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = GridLength.Auto });

            _statusText = new TextBlock
            {
                Text = "برای ثبت تصمیم، یکی از گزینه‌ها را انتخاب کن.",
                Foreground = Brush(190, 190, 205),
                FontSize = 12,
                VerticalAlignment = VerticalAlignment.Center
            };

            Grid.SetColumn(_statusText, 0);
            footer.Children.Add(_statusText);

            var buttons = new StackPanel
            {
                Orientation = Orientation.Horizontal
            };

            _confirmButton = CreateButton(
                "تأیید کل سفارش",
                Brush(31, 115, 76),
                Brush(255, 255, 255));

            _rejectButton = CreateButton(
                "رد کل سفارش",
                Brush(140, 43, 53),
                Brush(255, 255, 255));

            var closeButton = CreateButton(
                "بستن",
                Brush(52, 52, 66),
                Brush(235, 235, 240));

            _confirmButton.Click += (_, _) =>
            {
                DecisionRequested?.Invoke(_orderId, "confirmed");
            };

            _rejectButton.Click += (_, _) =>
            {
                var result = MessageBox.Show(
                    "آیا از رد تمام رزروهای این سفارش مطمئن هستی؟",
                    "تأیید رد سفارش",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                    DecisionRequested?.Invoke(_orderId, "rejected");
            };

            closeButton.Click += (_, _) => Close();

            buttons.Children.Add(_confirmButton);
            buttons.Children.Add(_rejectButton);
            buttons.Children.Add(closeButton);

            Grid.SetColumn(buttons, 1);
            footer.Children.Add(buttons);

            Grid.SetRow(footer, 3);
            root.Children.Add(footer);

            Content = root;
        }

        private sealed class OrderLineDisplay
        {
            public string Date { get; set; } = "";
            public string StartTime { get; set; } = "";
            public string Hours { get; set; } = "";
            public string SystemType { get; set; } = "";
            public string SystemNumber { get; set; } = "";
            public string Amount { get; set; } = "";
        }

        private static void AddColumn(
            DataGrid grid,
            string title,
            string binding,
            double width)
        {
            grid.Columns.Add(new DataGridTextColumn
            {
                Header = title,
                Binding = new System.Windows.Data.Binding(binding),
                Width = new DataGridLength(
                    width,
                    DataGridLengthUnitType.Star)
            });
        }

        private static Button CreateButton(
            string text,
            Brush background,
            Brush foreground)
        {
            return new Button
            {
                Content = text,
                FontFamily = new FontFamily("Peyda"),
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Background = background,
                Foreground = foreground,
                BorderBrush = background,
                BorderThickness = new Thickness(1),
                Padding = new Thickness(17, 10, 17, 10),
                Margin = new Thickness(5, 0, 5, 0),
                Cursor = System.Windows.Input.Cursors.Hand
            };
        }

        private static SolidColorBrush Brush(
            byte r,
            byte g,
            byte b)
        {
            return new SolidColorBrush(
                Color.FromRgb(r, g, b));
        }

        public void SetProcessing(bool processing)
        {
            _confirmButton.IsEnabled = !processing;
            _rejectButton.IsEnabled = !processing;

            _statusText.Text = processing
                ? "در حال ثبت تصمیم روی سرور..."
                : "ثبت تصمیم ناموفق بود؛ می‌توانی دوباره تلاش کنی.";
        }

        public void SetDecisionResult(
            bool success,
            string message)
        {
            if (success)
            {
                Close();
                return;
            }

            _confirmButton.IsEnabled = true;
            _rejectButton.IsEnabled = true;

            _statusText.Text = message;
            _statusText.Foreground = Brush(255, 120, 120);
        }
    }
}
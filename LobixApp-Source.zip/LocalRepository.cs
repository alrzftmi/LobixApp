namespace LobixApp.Services.Repositories;

/// <summary>Generic local-first repository. Mutations are committed locally with an outbox row in one transaction.</summary>
public sealed class LocalRepository
{
    private readonly LocalDatabase _database;
    public LocalRepository(LocalDatabase? database = null) => _database = database ?? LocalDatabase.Instance;

    public Task<T?> GetAsync<T>(string entityType, string entityId, int productId = 0, CancellationToken ct = default) =>
        _database.GetEntityAsync<T>(entityType, entityId, productId, ct);

    public Task<IReadOnlyList<T>> GetAllAsync<T>(string entityType, int productId = 0, CancellationToken ct = default) =>
        _database.GetEntitiesAsync<T>(entityType, productId, ct);

    public Task<string> CreateOrUpdateAsync<T>(int productId, string entityType, string entityId, T entity,
        long baseRevision = 0, CancellationToken ct = default) =>
        _database.SaveLocalChangeAsync(productId, entityType, entityId, entity,
            baseRevision == 0 ? "CreateOrUpdate" : "Update", baseRevision, ct);

    public Task<string> DeleteAsync(int productId, string entityType, string entityId,
        long baseRevision = 0, CancellationToken ct = default) =>
        _database.DeleteLocalEntityAsync(productId, entityType, entityId, baseRevision, ct);
}

﻿
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace LobixApp.Models
{
    public class AvailabilityResponse
    {
        public bool Success { get; set; }

        [JsonPropertyName("api_version")]
        public string ApiVersion { get; set; } = string.Empty;

        [JsonPropertyName("server_time")]
        public string ServerTime { get; set; } = string.Empty;

        public AvailabilityData Availability { get; set; } = new();
    }


    public class AvailabilityData
    {
        public string Date { get; set; } = string.Empty;

        [JsonPropertyName("variation_id")]
        public int VariationId { get; set; }

        public int Capacity { get; set; }

        [JsonPropertyName("work_start")]
        public int WorkStart { get; set; }

        [JsonPropertyName("work_end")]
        public int WorkEnd { get; set; }

        public List<AvailabilityHour> Hours { get; set; } = new();

        public List<AvailabilityHour> Slots { get; set; } = new();
    }


    public class AvailabilityHour
    {
        public int Hour { get; set; }

        public int Capacity { get; set; }

        public int Reserved { get; set; }

        public int Available { get; set; }

        public bool Bookable { get; set; }
    }
}

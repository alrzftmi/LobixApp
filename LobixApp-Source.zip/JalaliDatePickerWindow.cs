﻿
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using LobixApp.Utilities;

namespace LobixApp.Utilities
{
    public sealed class JalaliDatePickerWindow : Window
    {
        private readonly Grid _daysGrid;
        private readonly TextBlock _monthTitle;
        private readonly DateTime _minimumDate;

        private int _year;
        private int _month;
        private DateTime? _selectedDate;

        private readonly Brush _background = Brush("#111116");
        private readonly Brush _card = Brush("#1B1B24");
        private readonly Brush _border = Brush("#343442");
        private readonly Brush _accent = Brush("#DB3C45");
        private readonly Brush _foreground = Brush("#F4F4F8");
        private readonly Brush _muted = Brush("#B0B0BF");

        public DateTime? SelectedDate => _selectedDate;

        public JalaliDatePickerWindow(
            DateTime? initialDate = null,
            DateTime? minimumDate = null)
        {
            _minimumDate = (minimumDate ?? DateTime.Today).Date;

            DateTime initial = (initialDate ?? DateTime.Today).Date;

            if (initial < _minimumDate)
                initial = _minimumDate;

            _selectedDate = initial;
            _year = JalaliDateHelper.GetYear(initial);
            _month = JalaliDateHelper.GetMonth(initial);

            Title = "انتخاب تاریخ شمسی";
            Width = 370;
            Height = 450;
            MinWidth = 370;
            MinHeight = 450;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            FlowDirection = FlowDirection.RightToLeft;
            Background = _background;
            Foreground = _foreground;
            FontFamily = new FontFamily("Segoe UI");

            Grid root = new()
            {
                Margin = new Thickness(18)
            };

            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            Content = root;

            Grid monthHeader = new()
            {
                Margin = new Thickness(0, 0, 0, 16)
            };

            monthHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            monthHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            monthHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            Button previousButton = MakeButton("‹", 38, 36);
            previousButton.Click += (_, _) => ChangeMonth(-1);
            Grid.SetColumn(previousButton, 0);
            monthHeader.Children.Add(previousButton);

            _monthTitle = new TextBlock
            {
                FontSize = 17,
                FontWeight = FontWeights.Bold,
                Foreground = _foreground,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            Grid.SetColumn(_monthTitle, 1);
            monthHeader.Children.Add(_monthTitle);

            Button nextButton = MakeButton("›", 38, 36);
            nextButton.Click += (_, _) => ChangeMonth(1);
            Grid.SetColumn(nextButton, 2);
            monthHeader.Children.Add(nextButton);

            Grid.SetRow(monthHeader, 0);
            root.Children.Add(monthHeader);

            Grid weekdays = new()
            {
                Margin = new Thickness(0, 0, 0, 8)
            };

            for (int i = 0; i < 7; i++)
                weekdays.ColumnDefinitions.Add(new ColumnDefinition());

            string[] weekdayNames =
            {
                "شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه",
                "چهارشنبه", "پنجشنبه", "جمعه"
            };

            for (int i = 0; i < weekdayNames.Length; i++)
            {
                TextBlock label = new()
                {
                    Text = weekdayNames[i],
                    FontSize = 10,
                    Foreground = _muted,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };

                Grid.SetColumn(label, i);
                weekdays.Children.Add(label);
            }

            Grid.SetRow(weekdays, 1);
            root.Children.Add(weekdays);

            _daysGrid = new Grid
            {
                Margin = new Thickness(0, 0, 0, 12)
            };

            for (int i = 0; i < 7; i++)
                _daysGrid.ColumnDefinitions.Add(new ColumnDefinition());

            for (int i = 0; i < 6; i++)
                _daysGrid.RowDefinitions.Add(new RowDefinition());

            Grid.SetRow(_daysGrid, 2);
            root.Children.Add(_daysGrid);

            StackPanel footer = new()
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Stretch
            };

            Button todayButton = MakeButton("امروز", 0, 38);
            todayButton.Margin = new Thickness(0, 0, 8, 0);
            todayButton.Click += (_, _) =>
            {
                DateTime today = DateTime.Today;

                if (today >= _minimumDate)
                {
                    _selectedDate = today;
                    _year = JalaliDateHelper.GetYear(today);
                    _month = JalaliDateHelper.GetMonth(today);
                    RenderCalendar();
                }
            };

            Button cancelButton = MakeButton("انصراف", 0, 38);
            cancelButton.Margin = new Thickness(0, 0, 8, 0);
            cancelButton.Click += (_, _) =>
            {
                DialogResult = false;
            };

            Button confirmButton = MakeButton("تأیید تاریخ", 0, 38);
            confirmButton.Background = _accent;
            confirmButton.Foreground = Brushes.White;
            confirmButton.FontWeight = FontWeights.SemiBold;
            confirmButton.Click += (_, _) =>
            {
                if (_selectedDate.HasValue &&
                    _selectedDate.Value.Date >= _minimumDate)
                {
                    DialogResult = true;
                }
            };

            todayButton.HorizontalAlignment = HorizontalAlignment.Stretch;
            cancelButton.HorizontalAlignment = HorizontalAlignment.Stretch;
            confirmButton.HorizontalAlignment = HorizontalAlignment.Stretch;

            todayButton.Width = 75;
            cancelButton.Width = 85;
            confirmButton.Width = 120;

            footer.Children.Add(todayButton);
            footer.Children.Add(cancelButton);
            footer.Children.Add(confirmButton);

            Grid.SetRow(footer, 3);
            root.Children.Add(footer);

            RenderCalendar();
        }

        private void ChangeMonth(int offset)
        {
            DateTime currentMonth =
                JalaliDateHelper.ToGregorianDate(_year, _month, 1);

            DateTime targetMonth =
                JalaliDateHelper.AddPersianMonths(currentMonth, offset);

            _year = JalaliDateHelper.GetYear(targetMonth);
            _month = JalaliDateHelper.GetMonth(targetMonth);

            RenderCalendar();
        }

        private void RenderCalendar()
        {
            _monthTitle.Text =
                JalaliDateHelper.FormatMonth(_year, _month);

            _daysGrid.Children.Clear();

            int daysInMonth =
                JalaliDateHelper.GetDaysInMonth(_year, _month);

            DateTime firstDay =
                JalaliDateHelper.ToGregorianDate(_year, _month, 1);

            // در تقویم شمسی، هفته از شنبه شروع می‌شود.
            int startOffset = ((int)firstDay.DayOfWeek + 1) % 7;

            for (int day = 1; day <= daysInMonth; day++)
            {
                int cellIndex = startOffset + day - 1;
                int row = cellIndex / 7;
                int column = cellIndex % 7;

                DateTime gregorianDate =
                    JalaliDateHelper.ToGregorianDate(_year, _month, day);

                bool isPast = gregorianDate.Date < _minimumDate;
                bool isSelected =
                    _selectedDate.HasValue &&
                    _selectedDate.Value.Date == gregorianDate.Date;

                bool isToday = gregorianDate.Date == DateTime.Today;

                Button dayButton = MakeButton(
                    JalaliDateHelper.ToPersianDigits(day.ToString("00")),
                    0,
                    42);

                dayButton.Margin = new Thickness(2);
                dayButton.Padding = new Thickness(0);
                dayButton.BorderThickness = new Thickness(1);

                if (isSelected)
                {
                    dayButton.Background = _accent;
                    dayButton.Foreground = Brushes.White;
                    dayButton.BorderBrush = _accent;
                }
                else if (isToday)
                {
                    dayButton.Background = _card;
                    dayButton.Foreground = _foreground;
                    dayButton.BorderBrush = _accent;
                }
                else
                {
                    dayButton.Background = _card;
                    dayButton.Foreground = _foreground;
                    dayButton.BorderBrush = _border;
                }

                dayButton.IsEnabled = !isPast;
                dayButton.Opacity = isPast ? 0.35 : 1;

                DateTime capturedDate = gregorianDate;

                dayButton.Click += (_, _) =>
                {
                    _selectedDate = capturedDate;
                    RenderCalendar();
                };

                Grid.SetRow(dayButton, row);
                Grid.SetColumn(dayButton, column);
                _daysGrid.Children.Add(dayButton);
            }
        }

        private Button MakeButton(
            string text,
            double width,
            double height)
        {
            Button button = new()
            {
                Content = text,
                Width = width > 0 ? width : double.NaN,
                Height = height,
                Padding = new Thickness(8, 4, 8, 4),
                Margin = new Thickness(0),
                FontSize = 12,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = _foreground,
                Background = _card,
                BorderBrush = _border,
                BorderThickness = new Thickness(1),
                Cursor = System.Windows.Input.Cursors.Hand,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment = VerticalAlignment.Center
            };

            return button;
        }

        private static SolidColorBrush Brush(string color)
        {
            return new SolidColorBrush(
                (Color)ColorConverter.ConvertFromString(color));
        }
    }
}
